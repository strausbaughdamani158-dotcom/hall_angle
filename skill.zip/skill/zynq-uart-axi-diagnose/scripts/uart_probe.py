#!/usr/bin/env python3
"""Read-only PS UART ASCII hello probe; adaptable to similar FPGA projects."""

import argparse
import sys
import time


def parse_hello(line, expected_version=None, expected_base=None, expected_max_samples=None):
    """Parse `OK HELLO <version> <base> <max_samples>` or raise ValueError."""
    fields = line.strip().split()
    if len(fields) != 5 or fields[:2] != ["OK", "HELLO"]:
        raise ValueError(f"非 HELLO 回应: {line!r}")
    try:
        version = int(fields[2], 10)
        base = int(fields[3], 0)
        max_samples = int(fields[4], 16)
    except ValueError as exc:
        raise ValueError(f"HELLO 字段无法解析: {line!r}") from exc
    if not (0 <= version <= 65535 and 0 <= base <= 0xFFFFFFFF and max_samples > 0):
        raise ValueError(f"HELLO 字段超出范围: {line!r}")
    if expected_version is not None and version != expected_version:
        raise ValueError(f"协议版本不匹配: 实际 {version}, 期望 {expected_version}")
    if expected_base is not None and base != expected_base:
        raise ValueError(f"AXI 基址不匹配: 实际 0x{base:08X}, 期望 0x{expected_base:08X}")
    if expected_max_samples is not None and max_samples != expected_max_samples:
        raise ValueError(f"缓存上限不匹配: 实际 {max_samples}, 期望 {expected_max_samples}")
    return version, base, max_samples


def read_reply(port, deadline):
    data = bytearray()
    while time.monotonic() < deadline:
        char = port.read(1)
        if not char:
            continue
        if char == b"\n":
            try:
                line = data.decode("ascii").strip()
            except UnicodeDecodeError as exc:
                raise ValueError("收到非 ASCII 字节：检查波特率、8N1 与电平") from exc
            data.clear()
            if not line or line.startswith("READY "):
                continue
            return line
        data.extend(char)
        if len(data) > 8192:
            raise ValueError("回应超过 8192 字节：可能不是预期的行协议")
    raise TimeoutError("未收到完整回应：检查端口、引脚、bitstream、CPU 运行和 UART 配置")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", required=True, help="例如 COM14 或 /dev/ttyUSB0")
    parser.add_argument("--baud", type=int, default=115200)
    parser.add_argument("--timeout", type=float, default=3.0)
    parser.add_argument("--expect-version", type=int)
    parser.add_argument("--expect-base", type=lambda value: int(value, 0))
    parser.add_argument("--expect-max-samples", type=int)
    args = parser.parse_args(argv)
    if args.expect_max_samples is not None and args.expect_max_samples <= 0:
        parser.error("expect-max-samples 必须大于 0")
    if args.baud <= 0 or args.timeout <= 0:
        parser.error("baud 和 timeout 必须大于 0")

    try:
        import serial
    except ImportError:
        print("缺少 pyserial；运行 python -m pip install pyserial", file=sys.stderr)
        return 2

    try:
        with serial.Serial(args.port, args.baud, timeout=0.1, write_timeout=1,
                           bytesize=8, parity="N", stopbits=1) as port:
            port.write(b"\n")
            time.sleep(0.15)
            port.reset_input_buffer()
            if port.write(b"hello\n") != len(b"hello\n"):
                raise IOError("hello 命令发送不完整")
            line = read_reply(port, time.monotonic() + args.timeout)
            print(f"原始回应: {line}")
            version, base, max_samples = parse_hello(
                line, args.expect_version, args.expect_base, args.expect_max_samples
            )
            print(f"握手通过: version={version}, base=0x{base:08X}, max_samples={max_samples}")
            print("范围: 仅确认 UART/PS 文本握手；未验证 AXI 读写或 PL 功能")
            return 0
    except (OSError, TimeoutError, ValueError, IOError) as exc:
        print(f"握手失败: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
