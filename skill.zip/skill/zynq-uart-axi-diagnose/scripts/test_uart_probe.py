"""Offline synthetic-stream checks; no serial hardware is opened."""
import unittest
import time
from unittest.mock import patch
from uart_probe import parse_hello, read_reply

GOOD = 'OK HELLO 6 0x43C00000 0x00008000'

class FakePort:
    def __init__(self, payload): self.payload = bytearray(payload)
    def read(self, size):
        result = bytes(self.payload[:size]); del self.payload[:size]; return result

class ProbeTests(unittest.TestCase):
    def test_current_contract(self):
        self.assertEqual(parse_hello(GOOD,6,0x43C00000,32768),(6,0x43C00000,32768))
    def test_version_mismatch(self):
        with self.assertRaisesRegex(ValueError,'版本不匹配'):
            parse_hello(GOOD.replace('HELLO 6','HELLO 5'),6)
    def test_base_mismatch(self):
        with self.assertRaisesRegex(ValueError,'基址不匹配'):
            parse_hello(GOOD,6,0x40000000)
    def test_capacity_mismatch(self):
        with self.assertRaisesRegex(ValueError,'缓存上限不匹配'):
            parse_hello(GOOD.replace('0x00008000','0x1000'),6,0x43C00000,32768)
    def test_err_response(self):
        with self.assertRaisesRegex(ValueError,'非 HELLO'): parse_hello('ERR CMD')
    def test_missing_field(self):
        with self.assertRaises(ValueError): parse_hello('OK HELLO 6 0x43C00000')
    def test_invalid_number(self):
        with self.assertRaisesRegex(ValueError,'字段无法解析'): parse_hello(GOOD.replace('0x00008000','not_hex'))
    def test_zero_capacity(self):
        with self.assertRaisesRegex(ValueError,'字段超出范围'): parse_hello(GOOD.replace('0x00008000','0'))
    def test_skips_boot_and_blank_lines(self):
        p=FakePort(b'READY PS_AXI_ASCII 6\r\n\r\n'+GOOD.encode()+b'\r\n')
        self.assertEqual(read_reply(p,time.monotonic()+1),GOOD)
    def test_non_ascii(self):
        with self.assertRaisesRegex(ValueError,'非 ASCII'): read_reply(FakePort(b'\xff\n'),time.monotonic()+1)
    def test_timeout(self):
        with patch('uart_probe.time.monotonic',side_effect=[0.,2.]):
            with self.assertRaises(TimeoutError):read_reply(FakePort(b''),1.)
    def test_partial_line_timeout(self):
        with patch('uart_probe.time.monotonic',side_effect=[0.,0.,2.]):
            with self.assertRaises(TimeoutError):read_reply(FakePort(b'OK'),1.)
    def test_oversize(self):
        with self.assertRaisesRegex(ValueError,'8192'):read_reply(FakePort(b'X'*8193),time.monotonic()+2)

if __name__=='__main__': unittest.main()
