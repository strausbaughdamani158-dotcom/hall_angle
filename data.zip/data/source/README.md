# 原始数据表

| 文件 | 原始来源 | 用途 |
| --- | --- | --- |
| `dividing_head_interpolation_calibration.xls` | `9.xls` 原样复制 | `Sheet1` 第 1–41 行：A 为插值前分度头角度，B 为插值前算法角度；D 为校准后分度头角度，E 为校准后算法角度。A 和 D 全部相同，0°–360°、间隔 9°。 |
| `temperature_compensation_source.xls` | 原温度补偿源表 | 同时包含校准/补偿前后记录，用于两组温度曲线数据。 |

从分度头原表拆出的阶段数据分别在 `../reference/dividing_head_before_calibration.xlsx` 和 `../measured/dividing_head_after_calibration.xlsx`。两表的误差列按 B−A、E−D 计算。41 点误差统计：前期范围 -1.16°～+0.10°、RMS 0.624°；后期范围 -0.07°～+0.09°、RMS 0.034°。对应图为 `../../board/results/angle_error_from_dividing_head_9xls.png`。


