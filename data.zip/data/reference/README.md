# 校准前、补偿前数据

| 文件 | 内容 |
| --- | --- |
| `dividing_head_before_calibration.xlsx` | 41 个分度头参考角度、插值前算法输出角度、误差 B−A。 |
| `working_point_before_calibration_plot_data.csv` | CH1/CH2 校准前工作点随温度变化的绘图数据。 |
| `sensitivity_before_calibration_plot_data.csv` | CH1/CH2 校准前峰值码随温度变化的绘图数据。 |


