# 校准后、补偿后数据

| 文件 | 内容 |
| --- | --- |
| `dividing_head_after_calibration.xlsx` | 41 个分度头参考角度、校准后算法输出角度、误差 E−D。 |
| `working_point_after_calibration_plot_data.csv` | CH1/CH2 校准后工作点随温度变化的绘图数据。 |
| `sensitivity_after_calibration_plot_data.csv` | CH1/CH2 校准后峰值码随温度变化的绘图数据。 |


