# Hall 输出示波器波形

这些图片是 PWM 四个档位和 SENT 模式的示波器实拍，按接口类型归档。文件保留原始画面，名称中的频率为设定档位。

| 文件 | 设定模式 |
| --- | --- |
| `pwm_50hz_scope.png` | PWM，50 Hz |
| `pwm_500hz_scope.png` | PWM，500 Hz |
| `pwm_2000hz_scope.png` | PWM，2000 Hz |
| `pwm_4000hz_scope.png` | PWM，4000 Hz |
| `sent_scope.png` | SENT |


