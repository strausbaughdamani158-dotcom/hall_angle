# Board measurement results

本目录归档已确认来自上板实测的结果图。装置照片在 `../setup/photos/`，图片文件名使用英文以便跨平台引用；图中文字保留中文。

| 文件 | 内容 | 关联数据 |
| --- | --- | --- 
| `angle_error_before_after_interpolation.png` | 插值前后角度误差随角度变化的对比 |  
| `angle_error_from_dividing_head_9xls.png` | 依据 41 点分度头实测数据绘制的插值校准前后误差 | `../../data/source/dividing_head_interpolation_calibration.xls`；拆分表见 `../../data/reference/` 和 `../../data/measured/` |
| `working_point_before_calibration.png` | CH1/CH2 校准前工作点随温度变化 | `../../data/source/temperature_compensation_source.xls`、`../../data/reference/working_point_before_calibration_plot_data.csv` |
| `working_point_after_calibration.png` | CH1/CH2 校准后工作点随温度变化 | 同一源表、`../../data/measured/working_point_after_calibration_plot_data.csv` |
| `sensitivity_before_calibration.png` | CH1/CH2 校准前峰值码随温度变化 | 同一源表、`../../data/reference/sensitivity_before_calibration_plot_data.csv` |
| `sensitivity_after_calibration.png` | CH1/CH2 校准后峰值码随温度变化 | 同一源表、`../../data/measured/sensitivity_after_calibration_plot_data.csv` |

**数据边界：**温度源表有 -40°C 到 150°C 的 9 个温度点。

“灵敏度图”当前纵轴采用前端输出峰值码，表示相对幅值变化新绘制的分度头误差图可由 `data/source/` 中原始 XLS 的 A/B/D/E 列逐点复算，分阶段表格分别在 `data/reference/` 与 `data/measured/`。

## Hall 输出实测波形

PWM 四档与 SENT 的示波器照片见 [hall_output/README.md](hall_output/README.md)。文件名中的 PWM 频率表示设定档位，具体测量边界见该说明。
