# 上板连接与运行说明

本说明对应本提交包中的 `src/constraints/angle_sensor_system.xdc`、`board/artifacts/angle_sensor_system_wrapper.bit`、`board/artifacts/angle_sensor_system_wrapper.xsa` 和 `board/artifacts/angle_sensor_app.elf`。以下引脚号是 FPGA 封装管脚号；开发板排针位置应以所用开发板的原理图核对。

## 硬件信息

| 项目 | 信息 |
| --- | --- |
| FPGA 器件 | `xc7z020clg400-1` |
| 开发板型号及版本 | AC720|
| 霍尔前端芯片型号/版本 | 待补充 |
| 霍尔前端供电电压 | 接线前核对前端输出电平与 FPGA IO 电平兼容 |
| 外部磁场来源及机械连接 |分度头和电机|
| PS 程序 | `board/artifacts/angle_sensor_app.elf` |
| 上位机 | `src/host/angle_sensor_ps_gui.py` |

## PL 与外设接线

下表来自提交的 XDC。所列端口的 IO 标准均为 `LVCMOS33`。

| FPGA 顶层端口 | FPGA 管脚 | 方向及连接 | 
| --- | --- | --- | --- |
| `DataIn_1_0` | L15 | 输入：霍尔前端 PDM 通道 1 | 
| `DataIn_2_0` | K14 | 输入：霍尔前端 PDM 通道 2 |
| `data_vaild_0` | J14 | 输入：PDM 数据有效信号，高电平时 CIC 接收输入位 | 
| `hall_out_0[0]` | G14 | 输出：PWM/SENT 信号；UVW 模式为 W，ABZ 模式为 Z，接示波器或接收设备 | 
| `UART_1_0_txd` | N20 | 输出：PS UART1，经 PL 引出；接串口模块 RX | 
| `UART_1_0_rxd` | P19 | 输入：PS UART1，经 PL 引出；接串口模块 TX | 


串口使用 **115200 baud、8 数据位、无校验、1 停止位**。本机测试时上位机选用 `COM14`；换电脑或串口模块后，以设备管理器显示的端口号为准。
## 启动与测试

1. 断电时核对电源、地线、PDM、`data_vaild_0`、UART TX/RX 和 Hall 输出接线；确认外设电平与 FPGA IO 兼容。
2. 给开发板及霍尔前端上电，连接 JTAG 和所用串口。用 Vivado Hardware Manager 将 `board/artifacts/angle_sensor_system_wrapper.bit` 下载到 FPGA。
3. 在 Vitis 中使用配套 XSA 平台运行 `board/artifacts/angle_sensor_app.elf`。如果启动了 Debug 会话，按 **Resume**，确认 CPU 不停在 `main()` 或断点。
4. 运行 `src/host/angle_sensor_ps_gui.py`，选择实际 COM 口（本机为 `COM14`），打开串口。连接检测应收到 PS ASCII 协议 v6 的响应。
5. 先读取状态或检查数据链，再输入 PDM 位流并确认 `data_vaild_0` 有效；观察 CIC、DSP 和最终角度采集结果。选择 PWM/SENT 模式时，可在 G14 测量 Hall 输出。
6. 将装置与接线照片放在 `board/setup/photos/`，并在该目录的 `README.md` 中说明可见内容；将上位机截图、示波器波形和实测输出放在 `board/results/`，角度参考值与测试数据放在 `data/`。每组结果注明日期、转速或分度角、采样设置及对应固件版本。



