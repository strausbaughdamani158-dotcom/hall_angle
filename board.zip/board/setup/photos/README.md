# Hardware setup photos

这些照片记录测试装置、板卡和接线外观，供复现实物搭建时参考。照片本身不能证明角度精度、温度补偿效果、Hall 输出或串口通信已经通过；对应数值和仪器截图应归档到 `../../results/` 和 `../../../data/`。

| 文件 | 可见内容 | 推荐用途 |
| --- | --- | --- |
| [indexing_head_view_01.jpg](indexing_head_view_01.jpg) | 分度头与卡盘正面 | 说明角度基准装置 |
| [indexing_head_view_02.jpg](indexing_head_view_02.jpg) | 分度头与卡盘全景 | 说明机械安装环境 |
| [indexing_head_view_03.jpg](indexing_head_view_03.jpg) | 分度头另一视角 | 补充刻度与夹持方式 |
| [test_rig_overview_01.jpg](test_rig_overview_01.jpg) | 电机、蓝色传感器板及 FPGA 开发板的整体摆放 | 报告中的系统实物图 |
| [test_rig_overview_02.jpg](test_rig_overview_02.jpg) | 同一装置的另一视角 | 补充接线走向 |
| [test_rig_side_view.jpg](test_rig_side_view.jpg) | 电机、传感器板与 FPGA 的侧面 | 说明相对位置 |
| [fpga_board_wiring.jpg](fpga_board_wiring.jpg) | FPGA 开发板和排针接线近景 | 配合 XDC 与接线表解释管脚 |
| [sensor_board_closeup.jpg](sensor_board_closeup.jpg) | 蓝色传感器板近景 | 说明前端板及连接器外观 |
| [stepper_motor_mount.jpg](stepper_motor_mount.jpg) | 步进电机和安装支架近景 | 说明电机固定方式 |

分度头照片与电机平台照片展示了两类装置，不能仅凭照片推定它们属于同一次测试。正式报告应为使用到的照片补充实际测试日期、板卡/前端版本、磁体位置、转速或分度角，以及哪些线连接到 `DataIn_1_0`、`DataIn_2_0`、`data_vaild_0` 和 GND。上表描述只基于照片可见内容，未把未拍到的连接或测量结果写成事实。
