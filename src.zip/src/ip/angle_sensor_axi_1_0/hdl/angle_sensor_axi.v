
`timescale 1 ns / 1 ps

	module angle_sensor_axi #
	(
		// Users to add parameters here

		// User parameters ends
		// Do not modify the parameters beyond this line


		// Parameters of Axi Slave Bus Interface S00_AXI
		parameter integer C_S00_AXI_DATA_WIDTH	= 32,
		parameter integer C_S00_AXI_ADDR_WIDTH	= 10
	)
	(
		// Users to add ports here
        input wire DataIn_1,
        input wire DataIn_2,
        input wire data_vaild,
        output wire [2:0] hall_out,

		// User ports ends
		// Do not modify the ports beyond this line


		// Ports of Axi Slave Bus Interface S00_AXI
		input wire  s00_axi_aclk,
		input wire  s00_axi_aresetn,
		input wire [C_S00_AXI_ADDR_WIDTH-1 : 0] s00_axi_awaddr,
		input wire [2 : 0] s00_axi_awprot,
		input wire  s00_axi_awvalid,
		output wire  s00_axi_awready,
		input wire [C_S00_AXI_DATA_WIDTH-1 : 0] s00_axi_wdata,
		input wire [(C_S00_AXI_DATA_WIDTH/8)-1 : 0] s00_axi_wstrb,
		input wire  s00_axi_wvalid,
		output wire  s00_axi_wready,
		output wire [1 : 0] s00_axi_bresp,
		output wire  s00_axi_bvalid,
		input wire  s00_axi_bready,
		input wire [C_S00_AXI_ADDR_WIDTH-1 : 0] s00_axi_araddr,
		input wire [2 : 0] s00_axi_arprot,
		input wire  s00_axi_arvalid,
		output wire  s00_axi_arready,
		output wire [C_S00_AXI_DATA_WIDTH-1 : 0] s00_axi_rdata,
		output wire [1 : 0] s00_axi_rresp,
		output wire  s00_axi_rvalid,
		input wire  s00_axi_rready
	);
	// ============================================================
// AXI -> PL control wires
// ============================================================

wire        offset_comp_en;
wire        sensitivity_comp_en;
wire        norm_en;
wire        phase_coarse_en;
wire        phase_fine_en;
wire        linear_en;
wire        dnc_en;

wire        fir_mode;
wire [2:0]  fre_ctrl;
wire [1:0]  hall_mode_select;
wire [1:0]  hall_pwm_freq_select;
wire [9:0]  tempin;

wire [7:0]  dnc_threshold;
wire [7:0]  dnc_alpha;

wire [13:0] norm_max_x;
wire [13:0] norm_min_x;
wire [13:0] norm_max_y;
wire [13:0] norm_min_y;

wire signed [15:0] phase_k_coarse;
wire        [15:0] phase_gain_coarse;

wire signed [15:0] phase_k_fine;
wire        [15:0] phase_gain_fine;

wire [15:0] zero;
// ============================================================
// Sensitivity / temperature / offset tables
// ============================================================

wire [9:0] parameter1_0;
wire [9:0] parameter1_1;
wire [9:0] parameter1_2;
wire [9:0] parameter1_3;
wire [9:0] parameter1_4;
wire [9:0] parameter1_5;
wire [9:0] parameter1_6;
wire [9:0] parameter1_7;
wire [9:0] parameter1_8;

wire [9:0] parameter2_0;
wire [9:0] parameter2_1;
wire [9:0] parameter2_2;
wire [9:0] parameter2_3;
wire [9:0] parameter2_4;
wire [9:0] parameter2_5;
wire [9:0] parameter2_6;
wire [9:0] parameter2_7;
wire [9:0] parameter2_8;

wire [9:0] temp0;
wire [9:0] temp1;
wire [9:0] temp2;
wire [9:0] temp3;
wire [9:0] temp4;
wire [9:0] temp5;
wire [9:0] temp6;
wire [9:0] temp7;
wire [9:0] temp8;

wire signed [13:0] offset1_param0;
wire signed [13:0] offset1_param1;
wire signed [13:0] offset1_param2;
wire signed [13:0] offset1_param3;
wire signed [13:0] offset1_param4;
wire signed [13:0] offset1_param5;
wire signed [13:0] offset1_param6;
wire signed [13:0] offset1_param7;
wire signed [13:0] offset1_param8;

wire signed [13:0] offset2_param0;
wire signed [13:0] offset2_param1;
wire signed [13:0] offset2_param2;
wire signed [13:0] offset2_param3;
wire signed [13:0] offset2_param4;
wire signed [13:0] offset2_param5;
wire signed [13:0] offset2_param6;
wire signed [13:0] offset2_param7;
wire signed [13:0] offset2_param8;
// ============================================================
// Linearization table
// ============================================================

wire [15:0] x0;
wire [15:0] x1;
wire [15:0] x2;
wire [15:0] x3;
wire [15:0] x4;
wire [15:0] x5;
wire [15:0] x6;
wire [15:0] x7;
wire [15:0] x8;
wire [15:0] x9;
wire [15:0] x10;
wire [15:0] x11;
wire [15:0] x12;
wire [15:0] x13;
wire [15:0] x14;
wire [15:0] x15;
wire [15:0] x16;
wire [15:0] x17;
wire [15:0] x18;
wire [15:0] x19;
wire [15:0] x20;
wire [15:0] x21;
wire [15:0] x22;
wire [15:0] x23;
wire [15:0] x24;
wire [15:0] x25;
wire [15:0] x26;
wire [15:0] x27;
wire [15:0] x28;
wire [15:0] x29;
wire [15:0] x30;
wire [15:0] x31;
wire [15:0] x32;
// ============================================================
// DSP monitor / status signals
// ============================================================

wire [13:0] raw_ch1_mon;
wire [13:0] raw_ch2_mon;

wire [13:0] offset_ch1_mon;
wire [13:0] offset_ch2_mon;

wire signed [13:0] current_offset1_mon;
wire signed [13:0] current_offset2_mon;

wire [13:0] temp_comp_ch1_mon;
wire [13:0] temp_comp_ch2_mon;

wire [13:0] filter_y_mon;
wire [13:0] filter_x_mon;
wire        filter_valid_mon;

wire [13:0] norm_y_mon;
wire [13:0] norm_x_mon;
wire        norm_valid_mon;

wire [13:0] coarse_y_mon;
wire [13:0] coarse_x_mon;
wire        coarse_valid_mon;

wire [13:0] phase_y_mon;
wire [13:0] phase_x_mon;
wire        phase_valid_mon;

wire [15:0] angle_raw_out;
wire        angle_raw_valid;

wire [15:0] angle_linear_out;
wire        angle_linear_valid;

wire [15:0] angle_final_out;
wire        angle_final_valid;

wire [31:0] filter_sample_seq;
wire [31:0] norm_sample_seq;
wire [31:0] phase_sample_seq;
wire [31:0] angle_sample_seq;

// ============================================================
// External two-channel CIC samples
// ============================================================

wire [13:0] cic_ch1;
wire [13:0] cic_ch2;
wire        cic_valid;

// Instantiation of Axi Bus Interface S00_AXI
	angle_sensor_axi_slave_lite_v1_0_S00_AXI # ( 
		.C_S_AXI_DATA_WIDTH(C_S00_AXI_DATA_WIDTH),
		.C_S_AXI_ADDR_WIDTH(C_S00_AXI_ADDR_WIDTH)
	) angle_sensor_axi_slave_lite_v1_0_S00_AXI_inst (
.offset_comp_en         (offset_comp_en),
.sensitivity_comp_en    (sensitivity_comp_en),

.norm_en                (norm_en),

.phase_coarse_en        (phase_coarse_en),
.phase_fine_en          (phase_fine_en),

.linear_en              (linear_en),
.dnc_en                 (dnc_en),

.fir_mode               (fir_mode),
.fre_ctrl               (fre_ctrl),
.hall_mode_select       (hall_mode_select),
.hall_pwm_freq_select   (hall_pwm_freq_select),
.tempin                  (tempin),

.dnc_threshold           (dnc_threshold),
.dnc_alpha               (dnc_alpha),

.norm_max_x              (norm_max_x),
.norm_min_x              (norm_min_x),
.norm_max_y              (norm_max_y),
.norm_min_y              (norm_min_y),

.phase_k_coarse          (phase_k_coarse),
.phase_gain_coarse       (phase_gain_coarse),

.phase_k_fine            (phase_k_fine),
.phase_gain_fine         (phase_gain_fine),

.zero                    (zero),
.parameter1_0 (parameter1_0),
.parameter1_1 (parameter1_1),
.parameter1_2 (parameter1_2),
.parameter1_3 (parameter1_3),
.parameter1_4 (parameter1_4),
.parameter1_5 (parameter1_5),
.parameter1_6 (parameter1_6),
.parameter1_7 (parameter1_7),
.parameter1_8 (parameter1_8),

.parameter2_0 (parameter2_0),
.parameter2_1 (parameter2_1),
.parameter2_2 (parameter2_2),
.parameter2_3 (parameter2_3),
.parameter2_4 (parameter2_4),
.parameter2_5 (parameter2_5),
.parameter2_6 (parameter2_6),
.parameter2_7 (parameter2_7),
.parameter2_8 (parameter2_8),

.temp0 (temp0),
.temp1 (temp1),
.temp2 (temp2),
.temp3 (temp3),
.temp4 (temp4),
.temp5 (temp5),
.temp6 (temp6),
.temp7 (temp7),
.temp8 (temp8),

.offset1_param0 (offset1_param0),
.offset1_param1 (offset1_param1),
.offset1_param2 (offset1_param2),
.offset1_param3 (offset1_param3),
.offset1_param4 (offset1_param4),
.offset1_param5 (offset1_param5),
.offset1_param6 (offset1_param6),
.offset1_param7 (offset1_param7),
.offset1_param8 (offset1_param8),

.offset2_param0 (offset2_param0),
.offset2_param1 (offset2_param1),
.offset2_param2 (offset2_param2),
.offset2_param3 (offset2_param3),
.offset2_param4 (offset2_param4),
.offset2_param5 (offset2_param5),
.offset2_param6 (offset2_param6),
.offset2_param7 (offset2_param7),
.offset2_param8 (offset2_param8),

.x0  (x0),
.x1  (x1),
.x2  (x2),
.x3  (x3),
.x4  (x4),
.x5  (x5),
.x6  (x6),
.x7  (x7),
.x8  (x8),
.x9  (x9),
.x10 (x10),
.x11 (x11),
.x12 (x12),
.x13 (x13),
.x14 (x14),
.x15 (x15),
.x16 (x16),
.x17 (x17),
.x18 (x18),
.x19 (x19),
.x20 (x20),
.x21 (x21),
.x22 (x22),
.x23 (x23),
.x24 (x24),
.x25 (x25),
.x26 (x26),
.x27 (x27),
.x28 (x28),
.x29 (x29),
.x30 (x30),
.x31 (x31),
.x32 (x32),
.hall_out_mon          (hall_out),
.cic_ch1_mon          (cic_ch1),
.cic_ch2_mon          (cic_ch2),
.cic_valid_mon   (cic_valid),

.raw_ch1_mon           (raw_ch1_mon),
.raw_ch2_mon           (raw_ch2_mon),

.offset_ch1_mon        (offset_ch1_mon),
.offset_ch2_mon        (offset_ch2_mon),

.current_offset1_mon   (current_offset1_mon),
.current_offset2_mon   (current_offset2_mon),

.temp_comp_ch1_mon     (temp_comp_ch1_mon),
.temp_comp_ch2_mon     (temp_comp_ch2_mon),

.filter_y_mon          (filter_y_mon),
.filter_x_mon          (filter_x_mon),
.filter_valid_mon      (filter_valid_mon),

.norm_y_mon            (norm_y_mon),
.norm_x_mon            (norm_x_mon),
.norm_valid_mon        (norm_valid_mon),

.coarse_y_mon          (coarse_y_mon),
.coarse_x_mon          (coarse_x_mon),
.coarse_valid_mon      (coarse_valid_mon),

.phase_y_mon           (phase_y_mon),
.phase_x_mon           (phase_x_mon),
.phase_valid_mon       (phase_valid_mon),

.angle_raw_out         (angle_raw_out),
.angle_raw_valid       (angle_raw_valid),

.angle_linear_out      (angle_linear_out),
.angle_linear_valid    (angle_linear_valid),

.angle_final_out       (angle_final_out),
.angle_final_valid     (angle_final_valid),

.filter_sample_seq     (filter_sample_seq),
.norm_sample_seq       (norm_sample_seq),
.phase_sample_seq      (phase_sample_seq),
.angle_sample_seq      (angle_sample_seq),
		.S_AXI_ACLK(s00_axi_aclk),
		.S_AXI_ARESETN(s00_axi_aresetn),
		.S_AXI_AWADDR(s00_axi_awaddr),
		.S_AXI_AWPROT(s00_axi_awprot),
		.S_AXI_AWVALID(s00_axi_awvalid),
		.S_AXI_AWREADY(s00_axi_awready),
		.S_AXI_WDATA(s00_axi_wdata),
		.S_AXI_WSTRB(s00_axi_wstrb),
		.S_AXI_WVALID(s00_axi_wvalid),
		.S_AXI_WREADY(s00_axi_wready),
		.S_AXI_BRESP(s00_axi_bresp),
		.S_AXI_BVALID(s00_axi_bvalid),
		.S_AXI_BREADY(s00_axi_bready),
		.S_AXI_ARADDR(s00_axi_araddr),
		.S_AXI_ARPROT(s00_axi_arprot),
		.S_AXI_ARVALID(s00_axi_arvalid),
		.S_AXI_ARREADY(s00_axi_arready),
		.S_AXI_RDATA(s00_axi_rdata),
		.S_AXI_RRESP(s00_axi_rresp),
		.S_AXI_RVALID(s00_axi_rvalid),
		.S_AXI_RREADY(s00_axi_rready)
	);
// ============================================================
// Two-channel external CIC acquisition
// ============================================================

wire [15:0] cic_dout1, cic_dout2;
wire [13:0] cic_ch0_avg, cic_ch1_avg;
wire cic_valid1, cic_valid2;
CIC_TOP u_cic_top (
    .DataIn_1 (DataIn_1),
    .DataIn_2 (DataIn_2),
    .data_vaild(data_vaild),
    .rst      (s00_axi_aresetn),
    .clk      (s00_axi_aclk),
    .Dout1    (cic_dout1),
    .Dout2    (cic_dout2),
    .ch0_avg  (cic_ch0_avg),
    .ch1_avg  (cic_ch1_avg),
    .valid1   (cic_valid1),
    .valid2   (cic_valid2)
);
// Keep the existing 0x300 status wiring: it now monitors CIC output.
assign cic_ch1 = cic_ch0_avg; // channel 1 / Y
assign cic_ch2 = cic_ch1_avg; // channel 2 / X
assign cic_valid = cic_valid1 & cic_valid2;
// ============================================================
// DSP core
//
// CH1 = Y / Sin
// CH2 = X / Cos
// ============================================================

DSP_TOP u_dsp_top (

    .sys_clk                 (s00_axi_aclk),
    .sys_rst_n               (s00_axi_aresetn),

    // ========================================================
    // CIC channel input
    // ========================================================
    .adc_ch1_in              (cic_ch1),
    .adc_ch2_in              (cic_ch2),

    .tempin                  (tempin),

    // ========================================================
    // Enable / configuration
    // ========================================================
    .offset_comp_en          (offset_comp_en),
    .sensitivity_comp_en     (sensitivity_comp_en),

    .norm_en                 (norm_en),

    .phase_coarse_en         (phase_coarse_en),
    .phase_fine_en           (phase_fine_en),

    .linear_en               (linear_en),
    .dnc_en                  (dnc_en),

 .fir_mode                (fir_mode),
.fre_ctrl                (fre_ctrl),

.hall_mode_select        (hall_mode_select),
.hall_pwm_freq_select    (hall_pwm_freq_select),

.dnc_threshold           (dnc_threshold),
.dnc_alpha               (dnc_alpha),

    // ========================================================
    // CH1 sensitivity
    // ========================================================
    .parameter1_0            (parameter1_0),
    .parameter1_1            (parameter1_1),
    .parameter1_2            (parameter1_2),
    .parameter1_3            (parameter1_3),
    .parameter1_4            (parameter1_4),
    .parameter1_5            (parameter1_5),
    .parameter1_6            (parameter1_6),
    .parameter1_7            (parameter1_7),
    .parameter1_8            (parameter1_8),

    // ========================================================
    // CH2 sensitivity
    // ========================================================
    .parameter2_0            (parameter2_0),
    .parameter2_1            (parameter2_1),
    .parameter2_2            (parameter2_2),
    .parameter2_3            (parameter2_3),
    .parameter2_4            (parameter2_4),
    .parameter2_5            (parameter2_5),
    .parameter2_6            (parameter2_6),
    .parameter2_7            (parameter2_7),
    .parameter2_8            (parameter2_8),

    // ========================================================
    // Temperature breakpoints
    // ========================================================
    .temp0                   (temp0),
    .temp1                   (temp1),
    .temp2                   (temp2),
    .temp3                   (temp3),
    .temp4                   (temp4),
    .temp5                   (temp5),
    .temp6                   (temp6),
    .temp7                   (temp7),
    .temp8                   (temp8),

    // ========================================================
    // CH1 operating-point offset
    // ========================================================
    .offset1_param0          (offset1_param0),
    .offset1_param1          (offset1_param1),
    .offset1_param2          (offset1_param2),
    .offset1_param3          (offset1_param3),
    .offset1_param4          (offset1_param4),
    .offset1_param5          (offset1_param5),
    .offset1_param6          (offset1_param6),
    .offset1_param7          (offset1_param7),
    .offset1_param8          (offset1_param8),

    // ========================================================
    // CH2 operating-point offset
    // ========================================================
    .offset2_param0          (offset2_param0),
    .offset2_param1          (offset2_param1),
    .offset2_param2          (offset2_param2),
    .offset2_param3          (offset2_param3),
    .offset2_param4          (offset2_param4),
    .offset2_param5          (offset2_param5),
    .offset2_param6          (offset2_param6),
    .offset2_param7          (offset2_param7),
    .offset2_param8          (offset2_param8),

    // ========================================================
    // Normalization
    // ========================================================
    .norm_max_x              (norm_max_x),
    .norm_min_x              (norm_min_x),
    .norm_max_y              (norm_max_y),
    .norm_min_y              (norm_min_y),

    // ========================================================
    // Phase coarse / fine
    // ========================================================
    .phase_k_coarse          (phase_k_coarse),
    .phase_gain_coarse       (phase_gain_coarse),

    .phase_k_fine            (phase_k_fine),
    .phase_gain_fine         (phase_gain_fine),

    .zero                    (zero),

    // ========================================================
    // 33-point linearization
    // ========================================================
    .x0                      (x0),
    .x1                      (x1),
    .x2                      (x2),
    .x3                      (x3),
    .x4                      (x4),
    .x5                      (x5),
    .x6                      (x6),
    .x7                      (x7),
    .x8                      (x8),
    .x9                      (x9),
    .x10                     (x10),
    .x11                     (x11),
    .x12                     (x12),
    .x13                     (x13),
    .x14                     (x14),
    .x15                     (x15),
    .x16                     (x16),
    .x17                     (x17),
    .x18                     (x18),
    .x19                     (x19),
    .x20                     (x20),
    .x21                     (x21),
    .x22                     (x22),
    .x23                     (x23),
    .x24                     (x24),
    .x25                     (x25),
    .x26                     (x26),
    .x27                     (x27),
    .x28                     (x28),
    .x29                     (x29),
    .x30                     (x30),
    .x31                     (x31),
    .x32                     (x32),

    // ========================================================
    // Monitor outputs
    // ========================================================
    .raw_ch1_mon             (raw_ch1_mon),
    .raw_ch2_mon             (raw_ch2_mon),

    .offset_ch1_mon          (offset_ch1_mon),
    .offset_ch2_mon          (offset_ch2_mon),

    .current_offset1_mon     (current_offset1_mon),
    .current_offset2_mon     (current_offset2_mon),

    .temp_comp_ch1_mon       (temp_comp_ch1_mon),
    .temp_comp_ch2_mon       (temp_comp_ch2_mon),

    .filter_y_mon            (filter_y_mon),
    .filter_x_mon            (filter_x_mon),
    .filter_valid_mon        (filter_valid_mon),

    .norm_y_mon              (norm_y_mon),
    .norm_x_mon              (norm_x_mon),
    .norm_valid_mon          (norm_valid_mon),

    .coarse_y_mon            (coarse_y_mon),
    .coarse_x_mon            (coarse_x_mon),
    .coarse_valid_mon        (coarse_valid_mon),

    .phase_y_mon             (phase_y_mon),
    .phase_x_mon             (phase_x_mon),
    .phase_valid_mon         (phase_valid_mon),

    .angle_raw_out           (angle_raw_out),
    .angle_raw_valid         (angle_raw_valid),

    .angle_linear_out        (angle_linear_out),
    .angle_linear_valid      (angle_linear_valid),

    .angle_final_out         (angle_final_out),
    .angle_final_valid       (angle_final_valid),

    .filter_sample_seq       (filter_sample_seq),
    .norm_sample_seq         (norm_sample_seq),
    .phase_sample_seq        (phase_sample_seq),
    .angle_sample_seq        (angle_sample_seq),

.hall_out                (hall_out)
);
	// Add user logic here
// ============================================================
// AXI -> PL control wires
// ============================================================


	// User logic ends

	endmodule
