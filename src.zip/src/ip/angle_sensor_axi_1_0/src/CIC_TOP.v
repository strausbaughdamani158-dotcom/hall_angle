`timescale 1ns/1ps
// rst active low; valid1/valid2 are one-clk CIC output pulses.
// Dout1/ch0_avg correspond to DataIn_1; Dout2/ch1_avg to DataIn_2.
module CIC_TOP #(
    parameter integer DEC = 2560,
    parameter integer ACC_WIDTH = 47,
    parameter [10:0] SCALE_NUM = 11'd1678,
    parameter integer SCALE_SHIFT = 40,
    parameter integer WARMUP_SAMPLES = 16
)(
    input  wire        DataIn_1,
    input  wire        DataIn_2,
    input  wire        data_vaild, // exact name requested: 1=accept one bit
    input  wire        rst,
    input  wire        clk,

    output wire [15:0] Dout1,
    output wire [15:0] Dout2,
    output wire [13:0] ch1_avg,
    output wire [13:0] ch0_avg,
    output wire        valid1,
    output wire        valid2
);

    // Preserve the 14-bit ports without an additional filter stage.
    assign ch0_avg = Dout1[15:2];
    assign ch1_avg = Dout2[15:2];

    CIC_256 #(
        .DEC(DEC), .ACC_WIDTH(ACC_WIDTH),
        .SCALE_NUM(SCALE_NUM), .SCALE_SHIFT(SCALE_SHIFT),
        .WARMUP_SAMPLES(WARMUP_SAMPLES)
    ) u_cic_1 (
        .DataIn(DataIn_1), .sample_en(data_vaild),
        .rst(rst), .clk(clk), .Dout(Dout1),
        .count(), .dec_valid(valid1)
    );

    CIC_256 #(
        .DEC(DEC), .ACC_WIDTH(ACC_WIDTH),
        .SCALE_NUM(SCALE_NUM), .SCALE_SHIFT(SCALE_SHIFT),
        .WARMUP_SAMPLES(WARMUP_SAMPLES)
    ) u_cic_2 (
        .DataIn(DataIn_2), .sample_en(data_vaild),
        .rst(rst), .clk(clk), .Dout(Dout2),
        .count(), .dec_valid(valid2)
    );
endmodule
