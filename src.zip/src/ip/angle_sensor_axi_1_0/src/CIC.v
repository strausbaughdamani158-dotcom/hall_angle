module CIC_256 #(
    parameter integer DEC         = 2560,
    parameter integer ACC_WIDTH   = 47,

    parameter [10:0]  SCALE_NUM   = 11'd1678,
    parameter integer SCALE_SHIFT = 40,

    parameter integer WARMUP_SAMPLES = 16,

    parameter integer GLITCH_REJECT_EN = 0,
    parameter [15:0]  GLITCH_TH = 16'd4096
)
(
    input  wire        DataIn,
    input  wire        rst,
    input  wire        clk,

    output wire [15:0] Dout,
    output reg  [12:0] count,
    output reg         dec_valid
);

    (* ASYNC_REG = "TRUE" *) reg DataIn_meta;
    (* ASYNC_REG = "TRUE" *) reg DataIn_sync;

    always @(posedge clk or negedge rst) begin
        if (!rst) begin
            DataIn_meta <= 1'b0;
            DataIn_sync <= 1'b0;
        end else begin
            DataIn_meta <= DataIn;
            DataIn_sync <= DataIn_meta;
        end
    end

    reg [ACC_WIDTH-1:0] sigma1;
    reg [ACC_WIDTH-1:0] sigma2;
    reg [ACC_WIDTH-1:0] sigma3;
    reg [ACC_WIDTH-1:0] sigma4;

    reg [ACC_WIDTH-1:0] sigma4_Dec;

    wire [ACC_WIDTH-1:0] din_ext;

    wire [ACC_WIDTH-1:0] sigma1_temp;
    wire [ACC_WIDTH-1:0] sigma2_temp;
    wire [ACC_WIDTH-1:0] sigma3_temp;
    wire [ACC_WIDTH-1:0] sigma4_temp;

    assign din_ext = {{(ACC_WIDTH-1){1'b0}}, DataIn_sync};

    assign sigma1_temp = sigma1 + din_ext;
    assign sigma2_temp = sigma2 + sigma1_temp;
    assign sigma3_temp = sigma3 + sigma2_temp;
    assign sigma4_temp = sigma4 + sigma3_temp;

    reg [ACC_WIDTH-1:0] delta1;
    reg [ACC_WIDTH-1:0] delta2;
    reg [ACC_WIDTH-1:0] delta3;
    reg [ACC_WIDTH-1:0] delta4;

    wire [ACC_WIDTH-1:0] delta1_temp;
    wire [ACC_WIDTH-1:0] delta2_temp;
    wire [ACC_WIDTH-1:0] delta3_temp;
    wire [ACC_WIDTH-1:0] delta4_temp;

    assign delta1_temp = sigma4_temp - sigma4_Dec;
    assign delta2_temp = delta1_temp - delta1;
    assign delta3_temp = delta2_temp - delta2;
    assign delta4_temp = delta3_temp - delta3;

    reg [ACC_WIDTH-1:0] DataOut;

    wire [ACC_WIDTH+10:0] scaled_mult;
    wire [ACC_WIDTH+10:0] scaled_shifted;
    wire                  sat_flag;
    wire [15:0]           cic_code_raw;

    assign scaled_mult    = delta4_temp * SCALE_NUM;
    assign scaled_shifted = scaled_mult >> SCALE_SHIFT;

    assign sat_flag = |scaled_shifted[ACC_WIDTH+10:16];

    assign cic_code_raw = sat_flag ? 16'hFFFF : scaled_shifted[15:0];

    reg [15:0] last_good_code;
    reg        last_good_valid;

    wire [16:0] diff_abs;

    assign diff_abs = (cic_code_raw >= last_good_code) ?
                      ({1'b0, cic_code_raw} - {1'b0, last_good_code}) :
                      ({1'b0, last_good_code} - {1'b0, cic_code_raw});

    wire glitch_detected;

    assign glitch_detected = (GLITCH_REJECT_EN != 0) &&
                             last_good_valid &&
                             (diff_abs > {1'b0, GLITCH_TH});

    wire [15:0] cic_code_clean;

    assign cic_code_clean = glitch_detected ? last_good_code : cic_code_raw;

    reg [15:0] ma_d0;
    reg [15:0] ma_d1;
    reg [15:0] ma_d2;
    reg [15:0] ma_d3;
    reg [15:0] ma_d4;
    reg [15:0] ma_d5;
    reg [15:0] ma_d6;
    reg [15:0] ma_d7;

    reg [18:0] ma_sum;
    wire [18:0] ma_sum_next;

    assign ma_sum_next = ma_sum
                       - {3'b000, ma_d7}
                       + {3'b000, cic_code_clean};

    reg [2:0] ma_cnt;
    reg       ma_full;

    reg [15:0] Dout_reg;
    assign Dout = Dout_reg;

    reg [7:0] warmup_cnt;

    always @(posedge clk or negedge rst) begin
        if (rst == 1'b0) begin
            sigma1     <= {ACC_WIDTH{1'b0}};
            sigma2     <= {ACC_WIDTH{1'b0}};
            sigma3     <= {ACC_WIDTH{1'b0}};
            sigma4     <= {ACC_WIDTH{1'b0}};

            delta1     <= {ACC_WIDTH{1'b0}};
            delta2     <= {ACC_WIDTH{1'b0}};
            delta3     <= {ACC_WIDTH{1'b0}};
            delta4     <= {ACC_WIDTH{1'b0}};

            sigma4_Dec <= {ACC_WIDTH{1'b0}};
            DataOut    <= {ACC_WIDTH{1'b0}};

            count      <= 13'd0;
            dec_valid  <= 1'b0;

            ma_d0      <= 16'd0;
            ma_d1      <= 16'd0;
            ma_d2      <= 16'd0;
            ma_d3      <= 16'd0;
            ma_d4      <= 16'd0;
            ma_d5      <= 16'd0;
            ma_d6      <= 16'd0;
            ma_d7      <= 16'd0;
            ma_sum     <= 19'd0;
            ma_cnt     <= 3'd0;
            ma_full    <= 1'b0;

            Dout_reg   <= 16'd0;
            warmup_cnt <= 8'd0;

            last_good_code  <= 16'd0;
            last_good_valid <= 1'b0;
        end else begin
            dec_valid <= 1'b0;

            if (count == DEC - 1) begin
                count <= 13'd0;

                sigma4_Dec <= sigma4_temp;

                delta1 <= delta1_temp;
                delta2 <= delta2_temp;
                delta3 <= delta3_temp;
                delta4 <= delta4_temp;

                DataOut <= delta4_temp;

                if (warmup_cnt < WARMUP_SAMPLES) begin
                    warmup_cnt <= warmup_cnt + 1'b1;

                    ma_d0   <= 16'd0;
                    ma_d1   <= 16'd0;
                    ma_d2   <= 16'd0;
                    ma_d3   <= 16'd0;
                    ma_d4   <= 16'd0;
                    ma_d5   <= 16'd0;
                    ma_d6   <= 16'd0;
                    ma_d7   <= 16'd0;
                    ma_sum  <= 19'd0;
                    ma_cnt  <= 3'd0;
                    ma_full <= 1'b0;

                    last_good_valid <= 1'b0;
                end else begin
                    ma_d0 <= cic_code_clean;
                    ma_d1 <= ma_d0;
                    ma_d2 <= ma_d1;
                    ma_d3 <= ma_d2;
                    ma_d4 <= ma_d3;
                    ma_d5 <= ma_d4;
                    ma_d6 <= ma_d5;
                    ma_d7 <= ma_d6;

                    ma_sum <= ma_sum_next;

                    if (!ma_full) begin
                        if (ma_cnt == 3'd7) begin
                            ma_full <= 1'b1;
                            ma_cnt  <= 3'd7;
                        end else begin
                            ma_cnt <= ma_cnt + 1'b1;
                        end
                    end

                    if (ma_full || (ma_cnt == 3'd7)) begin
                        Dout_reg <= ma_sum_next[18:3];

                        last_good_code  <= ma_sum_next[18:3];
                        last_good_valid <= 1'b1;

                        dec_valid <= 1'b1;
                    end
                end
            end else begin
                count <= count + 13'd1;
            end

            sigma1 <= sigma1_temp;
            sigma2 <= sigma2_temp;
            sigma3 <= sigma3_temp;
            sigma4 <= sigma4_temp;
        end
    end

endmodule