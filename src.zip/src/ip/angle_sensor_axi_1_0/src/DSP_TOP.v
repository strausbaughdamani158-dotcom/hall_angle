`timescale 1ns / 1ps

// ============================================================================
// Competition PL DSP core
//
// This version intentionally removes UART/EEPROM protocol control from PL.
// All enables/coefficients are explicit input ports and will be driven by the
// PS AXI-Lite register bank.  Real-time stage data are explicit output ports
// and will be read by PS through status registers.
//
// Processing order:
//   ADC -> operating-point compensation -> sensitivity compensation
//       -> median/average/CIC/FIR -> manual normalization
//       -> coarse phase correction -> fine phase correction -> CORDIC
//       -> 33-point linearization -> DNC
//
// Channel convention:
//   adc_ch1_in = Y / Sin
//   adc_ch2_in = X / Cos
// ============================================================================
module DSP_TOP (
    input  wire        sys_clk,
    input  wire        sys_rst_n,

    // ------------------------------------------------------------------------
    // Sensor input.  Acquisition (parallel ADC/SPI/PDM) is intentionally kept
    // outside this DSP core so the competition board can swap front ends.
    // ------------------------------------------------------------------------
    input  wire [13:0] adc_ch1_in,     // Y / Sin
    input  wire [13:0] adc_ch2_in,     // X / Cos
    input  wire [9:0]  tempin,

    // ------------------------------------------------------------------------
    // Stage enable/configuration registers from PS
    // ------------------------------------------------------------------------
    input  wire        offset_comp_en,
    input  wire        sensitivity_comp_en,
    input  wire        norm_en,
    input  wire        phase_coarse_en,
    input  wire        phase_fine_en,
    input  wire        linear_en,
    input  wire        dnc_en,

    input  wire        fir_mode,
    input  wire [2:0]  fre_ctrl,
    input  wire [7:0]  dnc_threshold,
    input  wire [7:0]  dnc_alpha,
// ------------------------------------------------------------------------
// Hall output configuration from PS AXI
// hall_mode_select = 2'b00 : PWM
// hall_mode_select = 2'b01 : SENT
// hall_mode_select = 2'b10 : UVW
// hall_mode_select = 2'b11 : ABZ
// ------------------------------------------------------------------------
input  wire [1:0]  hall_mode_select,
input  wire [1:0]  hall_pwm_freq_select,
    // ------------------------------------------------------------------------
    // CH1 sensitivity table, Q8: 256 = 1.0
    // ------------------------------------------------------------------------
    input  wire [9:0] parameter1_0,
    input  wire [9:0] parameter1_1,
    input  wire [9:0] parameter1_2,
    input  wire [9:0] parameter1_3,
    input  wire [9:0] parameter1_4,
    input  wire [9:0] parameter1_5,
    input  wire [9:0] parameter1_6,
    input  wire [9:0] parameter1_7,
    input  wire [9:0] parameter1_8,

    // CH2 sensitivity table
    input  wire [9:0] parameter2_0,
    input  wire [9:0] parameter2_1,
    input  wire [9:0] parameter2_2,
    input  wire [9:0] parameter2_3,
    input  wire [9:0] parameter2_4,
    input  wire [9:0] parameter2_5,
    input  wire [9:0] parameter2_6,
    input  wire [9:0] parameter2_7,
    input  wire [9:0] parameter2_8,

    // Temperature breakpoints.  temp0..temp8 correspond to 9 calibration pts.
    input  wire [9:0] temp0,
    input  wire [9:0] temp1,
    input  wire [9:0] temp2,
    input  wire [9:0] temp3,
    input  wire [9:0] temp4,
    input  wire [9:0] temp5,
    input  wire [9:0] temp6,
    input  wire [9:0] temp7,
    input  wire [9:0] temp8,

    // Signed operating-point correction table
    input  wire signed [13:0] offset1_param0,
    input  wire signed [13:0] offset1_param1,
    input  wire signed [13:0] offset1_param2,
    input  wire signed [13:0] offset1_param3,
    input  wire signed [13:0] offset1_param4,
    input  wire signed [13:0] offset1_param5,
    input  wire signed [13:0] offset1_param6,
    input  wire signed [13:0] offset1_param7,
    input  wire signed [13:0] offset1_param8,

    input  wire signed [13:0] offset2_param0,
    input  wire signed [13:0] offset2_param1,
    input  wire signed [13:0] offset2_param2,
    input  wire signed [13:0] offset2_param3,
    input  wire signed [13:0] offset2_param4,
    input  wire signed [13:0] offset2_param5,
    input  wire signed [13:0] offset2_param6,
    input  wire signed [13:0] offset2_param7,
    input  wire signed [13:0] offset2_param8,

    // Manual normalization parameters calculated by PS
    input  wire [13:0] norm_max_x,
    input  wire [13:0] norm_min_x,
    input  wire [13:0] norm_max_y,
    input  wire [13:0] norm_min_y,

    // Coarse/fine phase coefficients calculated by PS
    input  wire signed [15:0] phase_k_coarse,
    input  wire        [15:0] phase_gain_coarse,
    input  wire signed [15:0] phase_k_fine,
    input  wire        [15:0] phase_gain_fine,

    input  wire [15:0] zero,

    // 33-point linearization table calculated by PS
    input  wire [15:0] x0,
    input  wire [15:0] x1,
    input  wire [15:0] x2,
    input  wire [15:0] x3,
    input  wire [15:0] x4,
    input  wire [15:0] x5,
    input  wire [15:0] x6,
    input  wire [15:0] x7,
    input  wire [15:0] x8,
    input  wire [15:0] x9,
    input  wire [15:0] x10,
    input  wire [15:0] x11,
    input  wire [15:0] x12,
    input  wire [15:0] x13,
    input  wire [15:0] x14,
    input  wire [15:0] x15,
    input  wire [15:0] x16,
    input  wire [15:0] x17,
    input  wire [15:0] x18,
    input  wire [15:0] x19,
    input  wire [15:0] x20,
    input  wire [15:0] x21,
    input  wire [15:0] x22,
    input  wire [15:0] x23,
    input  wire [15:0] x24,
    input  wire [15:0] x25,
    input  wire [15:0] x26,
    input  wire [15:0] x27,
    input  wire [15:0] x28,
    input  wire [15:0] x29,
    input  wire [15:0] x30,
    input  wire [15:0] x31,
    input  wire [15:0] x32,

    // ------------------------------------------------------------------------
    // Status/monitor outputs to PS
    // ------------------------------------------------------------------------
    output wire [13:0] raw_ch1_mon,
    output wire [13:0] raw_ch2_mon,

    output wire [13:0] offset_ch1_mon,
    output wire [13:0] offset_ch2_mon,
    output wire signed [13:0] current_offset1_mon,
    output wire signed [13:0] current_offset2_mon,

    output wire [13:0] temp_comp_ch1_mon,
    output wire [13:0] temp_comp_ch2_mon,

    output wire [13:0] filter_y_mon,
    output wire [13:0] filter_x_mon,
    output wire        filter_valid_mon,

    output wire [13:0] norm_y_mon,
    output wire [13:0] norm_x_mon,
    output wire        norm_valid_mon,

    output wire [13:0] coarse_y_mon,
    output wire [13:0] coarse_x_mon,
    output wire        coarse_valid_mon,

    output wire [13:0] phase_y_mon,
    output wire [13:0] phase_x_mon,
    output wire        phase_valid_mon,

    output wire [15:0] angle_raw_out,
    output wire        angle_raw_valid,
    output wire [15:0] angle_linear_out,
    output wire        angle_linear_valid,
    output wire [15:0] angle_final_out,
    output wire        angle_final_valid,

    // Sequence counters. PS polls these counters to detect a new sample and
    // then reads the corresponding latest-value registers. No FIFO is needed.
    output reg  [31:0] filter_sample_seq,
    output reg  [31:0] norm_sample_seq,
    output reg  [31:0] phase_sample_seq,
    output reg  [31:0] angle_sample_seq,

// ------------------------------------------------------------------------
// Hall physical output
// ------------------------------------------------------------------------
output wire [2:0]  hall_out
);

// ---------------------------------------------------------------------------
// Reset synchronization in the PL processing clock domain
// ---------------------------------------------------------------------------
reg rst_n_sync1;
reg rst_n_sync2;
always @(posedge sys_clk or negedge sys_rst_n) begin
    if (!sys_rst_n) begin
        rst_n_sync1 <= 1'b0;
        rst_n_sync2 <= 1'b0;
    end else begin
        rst_n_sync1 <= 1'b1;
        rst_n_sync2 <= rst_n_sync1;
    end
end

assign raw_ch1_mon = adc_ch1_in;
assign raw_ch2_mon = adc_ch2_in;

// ---------------------------------------------------------------------------
// 1. Temperature / operating-point compensation
// ---------------------------------------------------------------------------
wire [13:0] temp_comp_ch1;
wire [13:0] temp_comp_ch2;

temp_eeprom_top u_temp_comp (
    .clk        (sys_clk),
    .rst_n      (rst_n_sync2),
    .entp       (sensitivity_comp_en),
    .enof       (offset_comp_en),

    .parameter1_0(parameter1_0), .parameter1_1(parameter1_1),
    .parameter1_2(parameter1_2), .parameter1_3(parameter1_3),
    .parameter1_4(parameter1_4), .parameter1_5(parameter1_5),
    .parameter1_6(parameter1_6), .parameter1_7(parameter1_7),
    .parameter1_8(parameter1_8),

    .parameter2_0(parameter2_0), .parameter2_1(parameter2_1),
    .parameter2_2(parameter2_2), .parameter2_3(parameter2_3),
    .parameter2_4(parameter2_4), .parameter2_5(parameter2_5),
    .parameter2_6(parameter2_6), .parameter2_7(parameter2_7),
    .parameter2_8(parameter2_8),

    .offset1_param0(offset1_param0), .offset1_param1(offset1_param1),
    .offset1_param2(offset1_param2), .offset1_param3(offset1_param3),
    .offset1_param4(offset1_param4), .offset1_param5(offset1_param5),
    .offset1_param6(offset1_param6), .offset1_param7(offset1_param7),
    .offset1_param8(offset1_param8),

    .offset2_param0(offset2_param0), .offset2_param1(offset2_param1),
    .offset2_param2(offset2_param2), .offset2_param3(offset2_param3),
    .offset2_param4(offset2_param4), .offset2_param5(offset2_param5),
    .offset2_param6(offset2_param6), .offset2_param7(offset2_param7),
    .offset2_param8(offset2_param8),

    .temp1(temp0), .temp2(temp1), .temp3(temp2),
    .temp4(temp3), .temp5(temp4), .temp6(temp5),
    .temp7(temp6), .temp8(temp7), .temp9(temp8),

    .data_in1(adc_ch1_in),
    .data_in2(adc_ch2_in),
    .tpout1  (temp_comp_ch1),
    .tpout2  (temp_comp_ch2),

    .offset_comp_out1(offset_ch1_mon),
    .offset_comp_out2(offset_ch2_mon),
    .current_offset1_mon(current_offset1_mon),
    .current_offset2_mon(current_offset2_mon),

    .tempin(tempin)
);

assign temp_comp_ch1_mon = temp_comp_ch1;
assign temp_comp_ch2_mon = temp_comp_ch2;

// ---------------------------------------------------------------------------
// 2. Filter -> normalization -> coarse/fine phase -> CORDIC
// ---------------------------------------------------------------------------
FIR_PHASE_NORM_CORDIC #(
    .DATA_WIDTH(14),
    .K_WIDTH   (16)
) u_angle_dsp (
    .clk               (sys_clk),
    .rst_n             (rst_n_sync2),

    .fir_mode          (fir_mode),
    .fre_ctrl          (fre_ctrl),

    .norm_en           (norm_en),
    .manual_max_x      (norm_max_x),
    .manual_min_x      (norm_min_x),
    .manual_max_y      (norm_max_y),
    .manual_min_y      (norm_min_y),

    .phase_coarse_en   (phase_coarse_en),
    .manual_k_coarse   (phase_k_coarse),
    .manual_gain_coarse(phase_gain_coarse),

    .phase_fine_en     (phase_fine_en),
    .manual_k_fine     (phase_k_fine),
    .manual_gain_fine  (phase_gain_fine),

    .data_in1          (temp_comp_ch1),
    .data_in2          (temp_comp_ch2),
    .zero              (zero),

    .angle_raw         (angle_raw_out),
    .angle_valid       (angle_raw_valid),

    .filter_out_y      (filter_y_mon),
    .filter_out_x      (filter_x_mon),
    .filter_valid_out  (filter_valid_mon),

    .norm_out_y        (norm_y_mon),
    .norm_out_x        (norm_x_mon),
    .norm_valid_out    (norm_valid_mon),

    .coarse_out_y      (coarse_y_mon),
    .coarse_out_x      (coarse_x_mon),
    .coarse_valid_out  (coarse_valid_mon),

    .calib_out_y       (phase_y_mon),
    .calib_out_x       (phase_x_mon),
    .phase_valid_out   (phase_valid_mon)
);

// ---------------------------------------------------------------------------
// 3. 33-point angle linearization
// ---------------------------------------------------------------------------
Linearization #(
    .DATA_WIDTH(16),
    .STEP      (32'd2250)
) u_linearization (
    .clk                  (sys_clk),
    .rst_n                (rst_n_sync2),
    .en                   (linear_en),
    .i_valid              (angle_raw_valid),
    .datain_Linearization (angle_raw_out),

    .x0(x0), .x1(x1), .x2(x2), .x3(x3), .x4(x4), .x5(x5), .x6(x6), .x7(x7),
    .x8(x8), .x9(x9), .x10(x10), .x11(x11), .x12(x12), .x13(x13), .x14(x14), .x15(x15),
    .x16(x16), .x17(x17), .x18(x18), .x19(x19), .x20(x20), .x21(x21), .x22(x22), .x23(x23),
    .x24(x24), .x25(x25), .x26(x26), .x27(x27), .x28(x28), .x29(x29), .x30(x30), .x31(x31),
    .x32(x32),

    .data_out             (angle_linear_out),
    .o_valid              (angle_linear_valid)
);

// ---------------------------------------------------------------------------
// 4. Optional DNC output smoothing
// ---------------------------------------------------------------------------
dnc_filter u_dnc_filter (
    .clk          (sys_clk),
    .rst_n        (rst_n_sync2),
    .enable       (dnc_en),
    .sample_valid (angle_linear_valid),
    .angle_in     (angle_linear_out),
    .dnc_threshold(dnc_threshold),
    .dnc_alpha    (dnc_alpha),
    .angle_out    (angle_final_out),
    .o_valid      (angle_final_valid)
);

// ---------------------------------------------------------------------------
// Sequence counters for PS polling.  They naturally wrap at 2^32.
// ---------------------------------------------------------------------------
always @(posedge sys_clk or negedge rst_n_sync2) begin
    if (!rst_n_sync2) begin
        filter_sample_seq <= 32'd0;
        norm_sample_seq   <= 32'd0;
        phase_sample_seq  <= 32'd0;
        angle_sample_seq  <= 32'd0;
    end else begin
        if (filter_valid_mon)
            filter_sample_seq <= filter_sample_seq + 32'd1;
        if (norm_valid_mon)
            norm_sample_seq <= norm_sample_seq + 32'd1;
        if (phase_valid_mon)
            phase_sample_seq <= phase_sample_seq + 32'd1;
        if (angle_final_valid)
            angle_sample_seq <= angle_sample_seq + 32'd1;
    end
end
// ---------------------------------------------------------------------------
// 5. Hall output interface
//
// angle_final_out : 0 ~ 36000
//                   0.01 degree / LSB
//
// hall_mode_select:
//      00 -> PWM
//      01 -> SENT
//      10 -> UVW: hall_out[2:0] = {U, V, W}
//      11 -> ABZ: hall_out[2:0] = {A, B, Z}
// PWM/SENT use hall_out[0]; hall_out[2:1] are zero.
//
// hall_pwm_freq_select:
//      00 -> 50 Hz
//      01 -> 500 Hz
//      10 -> 2000 Hz
//      11 -> 4000 Hz
// ---------------------------------------------------------------------------

hall_interface #(
    .CLK_FREQ_HZ(10000000)
) u_hall_interface (
    .clk            (sys_clk),
    .rst_n          (rst_n_sync2),

    .mode_select    (hall_mode_select),
    .pwm_freq_select(hall_pwm_freq_select),

    .phase          (angle_final_out),

    .data_out       (hall_out)
);
endmodule
