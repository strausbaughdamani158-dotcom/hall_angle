`timescale 1ns / 1ps

module sincos_generator #(
    parameter integer DATA_WIDTH = 14
)(
    input  wire                 clk,
    input  wire                 rst_n,

    input  wire                 enable,

    // ============================================================
    // DDS frequency control word
    //
    // fout = freq_word * fclk / 2^32
    //
    // fclk = 10 MHz
    // ============================================================
    input  wire [31:0]          freq_word,

    // ============================================================
    // Relative phase error
    //
    // 16'h0000 = 0 deg error
    // 16'h4000 = +90 deg
    // 16'h8000 = +180 deg
    // 16'hC000 = +270 deg
    //
    // COS phase = SIN phase + 90deg + phase_error
    // ============================================================
    input  wire [15:0]          phase_error,

    output reg  [DATA_WIDTH-1:0] sin_out,
    output reg  [DATA_WIDTH-1:0] cos_out,

    output reg                   data_valid
);

    // ============================================================
    // 32-bit DDS phase accumulator
    // ============================================================

    reg [31:0] phase_acc;

    wire [31:0] sin_phase;
    wire [31:0] cos_phase;

    wire [31:0] phase_error_32;

    assign phase_error_32 = {
        phase_error,
        16'd0
    };

    assign sin_phase = phase_acc;

    // 0x40000000 = 90 degrees
    assign cos_phase =
        phase_acc +
        32'h40000000 +
        phase_error_32;


    // ============================================================
    // Use upper 8 bits as LUT address
    // 256 samples / electrical period
    // ============================================================

    wire [7:0] sin_addr;
    wire [7:0] cos_addr;

    assign sin_addr = sin_phase[31:24];
    assign cos_addr = cos_phase[31:24];


    // ============================================================
    // Signed sine LUT result
    //
    // Range approximately:
    // -7000 ~ +7000
    // ============================================================

    wire signed [13:0] sin_signed;
    wire signed [13:0] cos_signed;

    sine_lut_256 u_sin_lut (
        .addr (sin_addr),
        .dout (sin_signed)
    );

    sine_lut_256 u_cos_lut (
        .addr (cos_addr),
        .dout (cos_signed)
    );


    // ============================================================
    // Convert signed waveform into 14-bit Offset Binary
    //
    // center = 8192
    // ============================================================

    wire signed [14:0] sin_offset_calc;
    wire signed [14:0] cos_offset_calc;

    assign sin_offset_calc =
        $signed({sin_signed[13], sin_signed}) +
        15'sd8192;

    assign cos_offset_calc =
        $signed({cos_signed[13], cos_signed}) +
        15'sd8192;


    // ============================================================
    // DDS accumulator
    // ============================================================

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            phase_acc <= 32'd0;
        end
        else begin
            if (enable) begin
                phase_acc <= phase_acc + freq_word;
            end
            else begin
                phase_acc <= phase_acc;
            end
        end
    end


    // ============================================================
    // Output register
    // ============================================================

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            sin_out    <= 14'd8192;
            cos_out    <= 14'd8192;
            data_valid <= 1'b0;
        end
        else begin

            if (enable) begin

                if (sin_offset_calc < 15'sd0)
                    sin_out <= 14'd0;
                else if (sin_offset_calc > 15'sd16383)
                    sin_out <= 14'd16383;
                else
                    sin_out <= sin_offset_calc[13:0];


                if (cos_offset_calc < 15'sd0)
                    cos_out <= 14'd0;
                else if (cos_offset_calc > 15'sd16383)
                    cos_out <= 14'd16383;
                else
                    cos_out <= cos_offset_calc[13:0];


                data_valid <= 1'b1;
            end
            else begin
                sin_out    <= 14'd8192;
                cos_out    <= 14'd8192;
                data_valid <= 1'b0;
            end

        end
    end

endmodule
module sine_lut_256 (
    input  wire [7:0]         addr,
    output wire signed [13:0] dout
);

    wire [1:0] quadrant;
    wire [5:0] index;

    reg  [5:0] lut_addr;
    reg        negative;

    reg signed [13:0] magnitude;


    assign quadrant = addr[7:6];
    assign index    = addr[5:0];


    always @(*) begin

        lut_addr = 6'd0;
        negative = 1'b0;

        case (quadrant)

            2'b00: begin
                lut_addr = index;
                negative = 1'b0;
            end

            2'b01: begin
                lut_addr = 6'd63 - index;
                negative = 1'b0;
            end

            2'b10: begin
                lut_addr = index;
                negative = 1'b1;
            end

            2'b11: begin
                lut_addr = 6'd63 - index;
                negative = 1'b1;
            end

            default: begin
                lut_addr = 6'd0;
                negative = 1'b0;
            end

        endcase
    end


    always @(*) begin

        case (lut_addr)

            6'd0  : magnitude = 14'sd0;
            6'd1  : magnitude = 14'sd172;
            6'd2  : magnitude = 14'sd343;
            6'd3  : magnitude = 14'sd515;
            6'd4  : magnitude = 14'sd686;
            6'd5  : magnitude = 14'sd857;
            6'd6  : magnitude = 14'sd1027;
            6'd7  : magnitude = 14'sd1197;

            6'd8  : magnitude = 14'sd1366;
            6'd9  : magnitude = 14'sd1534;
            6'd10 : magnitude = 14'sd1701;
            6'd11 : magnitude = 14'sd1867;
            6'd12 : magnitude = 14'sd2031;
            6'd13 : magnitude = 14'sd2194;
            6'd14 : magnitude = 14'sd2356;
            6'd15 : magnitude = 14'sd2515;

            6'd16 : magnitude = 14'sd2673;
            6'd17 : magnitude = 14'sd2829;
            6'd18 : magnitude = 14'sd2983;
            6'd19 : magnitude = 14'sd3135;
            6'd20 : magnitude = 14'sd3284;
            6'd21 : magnitude = 14'sd3432;
            6'd22 : magnitude = 14'sd3576;
            6'd23 : magnitude = 14'sd3718;

            6'd24 : magnitude = 14'sd3858;
            6'd25 : magnitude = 14'sd3994;
            6'd26 : magnitude = 14'sd4128;
            6'd27 : magnitude = 14'sd4258;
            6'd28 : magnitude = 14'sd4386;
            6'd29 : magnitude = 14'sd4510;
            6'd30 : magnitude = 14'sd4631;
            6'd31 : magnitude = 14'sd4749;

            6'd32 : magnitude = 14'sd4863;
            6'd33 : magnitude = 14'sd4974;
            6'd34 : magnitude = 14'sd5082;
            6'd35 : magnitude = 14'sd5186;
            6'd36 : magnitude = 14'sd5286;
            6'd37 : magnitude = 14'sd5383;
            6'd38 : magnitude = 14'sd5476;
            6'd39 : magnitude = 14'sd5565;

            6'd40 : magnitude = 14'sd5650;
            6'd41 : magnitude = 14'sd5732;
            6'd42 : magnitude = 14'sd5809;
            6'd43 : magnitude = 14'sd5882;
            6'd44 : magnitude = 14'sd5952;
            6'd45 : magnitude = 14'sd6017;
            6'd46 : magnitude = 14'sd6078;
            6'd47 : magnitude = 14'sd6135;

            6'd48 : magnitude = 14'sd6187;
            6'd49 : magnitude = 14'sd6236;
            6'd50 : magnitude = 14'sd6280;
            6'd51 : magnitude = 14'sd6320;
            6'd52 : magnitude = 14'sd6356;
            6'd53 : magnitude = 14'sd6387;
            6'd54 : magnitude = 14'sd6414;
            6'd55 : magnitude = 14'sd6437;

            6'd56 : magnitude = 14'sd6455;
            6'd57 : magnitude = 14'sd6469;
            6'd58 : magnitude = 14'sd6478;
            6'd59 : magnitude = 14'sd6483;
            6'd60 : magnitude = 14'sd6483;
            6'd61 : magnitude = 14'sd6479;
            6'd62 : magnitude = 14'sd6470;
            6'd63 : magnitude = 14'sd6457;

            default:
                magnitude = 14'sd0;

        endcase
    end


    assign dout =
        negative ? -magnitude : magnitude;

endmodule