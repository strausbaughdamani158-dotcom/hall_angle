//====================================================================
// \u9876\u5c42\u6a21\u5757\uff1ahall_interface
//====================================================================
`timescale 1ns / 1ps


module hall_interface #(
    parameter integer CLK_FREQ_HZ = 10000000
)(
    input clk,
    input rst_n,

    // 00 PWM
    // 01 SENT
    // 10 UVW
    // 11 ABZ
    input [1:0] mode_select,

    input [1:0] pwm_freq_select,


    // 角度输入
    // 0~36000
    input [15:0] phase,


    // 三线输出
    output [2:0] data_out
);



wire PWM1_out;

wire SENT1_out;


wire [2:0] UVW_out;

wire [2:0] ABZ_out;



//============================================================
// PWM
//============================================================

PWM_program #(
    .CLK_FREQ_HZ(CLK_FREQ_HZ)
)
PWM1
(
    .clk(clk),
    .rst_n(rst_n),

    .phase(phase),

    .freq_select(pwm_freq_select),

    .PWM_out(PWM1_out)
);




//============================================================
// SENT
//============================================================


SENT #(
    .CLK_FREQ_HZ(CLK_FREQ_HZ)
)
SENT1
(
    .clk(clk),

    .rst_n(rst_n),

    .phase(phase),

    .sent_out(SENT1_out),

    .period_test(),

    .nlow_test()
);





//============================================================
// UVW编码器
//============================================================


wire U;
wire V;
wire W;



UVW UVW1
(
    .clk(clk),

    .rst_n(rst_n),

    .phase_in(phase),

    .U(U),

    .V(V),

    .W(W)
);


assign UVW_out = {U,V,W};





//============================================================
// ABZ编码器
//============================================================


wire A;
wire B;
wire Z;



ABZ ABZ1
(
    .clk(clk),

    .rst_n(rst_n),

    .phase(phase),

    .A(A),

    .B(B),

    .Z(Z)
);


assign ABZ_out = {A,B,Z};





//============================================================
// 输出选择
//============================================================


output_select sel1
(
    .clk(clk),

    .rst_n(rst_n),

    .select(mode_select),


    .PWM1(PWM1_out),

    .SENT1(SENT1_out),

    .UVW1(UVW_out),

    .ABZ1(ABZ_out),


    .data_out(data_out)

);



endmodule

//====================================================================
// \u8f93\u51fa\u9009\u62e9\u6a21\u5757 (\u4fdd\u6301\u4e0d\u53d8)
//====================================================================
module output_select(

    input clk,

    input rst_n,


    input [1:0] select,


    input PWM1,

    input SENT1,

    input [2:0] UVW1,

    input [2:0] ABZ1,


    output reg [2:0] data_out

);



always @(posedge clk or negedge rst_n)

begin

    if(!rst_n)

    begin

        data_out <= 3'b000;

    end


    else

    begin

        case(select)


        // PWM
        2'b00:

            data_out <= {2'b00,PWM1};



        // SENT
        2'b01:

            data_out <= {2'b00,SENT1};



        // UVW
        2'b10:

            data_out <= UVW1;



        // ABZ
        2'b11:

            data_out <= ABZ1;



        default:

            data_out <= 3'b000;


        endcase

    end


end


endmodule


//====================================================================
// CRC \u6a21\u5757 (\u4fee\u590d\u4e86\u539f\u7248\u9ad84\u4f4d\u4e22\u5931\u7684BUG\uff0c\u5e76\u6269\u5c55\u9002\u5e94 16-bit)
//====================================================================
module CRC(
    input sys_clk,
    input sys_rst_n,
    input crc_rst,
    input [15:0] data_in,     // \u3010\u4fee\u6539\u3011 12 -> 16
    output reg flag,
    output reg [3:0] crc_out, 
    output reg [19:0] data_out // \u3010\u4fee\u6539\u3011 16 -> 20 (16\u4f4d\u6570\u636e+4\u4f4dCRC)
);
    reg [19:0] data_in_reg;    // \u3010\u4fee\u6539\u3011 \u7f13\u51b2\u6c60 16 -> 20
    reg [15:0] data_latched;
    localparam gx_crc_5 = 5'b11101; // p(x) = x^4 + x^3 + x^2 + 1
   
    always @(posedge sys_clk or negedge sys_rst_n) begin
        if(!sys_rst_n) begin
            crc_out     <= 4'd0;
            flag        <= 1'b0;
            data_in_reg <= 20'd0;
            data_latched <= 16'd0;
            data_out    <= 20'd0;
        end   
        else if (!crc_rst) begin
            crc_out     <= 4'd0;
            flag        <= 1'b0;
            data_in_reg <= {data_in, 4'b000};
            data_latched <= data_in;
        end
        else begin
            // \u3010\u4fee\u6539\u3011\u4fee\u590d\u5f02\u6216\u6f0f\u6d1e\uff0c\u4ece\u6700\u9ad8\u4f4d [19] \u5b8c\u6574\u6821\u9a8c\u5230 [4]
            if     (data_in_reg[19] == 1'b1) data_in_reg[19:15] <= data_in_reg[19:15] ^ gx_crc_5;
            else if(data_in_reg[18] == 1'b1) data_in_reg[18:14] <= data_in_reg[18:14] ^ gx_crc_5;
            else if(data_in_reg[17] == 1'b1) data_in_reg[17:13] <= data_in_reg[17:13] ^ gx_crc_5;
            else if(data_in_reg[16] == 1'b1) data_in_reg[16:12] <= data_in_reg[16:12] ^ gx_crc_5;
            else if(data_in_reg[15] == 1'b1) data_in_reg[15:11] <= data_in_reg[15:11] ^ gx_crc_5;
            else if(data_in_reg[14] == 1'b1) data_in_reg[14:10] <= data_in_reg[14:10] ^ gx_crc_5;
            else if(data_in_reg[13] == 1'b1) data_in_reg[13:9]  <= data_in_reg[13:9]  ^ gx_crc_5;
            else if(data_in_reg[12] == 1'b1) data_in_reg[12:8]  <= data_in_reg[12:8]  ^ gx_crc_5;
            else if(data_in_reg[11] == 1'b1) data_in_reg[11:7]  <= data_in_reg[11:7]  ^ gx_crc_5;
            else if(data_in_reg[10] == 1'b1) data_in_reg[10:6]  <= data_in_reg[10:6]  ^ gx_crc_5;
            else if(data_in_reg[9]  == 1'b1) data_in_reg[9:5]   <= data_in_reg[9:5]   ^ gx_crc_5;
            else if(data_in_reg[8]  == 1'b1) data_in_reg[8:4]   <= data_in_reg[8:4]   ^ gx_crc_5;
            else if(data_in_reg[7]  == 1'b1) data_in_reg[7:3]   <= data_in_reg[7:3]   ^ gx_crc_5;
            else if(data_in_reg[6]  == 1'b1) data_in_reg[6:2]   <= data_in_reg[6:2]   ^ gx_crc_5;
            else if(data_in_reg[5]  == 1'b1) data_in_reg[5:1]   <= data_in_reg[5:1]   ^ gx_crc_5;
            else if(data_in_reg[4]  == 1'b1) data_in_reg[4:0]   <= data_in_reg[4:0]   ^ gx_crc_5;
            else begin 
                crc_out  <= data_in_reg[3:0];
                data_out <= {data_latched, data_in_reg[3:0]};
                flag     <= 1'b1;
            end
        end
    end
endmodule


//====================================================================
// PWM \u7a0b\u5e8f\u6a21\u5757 (\u7f29\u653e\u7b97\u6cd5\u5339\u914d 16-bit \u4ee5\u53ca\u65b0\u9891\u7387\u8981\u6c42)
//====================================================================
module PWM_program #(
    parameter integer CLK_FREQ_HZ = 10000000
)(
    input clk,
    input rst_n,
    input [15:0] phase,       // \u3010\u4fee\u6539\u3011 14 -> 16
    input [1:0] freq_select,  
    output reg PWM_out
);

    reg [19:0] count_norm;
    reg [19:0] phase_count;
    reg [19:0] PWM_freq_N_clk;
    reg [19:0] requested_period;
    reg [19:0] requested_phase_count;

    localparam integer PERIOD_50HZ   = CLK_FREQ_HZ / 50;
    localparam integer PERIOD_500HZ  = CLK_FREQ_HZ / 500;
    localparam integer PERIOD_2000HZ = CLK_FREQ_HZ / 2000;
    localparam integer PERIOD_4000HZ = CLK_FREQ_HZ / 4000;

    wire [15:0] phase_limited = (phase > 16'd36000) ? 16'd36000 : phase;

    always @(*) begin
        case(freq_select)
            2'd0: requested_period = PERIOD_50HZ;
            2'd1: requested_period = PERIOD_500HZ;
            2'd2: requested_period = PERIOD_2000HZ;
            2'd3: requested_period = PERIOD_4000HZ;
            default: requested_period = PERIOD_50HZ;
        endcase

        // Explicit 36-bit operands prevent multiplication truncation.
        requested_phase_count =
            ({20'd0, phase_limited} * {16'd0, requested_period}) / 36'd36000;
    end

    // Commit frequency and duty only on a PWM frame boundary.
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            PWM_freq_N_clk <= PERIOD_50HZ;
            phase_count    <= 20'd0;
        end else if ((count_norm == 20'd0) ||
                     (count_norm >= PWM_freq_N_clk - 20'd1)) begin
            PWM_freq_N_clk <= requested_period;
            phase_count    <= requested_phase_count;
        end
    end

    always@(posedge clk or negedge rst_n) begin
        if(!rst_n)
            count_norm <= 20'b0;
        else if(count_norm >= PWM_freq_N_clk - 20'd1)
            count_norm <= 20'd0;
        else  
            count_norm <= count_norm + 20'd1;
    end

    always@(posedge clk or negedge rst_n) begin
        if(!rst_n)
            PWM_out <= 1'b0;
        else if((phase_count != 0) && (count_norm < phase_count))  
            PWM_out <= 1'b1;
        else 
            PWM_out <= 1'b0;
    end
endmodule



//====================================================================
// \u81ea\u5b9a\u4e49\u4e32\u884c\u5e27\u6a21\u5757\uff08\u4fdd\u6301\u539f\u6709\u7ebf\u8def\u683c\u5f0f\uff1b\u5e76\u975e SAE J2716 SENT \u7f16\u7801\uff09
//====================================================================
`timescale 1ns / 1ps
module SENT #(
    parameter integer CLK_FREQ_HZ = 10000000
)(
    input clk,
    input rst_n,
    input [15:0] phase,
    output reg sent_out,
    output reg period_test, 
    output reg nlow_test
);

    localparam integer CLKS_PER_US = CLK_FREQ_HZ / 1000000;
    localparam Tnlow_N_clk   = CLKS_PER_US;       // 1us
    localparam Tsync_N_clk   = 15 * CLKS_PER_US;  // 15us
    localparam Tnibble_N_clk = 4 * CLKS_PER_US;   // 4us (Status)
    localparam Tbit_N_clk    = CLKS_PER_US;       // 1us (Data bit)
    localparam Tpause_N_clk  = 10 * CLKS_PER_US;  // 10us

    // \u7edd\u5bf9\u7cbe\u786e\u5e27\u8fb9\u754c\u5212\u5206 (\u7528\u7d2f\u52a0\u907f\u514d\u4efb\u4f55\u52a0\u51cf\u8bef\u5dee)
    localparam P1  = Tnlow_N_clk;                 // 1
    localparam P2  = P1 + Tsync_N_clk;            // 16
    localparam P3  = P2 + Tnlow_N_clk;            // 17
    localparam P4  = P3 + Tnibble_N_clk;          // 21
    localparam P5  = P4 + Tnlow_N_clk;            // 22
    
    localparam P6  = P5 + Tbit_N_clk;             // 23
    localparam P7  = P6 + Tbit_N_clk;             // 24
    localparam P8  = P7 + Tbit_N_clk;             // 25
    localparam P9  = P8 + Tbit_N_clk;             // 26
    localparam P10 = P9 + Tnlow_N_clk;            // 27
    
    localparam P11 = P10 + Tbit_N_clk;            // 28
    localparam P12 = P11 + Tbit_N_clk;            // 29
    localparam P13 = P12 + Tbit_N_clk;            // 30
    localparam P14 = P13 + Tbit_N_clk;            // 31
    localparam P15 = P14 + Tnlow_N_clk;           // 32
    
    localparam P16 = P15 + Tbit_N_clk;            // 33
    localparam P17 = P16 + Tbit_N_clk;            // 34
    localparam P18 = P17 + Tbit_N_clk;            // 35
    localparam P19 = P18 + Tbit_N_clk;            // 36
    localparam P20 = P19 + Tnlow_N_clk;           // 37
    
    localparam P21 = P20 + Tbit_N_clk;            // 38
    localparam P22 = P21 + Tbit_N_clk;            // 39
    localparam P23 = P22 + Tbit_N_clk;            // 40
    localparam P24 = P23 + Tbit_N_clk;            // 41
    localparam P25 = P24 + Tnlow_N_clk;           // 42
    
    localparam P26 = P25 + Tbit_N_clk;            // 43
    localparam P27 = P26 + Tbit_N_clk;            // 44
    localparam P28 = P27 + Tbit_N_clk;            // 45
    localparam P29 = P28 + Tbit_N_clk;            // 46
    localparam P30 = P29 + Tnlow_N_clk;           // 47
    localparam P31 = P30 + Tpause_N_clk;          // 57
    
    localparam period_N_clk  = P31; 

    reg [14:0] count_period; 
    reg crc_rst;

    wire [3:0] crc_out;
    wire flag;
    wire [19:0] data_out;    
    wire [15:0] frame_phase = data_out[19:4];
    wire [3:0] frame_crc = data_out[3:0];

    always@(posedge clk or negedge rst_n) begin
        // \u590d\u4f4d\u91ca\u653e\u540e\u7684\u7b2c\u4e00\u4e2a\u65f6\u949f\u5373\u88c5\u8f7d\u9996\u5e27\u6570\u636e\uff0c\u907f\u514d\u9996\u5e27\u56fa\u5b9a\u53d1\u9001 0\u3002
        if(!rst_n) crc_rst <= 1'b0;
        else if(count_period >= period_N_clk - 15'd1) crc_rst <= 1'b0;
        else crc_rst <= 1'b1;
    end

    CRC CRC1(      
        .sys_clk(clk),
        .sys_rst_n(rst_n),
        .crc_rst(crc_rst),
        .data_in(phase),    
        .flag(flag),
        .crc_out(crc_out),      
        .data_out(data_out)
    );

    always@(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            count_period <= 15'b0;
            period_test  <= 1'b1;
        end
        else begin
            if(count_period >= period_N_clk - 15'd1) begin
                count_period <= 15'b0;
                period_test  <= 1'b1;
            end
            else begin
                count_period <= count_period + 15'd1;
                period_test  <= 1'b0;
            end
        end
    end

    // \u3010\u5173\u952e\u4fee\u590d\u3011\u4f7f\u7528 >= \u548c <\uff0c\u5f7b\u5e95\u6d88\u706d\u7b2c 0 \u62cd\u7684\u8d8a\u754c Bug
    always @(*) begin
        if (!rst_n) begin
            sent_out = 1'b0;
            nlow_test = 1'b0;
        end else begin
            if      (count_period < P1)  begin sent_out = 1'b0;      nlow_test = 1'b1; end
            else if (count_period >= P1  && count_period < P2)  begin sent_out = 1'b1;      nlow_test = 1'b0; end
            else if (count_period >= P2  && count_period < P3)  begin sent_out = 1'b0;      nlow_test = 1'b1; end
            else if (count_period >= P3  && count_period < P4)  begin sent_out = 1'b1;      nlow_test = 1'b0; end
            else if (count_period >= P4  && count_period < P5)  begin sent_out = 1'b0;      nlow_test = 1'b1; end
            
            // Nibble 1 (bit 15-12)
            else if (count_period >= P5  && count_period < P6)  begin sent_out = frame_phase[15]; nlow_test = 1'b0; end
            else if (count_period >= P6  && count_period < P7)  begin sent_out = frame_phase[14]; nlow_test = 1'b0; end
            else if (count_period >= P7  && count_period < P8)  begin sent_out = frame_phase[13]; nlow_test = 1'b0; end
            else if (count_period >= P8  && count_period < P9)  begin sent_out = frame_phase[12]; nlow_test = 1'b0; end
            else if (count_period >= P9  && count_period < P10) begin sent_out = 1'b0;      nlow_test = 1'b1; end
            
            // Nibble 2 (bit 11-8)
            else if (count_period >= P10 && count_period < P11) begin sent_out = frame_phase[11]; nlow_test = 1'b0; end
            else if (count_period >= P11 && count_period < P12) begin sent_out = frame_phase[10]; nlow_test = 1'b0; end
            else if (count_period >= P12 && count_period < P13) begin sent_out = frame_phase[9];  nlow_test = 1'b0; end
            else if (count_period >= P13 && count_period < P14) begin sent_out = frame_phase[8];  nlow_test = 1'b0; end
            else if (count_period >= P14 && count_period < P15) begin sent_out = 1'b0;      nlow_test = 1'b1; end
            
            // Nibble 3 (bit 7-4)
            else if (count_period >= P15 && count_period < P16) begin sent_out = frame_phase[7];  nlow_test = 1'b0; end
            else if (count_period >= P16 && count_period < P17) begin sent_out = frame_phase[6];  nlow_test = 1'b0; end
            else if (count_period >= P17 && count_period < P18) begin sent_out = frame_phase[5];  nlow_test = 1'b0; end
            else if (count_period >= P18 && count_period < P19) begin sent_out = frame_phase[4];  nlow_test = 1'b0; end
            else if (count_period >= P19 && count_period < P20) begin sent_out = 1'b0;      nlow_test = 1'b1; end
            
            // Nibble 4 (bit 3-0)
            else if (count_period >= P20 && count_period < P21) begin sent_out = frame_phase[3];  nlow_test = 1'b0; end
            else if (count_period >= P21 && count_period < P22) begin sent_out = frame_phase[2];  nlow_test = 1'b0; end
            else if (count_period >= P22 && count_period < P23) begin sent_out = frame_phase[1];  nlow_test = 1'b0; end
            else if (count_period >= P23 && count_period < P24) begin sent_out = frame_phase[0];  nlow_test = 1'b0; end
            else if (count_period >= P24 && count_period < P25) begin sent_out = 1'b0;      nlow_test = 1'b1; end
            
            // CRC Nibble
            else if (count_period >= P25 && count_period < P26) begin sent_out = frame_crc[3];nlow_test = 1'b0; end
            else if (count_period >= P26 && count_period < P27) begin sent_out = frame_crc[2];nlow_test = 1'b0; end
            else if (count_period >= P27 && count_period < P28) begin sent_out = frame_crc[1];nlow_test = 1'b0; end
            else if (count_period >= P28 && count_period < P29) begin sent_out = frame_crc[0];nlow_test = 1'b0; end
            else if (count_period >= P29 && count_period < P30) begin sent_out = 1'b0;      nlow_test = 1'b1; end
            
            // Pause
            else if (count_period >= P30 && count_period < P31) begin sent_out = 1'b1;      nlow_test = 1'b0; end
            else begin sent_out = 1'b0; nlow_test = 1'b0; end
        end
    end
endmodule
`timescale 1ns / 1ps

`timescale 1ns / 1ps

module ABZ #(
    parameter integer CLK_FREQ_HZ = 10_000_000,

    // A相完整周期频率
    // 36000Hz表示每秒最多追踪36000个0.01°角度码
    parameter integer AB_FREQ_HZ  = 36_000
)(
    input  wire        clk,
    input  wire        rst_n,

    // 角度输入
    // 有效范围：0~36000
    // 36000按0°处理
    input  wire [15:0] phase,

    output wire        A,
    output wire        B,
    output reg         Z
);


    // ============================================================
    // 一个AB完整周期包含4个正交状态
    //
    // 正向：
    // 00 -> 01 -> 11 -> 10 -> 00
    //
    // 反向：
    // 00 -> 10 -> 11 -> 01 -> 00
    // ============================================================

    localparam integer QUAD_FREQ_HZ =
        AB_FREQ_HZ * 4;

    localparam integer QUAD_TICKS_RAW =
        CLK_FREQ_HZ / QUAD_FREQ_HZ;

    localparam integer QUAD_TICKS =
        (QUAD_TICKS_RAW < 1) ? 1 : QUAD_TICKS_RAW;


    reg [31:0] tick_cnt;

    wire quad_tick;

    assign quad_tick =
        (tick_cnt >= QUAD_TICKS - 1);


    // ============================================================
    // 输入角度归一化
    //
    // 36000 = 360.00° = 0°
    // ============================================================

    wire [15:0] target_phase;

    assign target_phase =
        (phase >= 16'd36000)
        ? 16'd0
        : phase;


    // ============================================================
    // 当前AB输出所对应的内部位置
    //
    // 0~35999
    // ============================================================

    reg [15:0] current_phase;


    // ============================================================
    // AB正交状态
    // ============================================================

    reg [1:0] ab_state;

    assign A = ab_state[1];
    assign B = ab_state[0];


    // ============================================================
    // 一次完整AB周期是否正在运行
    // ============================================================

    reg move_active;

    // 1：角度增加方向
    // 0：角度减小方向
    reg move_forward;


    // ============================================================
    // 环形角度距离
    //
    // forward_distance：
    // current -> target，角度增加方向距离
    //
    // reverse_distance：
    // current -> target，角度减小方向距离
    //
    // 自动选择较短路径。
    // ============================================================

    wire [16:0] forward_distance;
    wire [16:0] reverse_distance;

    assign forward_distance =
        (target_phase >= current_phase)
        ?
        ({1'b0,target_phase} -
         {1'b0,current_phase})
        :
        (17'd36000 +
         {1'b0,target_phase} -
         {1'b0,current_phase});


    assign reverse_distance =
        (current_phase >= target_phase)
        ?
        ({1'b0,current_phase} -
         {1'b0,target_phase})
        :
        (17'd36000 +
         {1'b0,current_phase} -
         {1'b0,target_phase});


    wire direction_forward;

    assign direction_forward =
        (forward_distance <= reverse_distance);


    // ============================================================
    // AB主控制
    //
    // 每完成一个完整AB正交周期：
    //
    // current_phase ± 1
    //
    // 即一个完整A/B周期对应0.01°
    // ============================================================

    always @(posedge clk or negedge rst_n) begin

        if(!rst_n) begin

            tick_cnt      <= 32'd0;

            current_phase <= 16'd0;

            ab_state      <= 2'b00;

            move_active   <= 1'b0;

            move_forward  <= 1'b1;

            Z             <= 1'b0;

        end
        else begin

            // Z默认只保持一个clk
            Z <= 1'b0;


            // ----------------------------------------------------
            // 当前已经到达目标，并且没有正在完成的AB周期
            // ----------------------------------------------------

            if((current_phase == target_phase) &&
               (!move_active)) begin

                tick_cnt <= 32'd0;

                ab_state <= 2'b00;

            end


            // ----------------------------------------------------
            // 正常等待正交状态切换时间
            // ----------------------------------------------------

            else if(!quad_tick) begin

                tick_cnt <= tick_cnt + 32'd1;

            end


            // ----------------------------------------------------
            // 到达1/4周期切换点
            // ----------------------------------------------------

            else begin

                tick_cnt <= 32'd0;


                // =================================================
                // 当前没有运行中的AB周期
                //
                // 开始一个新的完整AB周期
                // =================================================

                if(!move_active) begin

                    if(current_phase != target_phase) begin

                        move_active  <= 1'b1;

                        move_forward <= direction_forward;


                        if(direction_forward)
                            ab_state <= 2'b01;
                        else
                            ab_state <= 2'b10;

                    end
                    else begin

                        ab_state <= 2'b00;

                    end

                end


                // =================================================
                // 正向
                //
                // 00 -> 01 -> 11 -> 10 -> 00
                // =================================================

                else if(move_forward) begin

                    case(ab_state)

                        2'b01: begin

                            ab_state <= 2'b11;

                        end


                        2'b11: begin

                            ab_state <= 2'b10;

                        end


                        2'b10: begin

                            // 一个完整AB周期结束
                            ab_state    <= 2'b00;
                            move_active <= 1'b0;


                            // 35999 -> 0
                            if(current_phase >= 16'd35999) begin

                                current_phase <= 16'd0;

                                // 一圈Index
                                Z <= 1'b1;

                            end
                            else begin

                                current_phase <=
                                    current_phase + 16'd1;

                            end

                        end


                        default: begin

                            ab_state <= 2'b01;

                        end

                    endcase

                end


                // =================================================
                // 反向
                //
                // 00 -> 10 -> 11 -> 01 -> 00
                // =================================================

                else begin

                    case(ab_state)

                        2'b10: begin

                            ab_state <= 2'b11;

                        end


                        2'b11: begin

                            ab_state <= 2'b01;

                        end


                        2'b01: begin

                            // 一个完整AB周期结束
                            ab_state    <= 2'b00;
                            move_active <= 1'b0;


                            // 0 -> 35999
                            if(current_phase == 16'd0) begin

                                current_phase <= 16'd35999;

                                // 反向跨零同样产生Index
                                Z <= 1'b1;

                            end
                            else begin

                                current_phase <=
                                    current_phase - 16'd1;

                            end

                        end


                        default: begin

                            ab_state <= 2'b10;

                        end

                    endcase

                end

            end

        end

    end


endmodule
`timescale 1ns / 1ps

module UVW #(
    parameter integer CLK_FREQ_HZ = 10_000_000,

    // 一个完整UVW周期的频率
    parameter integer UVW_FREQ_HZ = 36_000
)(
    input  wire        clk,
    input  wire        rst_n,

    // 角度输入
    // 有效范围0~36000
    input  wire [15:0] phase_in,

    output reg         U,
    output reg         V,
    output reg         W
);


    // ============================================================
    // 一个UVW完整周期分成6个状态
    //
    // 正向：
    //
    // 100
    // 110
    // 010
    // 011
    // 001
    // 101
    //
    // 反向顺序相反
    // ============================================================

    localparam integer UVW_STATE_FREQ_HZ =
        UVW_FREQ_HZ * 6;

    localparam integer STATE_TICKS_RAW =
        CLK_FREQ_HZ / UVW_STATE_FREQ_HZ;

    localparam integer STATE_TICKS =
        (STATE_TICKS_RAW < 1) ? 1 : STATE_TICKS_RAW;


    reg [31:0] tick_cnt;

    wire state_tick;

    assign state_tick =
        (tick_cnt >= STATE_TICKS - 1);


    // ============================================================
    // 36000等效于0°
    // ============================================================

    wire [15:0] target_phase;

    assign target_phase =
        (phase_in >= 16'd36000)
        ? 16'd0
        : phase_in;


    // ============================================================
    // 当前内部位置
    // ============================================================

    reg [15:0] current_phase;


    // ============================================================
    // 环形方向判断
    // ============================================================

    wire [16:0] forward_distance;
    wire [16:0] reverse_distance;


    assign forward_distance =
        (target_phase >= current_phase)
        ?
        ({1'b0,target_phase} -
         {1'b0,current_phase})
        :
        (17'd36000 +
         {1'b0,target_phase} -
         {1'b0,current_phase});


    assign reverse_distance =
        (current_phase >= target_phase)
        ?
        ({1'b0,current_phase} -
         {1'b0,target_phase})
        :
        (17'd36000 +
         {1'b0,current_phase} -
         {1'b0,target_phase});


    wire direction_forward;

    assign direction_forward =
        (forward_distance <= reverse_distance);


    // ============================================================
    // UVW内部状态
    // ============================================================

    reg       move_active;
    reg       move_forward;

    reg [2:0] state_index;


    // ============================================================
    // UVW主状态机
    //
    // 每完成6个UVW状态：
    //
    // current_phase ± 1
    //
    // 即一个完整UVW周期对应一个0.01°角度码。
    // ============================================================

    always @(posedge clk or negedge rst_n) begin

        if(!rst_n) begin

            tick_cnt      <= 32'd0;

            current_phase <= 16'd0;

            move_active   <= 1'b0;

            move_forward  <= 1'b1;

            state_index   <= 3'd0;

            U <= 1'b0;
            V <= 1'b0;
            W <= 1'b0;

        end
        else begin


            // ----------------------------------------------------
            // 已经到达目标
            // ----------------------------------------------------

            if((current_phase == target_phase) &&
               (!move_active)) begin

                tick_cnt <= 32'd0;

                U <= 1'b0;
                V <= 1'b0;
                W <= 1'b0;

            end


            // ----------------------------------------------------
            // 等待UVW状态切换
            // ----------------------------------------------------

            else if(!state_tick) begin

                tick_cnt <= tick_cnt + 32'd1;

            end


            // ----------------------------------------------------
            // UVW状态切换
            // ----------------------------------------------------

            else begin

                tick_cnt <= 32'd0;


                // =================================================
                // 开始一个新的UVW周期
                // =================================================

                if(!move_active) begin

                    if(current_phase != target_phase) begin

                        move_active  <= 1'b1;

                        move_forward <= direction_forward;

                        state_index  <= 3'd0;


                        // 第一状态
                        U <= 1'b1;
                        V <= 1'b0;
                        W <= 1'b0;

                    end

                end


                // =================================================
                // 正向UVW
                //
                // 100
                // 110
                // 010
                // 011
                // 001
                // 101
                // =================================================

                else if(move_forward) begin

                    case(state_index)

                        3'd0: begin

                            state_index <= 3'd1;

                            U <= 1'b1;
                            V <= 1'b1;
                            W <= 1'b0;

                        end


                        3'd1: begin

                            state_index <= 3'd2;

                            U <= 1'b0;
                            V <= 1'b1;
                            W <= 1'b0;

                        end


                        3'd2: begin

                            state_index <= 3'd3;

                            U <= 1'b0;
                            V <= 1'b1;
                            W <= 1'b1;

                        end


                        3'd3: begin

                            state_index <= 3'd4;

                            U <= 1'b0;
                            V <= 1'b0;
                            W <= 1'b1;

                        end


                        3'd4: begin

                            state_index <= 3'd5;

                            U <= 1'b1;
                            V <= 1'b0;
                            W <= 1'b1;

                        end


                        3'd5: begin

                            // 一个完整UVW周期结束
                            state_index <= 3'd0;

                            move_active <= 1'b0;

                            U <= 1'b0;
                            V <= 1'b0;
                            W <= 1'b0;


                            if(current_phase >= 16'd35999)
                                current_phase <= 16'd0;
                            else
                                current_phase <=
                                    current_phase + 16'd1;

                        end


                        default: begin

                            state_index <= 3'd0;

                            move_active <= 1'b0;

                            U <= 1'b0;
                            V <= 1'b0;
                            W <= 1'b0;

                        end

                    endcase

                end


                // =================================================
                // 反向UVW
                //
                // 100
                // 101
                // 001
                // 011
                // 010
                // 110
                // =================================================

                else begin

                    case(state_index)

                        3'd0: begin

                            state_index <= 3'd1;

                            U <= 1'b1;
                            V <= 1'b0;
                            W <= 1'b1;

                        end


                        3'd1: begin

                            state_index <= 3'd2;

                            U <= 1'b0;
                            V <= 1'b0;
                            W <= 1'b1;

                        end


                        3'd2: begin

                            state_index <= 3'd3;

                            U <= 1'b0;
                            V <= 1'b1;
                            W <= 1'b1;

                        end


                        3'd3: begin

                            state_index <= 3'd4;

                            U <= 1'b0;
                            V <= 1'b1;
                            W <= 1'b0;

                        end


                        3'd4: begin

                            state_index <= 3'd5;

                            U <= 1'b1;
                            V <= 1'b1;
                            W <= 1'b0;

                        end


                        3'd5: begin

                            // 一个完整UVW周期结束
                            state_index <= 3'd0;

                            move_active <= 1'b0;

                            U <= 1'b0;
                            V <= 1'b0;
                            W <= 1'b0;


                            if(current_phase == 16'd0)
                                current_phase <= 16'd35999;
                            else
                                current_phase <=
                                    current_phase - 16'd1;

                        end


                        default: begin

                            state_index <= 3'd0;

                            move_active <= 1'b0;

                            U <= 1'b0;
                            V <= 1'b0;
                            W <= 1'b0;

                        end

                    endcase

                end

            end

        end

    end


endmodule
//`timescale 1ns / 1ps

////====================================================================
//// \u9876\u5c42\u6a21\u5757\uff1ahall_interface
////====================================================================
//module hall_interface #(
//    parameter integer CLK_FREQ_HZ = 10000000
//)(
//    input clk,                   // \u65f6\u949f\u57fa\u51c6\uff0c\u9ed8\u8ba4\u9891\u7387\u4e3a 10MHz
//    input rst_n,                 // \u590d\u4f4d\u4fe1\u53f7\uff0c\u4f4e\u7535\u5e73\u590d\u4f4d\uff0c\u9ad8\u7535\u5e73\u4fdd\u6301
//    input mode_select,           // \u6a21\u5f0f\u9009\u62e9\u7aef (0:PWM, 1:SENT)
//    input [1:0] pwm_freq_select, // PWM\u9891\u7387\u9009\u62e9\u7aef
//    input [15:0] phase,          // \u3010\u4fee\u6539\u3011 \u89d2\u5ea6\u8f93\u5165\u4fe1\u53f7\u603b\u7ebf 14 -> 16
//    output data_out              // \u6570\u636e\u8f93\u51fa
//);

//    wire PWM1_out;

//    // \u4f8b\u5316PWM\u6a21\u5757
//    PWM_program #(
//        .CLK_FREQ_HZ(CLK_FREQ_HZ)
//    ) PWM1(
//        .clk(clk),
//        .rst_n(rst_n),
//        .phase(phase),
//        .freq_select(pwm_freq_select),
//        .PWM_out(PWM1_out)
//    );

//    wire [15:0] SENT1_phase_in;
//    // \u3010\u4fee\u6539\u3011\u76f4\u63a5\u63a5\u5165 16-bit \u6570\u636e
//    assign SENT1_phase_in = phase; 

//    wire SENT1_out;
//    wire SENT1_period_test_out; 
//    wire SENT1_nlow_test;

//    // \u4f8b\u5316SENT\u6a21\u5757
//    SENT #(
//        .CLK_FREQ_HZ(CLK_FREQ_HZ)
//    ) SENT1(
//        .clk(clk),
//        .rst_n(rst_n),
//        .phase(SENT1_phase_in),
//        .sent_out(SENT1_out),
//        .period_test(SENT1_period_test_out),
//        .nlow_test(SENT1_nlow_test)
//    );

//    // \u4f8b\u5316\u8f93\u51fa\u9009\u62e9\u6a21\u5757
//    output_select sel1(
//        .clk(clk),
//        .rst_n(rst_n),
//        .select(mode_select),
//        .PWM1(PWM1_out),
//        .SENT1(SENT1_out),
//        .data_out(data_out)
//    );

//endmodule


////====================================================================
//// \u8f93\u51fa\u9009\u62e9\u6a21\u5757 (\u4fdd\u6301\u4e0d\u53d8)
////====================================================================
//module output_select(
//    input clk,
//    input rst_n,
//    input select,       
//    input PWM1, 
//    input SENT1,
//    output reg data_out 
//);
//    always@(posedge clk or negedge rst_n) begin
//        if(!rst_n) begin
//            data_out <= 1'b0;
//        end
//        else begin
//            case(select)
//                1'b0: data_out <= PWM1;
//                1'b1: data_out <= SENT1;
//                default: data_out <= 1'b0;
//            endcase
//        end
//    end
//endmodule


////====================================================================
//// CRC \u6a21\u5757 (\u4fee\u590d\u4e86\u539f\u7248\u9ad84\u4f4d\u4e22\u5931\u7684BUG\uff0c\u5e76\u6269\u5c55\u9002\u5e94 16-bit)
////====================================================================
//module CRC(
//    input sys_clk,
//    input sys_rst_n,
//    input crc_rst,
//    input [15:0] data_in,     // \u3010\u4fee\u6539\u3011 12 -> 16
//    output reg flag,
//    output reg [3:0] crc_out, 
//    output reg [19:0] data_out // \u3010\u4fee\u6539\u3011 16 -> 20 (16\u4f4d\u6570\u636e+4\u4f4dCRC)
//);
//    reg [19:0] data_in_reg;    // \u3010\u4fee\u6539\u3011 \u7f13\u51b2\u6c60 16 -> 20
//    reg [15:0] data_latched;
//    localparam gx_crc_5 = 5'b11101; // p(x) = x^4 + x^3 + x^2 + 1
   
//    always @(posedge sys_clk or negedge sys_rst_n) begin
//        if(!sys_rst_n) begin
//            crc_out     <= 4'd0;
//            flag        <= 1'b0;
//            data_in_reg <= 20'd0;
//            data_latched <= 16'd0;
//            data_out    <= 20'd0;
//        end   
//        else if (!crc_rst) begin
//            crc_out     <= 4'd0;
//            flag        <= 1'b0;
//            data_in_reg <= {data_in, 4'b000};
//            data_latched <= data_in;
//        end
//        else begin
//            // \u3010\u4fee\u6539\u3011\u4fee\u590d\u5f02\u6216\u6f0f\u6d1e\uff0c\u4ece\u6700\u9ad8\u4f4d [19] \u5b8c\u6574\u6821\u9a8c\u5230 [4]
//            if     (data_in_reg[19] == 1'b1) data_in_reg[19:15] <= data_in_reg[19:15] ^ gx_crc_5;
//            else if(data_in_reg[18] == 1'b1) data_in_reg[18:14] <= data_in_reg[18:14] ^ gx_crc_5;
//            else if(data_in_reg[17] == 1'b1) data_in_reg[17:13] <= data_in_reg[17:13] ^ gx_crc_5;
//            else if(data_in_reg[16] == 1'b1) data_in_reg[16:12] <= data_in_reg[16:12] ^ gx_crc_5;
//            else if(data_in_reg[15] == 1'b1) data_in_reg[15:11] <= data_in_reg[15:11] ^ gx_crc_5;
//            else if(data_in_reg[14] == 1'b1) data_in_reg[14:10] <= data_in_reg[14:10] ^ gx_crc_5;
//            else if(data_in_reg[13] == 1'b1) data_in_reg[13:9]  <= data_in_reg[13:9]  ^ gx_crc_5;
//            else if(data_in_reg[12] == 1'b1) data_in_reg[12:8]  <= data_in_reg[12:8]  ^ gx_crc_5;
//            else if(data_in_reg[11] == 1'b1) data_in_reg[11:7]  <= data_in_reg[11:7]  ^ gx_crc_5;
//            else if(data_in_reg[10] == 1'b1) data_in_reg[10:6]  <= data_in_reg[10:6]  ^ gx_crc_5;
//            else if(data_in_reg[9]  == 1'b1) data_in_reg[9:5]   <= data_in_reg[9:5]   ^ gx_crc_5;
//            else if(data_in_reg[8]  == 1'b1) data_in_reg[8:4]   <= data_in_reg[8:4]   ^ gx_crc_5;
//            else if(data_in_reg[7]  == 1'b1) data_in_reg[7:3]   <= data_in_reg[7:3]   ^ gx_crc_5;
//            else if(data_in_reg[6]  == 1'b1) data_in_reg[6:2]   <= data_in_reg[6:2]   ^ gx_crc_5;
//            else if(data_in_reg[5]  == 1'b1) data_in_reg[5:1]   <= data_in_reg[5:1]   ^ gx_crc_5;
//            else if(data_in_reg[4]  == 1'b1) data_in_reg[4:0]   <= data_in_reg[4:0]   ^ gx_crc_5;
//            else begin 
//                crc_out  <= data_in_reg[3:0];
//                data_out <= {data_latched, data_in_reg[3:0]};
//                flag     <= 1'b1;
//            end
//        end
//    end
//endmodule


////====================================================================
//// PWM \u7a0b\u5e8f\u6a21\u5757 (\u7f29\u653e\u7b97\u6cd5\u5339\u914d 16-bit \u4ee5\u53ca\u65b0\u9891\u7387\u8981\u6c42)
////====================================================================
//module PWM_program #(
//    parameter integer CLK_FREQ_HZ = 10000000
//)(
//    input clk,
//    input rst_n,
//    input [15:0] phase,       // \u3010\u4fee\u6539\u3011 14 -> 16
//    input [1:0] freq_select,  
//    output reg PWM_out
//);

//    reg [19:0] count_norm;
//    reg [19:0] phase_count;
//    reg [19:0] PWM_freq_N_clk;
//    reg [19:0] requested_period;
//    reg [19:0] requested_phase_count;

//    localparam integer PERIOD_50HZ   = CLK_FREQ_HZ / 50;
//    localparam integer PERIOD_500HZ  = CLK_FREQ_HZ / 500;
//    localparam integer PERIOD_2000HZ = CLK_FREQ_HZ / 2000;
//    localparam integer PERIOD_4000HZ = CLK_FREQ_HZ / 4000;

//    wire [15:0] phase_limited = (phase > 16'd36000) ? 16'd36000 : phase;

//    always @(*) begin
//        case(freq_select)
//            2'd0: requested_period = PERIOD_50HZ;
//            2'd1: requested_period = PERIOD_500HZ;
//            2'd2: requested_period = PERIOD_2000HZ;
//            2'd3: requested_period = PERIOD_4000HZ;
//            default: requested_period = PERIOD_50HZ;
//        endcase

//        // Explicit 36-bit operands prevent multiplication truncation.
//        requested_phase_count =
//            ({20'd0, phase_limited} * {16'd0, requested_period}) / 36'd36000;
//    end

//    // Commit frequency and duty only on a PWM frame boundary.
//    always @(posedge clk or negedge rst_n) begin
//        if(!rst_n) begin
//            PWM_freq_N_clk <= PERIOD_50HZ;
//            phase_count    <= 20'd0;
//        end else if ((count_norm == 20'd0) ||
//                     (count_norm >= PWM_freq_N_clk - 20'd1)) begin
//            PWM_freq_N_clk <= requested_period;
//            phase_count    <= requested_phase_count;
//        end
//    end

//    always@(posedge clk or negedge rst_n) begin
//        if(!rst_n)
//            count_norm <= 20'b0;
//        else if(count_norm >= PWM_freq_N_clk - 20'd1)
//            count_norm <= 20'd0;
//        else  
//            count_norm <= count_norm + 20'd1;
//    end

//    always@(posedge clk or negedge rst_n) begin
//        if(!rst_n)
//            PWM_out <= 1'b0;
//        else if((phase_count != 0) && (count_norm < phase_count))  
//            PWM_out <= 1'b1;
//        else 
//            PWM_out <= 1'b0;
//    end
//endmodule



////====================================================================
//// \u81ea\u5b9a\u4e49\u4e32\u884c\u5e27\u6a21\u5757\uff08\u4fdd\u6301\u539f\u6709\u7ebf\u8def\u683c\u5f0f\uff1b\u5e76\u975e SAE J2716 SENT \u7f16\u7801\uff09
////====================================================================
//`timescale 1ns / 1ps
//module SENT #(
//    parameter integer CLK_FREQ_HZ = 10000000
//)(
//    input clk,
//    input rst_n,
//    input [15:0] phase,
//    output reg sent_out,
//    output reg period_test, 
//    output reg nlow_test
//);

//    localparam integer CLKS_PER_US = CLK_FREQ_HZ / 1000000;
//    localparam Tnlow_N_clk   = CLKS_PER_US;       // 1us
//    localparam Tsync_N_clk   = 15 * CLKS_PER_US;  // 15us
//    localparam Tnibble_N_clk = 4 * CLKS_PER_US;   // 4us (Status)
//    localparam Tbit_N_clk    = CLKS_PER_US;       // 1us (Data bit)
//    localparam Tpause_N_clk  = 10 * CLKS_PER_US;  // 10us

//    // \u7edd\u5bf9\u7cbe\u786e\u5e27\u8fb9\u754c\u5212\u5206 (\u7528\u7d2f\u52a0\u907f\u514d\u4efb\u4f55\u52a0\u51cf\u8bef\u5dee)
//    localparam P1  = Tnlow_N_clk;                 // 1
//    localparam P2  = P1 + Tsync_N_clk;            // 16
//    localparam P3  = P2 + Tnlow_N_clk;            // 17
//    localparam P4  = P3 + Tnibble_N_clk;          // 21
//    localparam P5  = P4 + Tnlow_N_clk;            // 22
    
//    localparam P6  = P5 + Tbit_N_clk;             // 23
//    localparam P7  = P6 + Tbit_N_clk;             // 24
//    localparam P8  = P7 + Tbit_N_clk;             // 25
//    localparam P9  = P8 + Tbit_N_clk;             // 26
//    localparam P10 = P9 + Tnlow_N_clk;            // 27
    
//    localparam P11 = P10 + Tbit_N_clk;            // 28
//    localparam P12 = P11 + Tbit_N_clk;            // 29
//    localparam P13 = P12 + Tbit_N_clk;            // 30
//    localparam P14 = P13 + Tbit_N_clk;            // 31
//    localparam P15 = P14 + Tnlow_N_clk;           // 32
    
//    localparam P16 = P15 + Tbit_N_clk;            // 33
//    localparam P17 = P16 + Tbit_N_clk;            // 34
//    localparam P18 = P17 + Tbit_N_clk;            // 35
//    localparam P19 = P18 + Tbit_N_clk;            // 36
//    localparam P20 = P19 + Tnlow_N_clk;           // 37
    
//    localparam P21 = P20 + Tbit_N_clk;            // 38
//    localparam P22 = P21 + Tbit_N_clk;            // 39
//    localparam P23 = P22 + Tbit_N_clk;            // 40
//    localparam P24 = P23 + Tbit_N_clk;            // 41
//    localparam P25 = P24 + Tnlow_N_clk;           // 42
    
//    localparam P26 = P25 + Tbit_N_clk;            // 43
//    localparam P27 = P26 + Tbit_N_clk;            // 44
//    localparam P28 = P27 + Tbit_N_clk;            // 45
//    localparam P29 = P28 + Tbit_N_clk;            // 46
//    localparam P30 = P29 + Tnlow_N_clk;           // 47
//    localparam P31 = P30 + Tpause_N_clk;          // 57
    
//    localparam period_N_clk  = P31; 

//    reg [14:0] count_period; 
//    reg crc_rst;

//    wire [3:0] crc_out;
//    wire flag;
//    wire [19:0] data_out;    
//    wire [15:0] frame_phase = data_out[19:4];
//    wire [3:0] frame_crc = data_out[3:0];

//    always@(posedge clk or negedge rst_n) begin
//        // \u590d\u4f4d\u91ca\u653e\u540e\u7684\u7b2c\u4e00\u4e2a\u65f6\u949f\u5373\u88c5\u8f7d\u9996\u5e27\u6570\u636e\uff0c\u907f\u514d\u9996\u5e27\u56fa\u5b9a\u53d1\u9001 0\u3002
//        if(!rst_n) crc_rst <= 1'b0;
//        else if(count_period >= period_N_clk - 15'd1) crc_rst <= 1'b0;
//        else crc_rst <= 1'b1;
//    end

//    CRC CRC1(      
//        .sys_clk(clk),
//        .sys_rst_n(rst_n),
//        .crc_rst(crc_rst),
//        .data_in(phase),    
//        .flag(flag),
//        .crc_out(crc_out),      
//        .data_out(data_out)
//    );

//    always@(posedge clk or negedge rst_n) begin
//        if(!rst_n) begin
//            count_period <= 15'b0;
//            period_test  <= 1'b1;
//        end
//        else begin
//            if(count_period >= period_N_clk - 15'd1) begin
//                count_period <= 15'b0;
//                period_test  <= 1'b1;
//            end
//            else begin
//                count_period <= count_period + 15'd1;
//                period_test  <= 1'b0;
//            end
//        end
//    end

//    // \u3010\u5173\u952e\u4fee\u590d\u3011\u4f7f\u7528 >= \u548c <\uff0c\u5f7b\u5e95\u6d88\u706d\u7b2c 0 \u62cd\u7684\u8d8a\u754c Bug
//    always @(*) begin
//        if (!rst_n) begin
//            sent_out = 1'b0;
//            nlow_test = 1'b0;
//        end else begin
//            if      (count_period < P1)  begin sent_out = 1'b0;      nlow_test = 1'b1; end
//            else if (count_period >= P1  && count_period < P2)  begin sent_out = 1'b1;      nlow_test = 1'b0; end
//            else if (count_period >= P2  && count_period < P3)  begin sent_out = 1'b0;      nlow_test = 1'b1; end
//            else if (count_period >= P3  && count_period < P4)  begin sent_out = 1'b1;      nlow_test = 1'b0; end
//            else if (count_period >= P4  && count_period < P5)  begin sent_out = 1'b0;      nlow_test = 1'b1; end
            
//            // Nibble 1 (bit 15-12)
//            else if (count_period >= P5  && count_period < P6)  begin sent_out = frame_phase[15]; nlow_test = 1'b0; end
//            else if (count_period >= P6  && count_period < P7)  begin sent_out = frame_phase[14]; nlow_test = 1'b0; end
//            else if (count_period >= P7  && count_period < P8)  begin sent_out = frame_phase[13]; nlow_test = 1'b0; end
//            else if (count_period >= P8  && count_period < P9)  begin sent_out = frame_phase[12]; nlow_test = 1'b0; end
//            else if (count_period >= P9  && count_period < P10) begin sent_out = 1'b0;      nlow_test = 1'b1; end
            
//            // Nibble 2 (bit 11-8)
//            else if (count_period >= P10 && count_period < P11) begin sent_out = frame_phase[11]; nlow_test = 1'b0; end
//            else if (count_period >= P11 && count_period < P12) begin sent_out = frame_phase[10]; nlow_test = 1'b0; end
//            else if (count_period >= P12 && count_period < P13) begin sent_out = frame_phase[9];  nlow_test = 1'b0; end
//            else if (count_period >= P13 && count_period < P14) begin sent_out = frame_phase[8];  nlow_test = 1'b0; end
//            else if (count_period >= P14 && count_period < P15) begin sent_out = 1'b0;      nlow_test = 1'b1; end
            
//            // Nibble 3 (bit 7-4)
//            else if (count_period >= P15 && count_period < P16) begin sent_out = frame_phase[7];  nlow_test = 1'b0; end
//            else if (count_period >= P16 && count_period < P17) begin sent_out = frame_phase[6];  nlow_test = 1'b0; end
//            else if (count_period >= P17 && count_period < P18) begin sent_out = frame_phase[5];  nlow_test = 1'b0; end
//            else if (count_period >= P18 && count_period < P19) begin sent_out = frame_phase[4];  nlow_test = 1'b0; end
//            else if (count_period >= P19 && count_period < P20) begin sent_out = 1'b0;      nlow_test = 1'b1; end
            
//            // Nibble 4 (bit 3-0)
//            else if (count_period >= P20 && count_period < P21) begin sent_out = frame_phase[3];  nlow_test = 1'b0; end
//            else if (count_period >= P21 && count_period < P22) begin sent_out = frame_phase[2];  nlow_test = 1'b0; end
//            else if (count_period >= P22 && count_period < P23) begin sent_out = frame_phase[1];  nlow_test = 1'b0; end
//            else if (count_period >= P23 && count_period < P24) begin sent_out = frame_phase[0];  nlow_test = 1'b0; end
//            else if (count_period >= P24 && count_period < P25) begin sent_out = 1'b0;      nlow_test = 1'b1; end
            
//            // CRC Nibble
//            else if (count_period >= P25 && count_period < P26) begin sent_out = frame_crc[3];nlow_test = 1'b0; end
//            else if (count_period >= P26 && count_period < P27) begin sent_out = frame_crc[2];nlow_test = 1'b0; end
//            else if (count_period >= P27 && count_period < P28) begin sent_out = frame_crc[1];nlow_test = 1'b0; end
//            else if (count_period >= P28 && count_period < P29) begin sent_out = frame_crc[0];nlow_test = 1'b0; end
//            else if (count_period >= P29 && count_period < P30) begin sent_out = 1'b0;      nlow_test = 1'b1; end
            
//            // Pause
//            else if (count_period >= P30 && count_period < P31) begin sent_out = 1'b1;      nlow_test = 1'b0; end
//            else begin sent_out = 1'b0; nlow_test = 1'b0; end
//        end
//    end
//endmodule