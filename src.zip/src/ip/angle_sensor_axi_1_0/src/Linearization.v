`timescale 1ns / 1ps

module Linearization #(
    parameter integer DATA_WIDTH = 16,
    parameter [31:0] STEP = 32'd2250
)(
    input  wire        clk,                  // 系统时钟 10 MHz
    input  wire        rst_n,                // 低电平复位
    input  wire        en,                   // 1：插值校准；0：原样输出
    input  wire        i_valid,              // 输入角度有效脉冲

    input  wire [15:0] datain_Linearization,

    // 33 个16位无符号标定点
    input  wire [15:0] x0,
    input  wire [15:0] x1,
    input  wire [15:0] x2,
    input  wire [15:0] x3,
    input  wire [15:0] x4,
    input  wire [15:0] x5,
    input  wire [15:0] x6,
    input  wire [15:0] x7,

    input  wire [15:0] x8,
    input  wire [15:0] x9,
    input  wire [15:0] x10,
    input  wire [15:0] x11,
    input  wire [15:0] x12,
    input  wire [15:0] x13,
    input  wire [15:0] x14,
    input  wire [15:0] x15,

    input  wire [15:0] x16,
    input  wire [15:0] x17,
    input  wire [15:0] x18,
    input  wire [15:0] x19,
    input  wire [15:0] x20,
    input  wire [15:0] x21,
    input  wire [15:0] x22,
    input  wire [15:0] x23,

    input  wire [15:0] x24,
    input  wire [15:0] x25,
    input  wire [15:0] x26,
    input  wire [15:0] x27,
    input  wire [15:0] x28,
    input  wire [15:0] x29,
    input  wire [15:0] x30,
    input  wire [15:0] x31,

    input  wire [15:0] x32,

    output reg  [15:0] data_out,
    output reg         o_valid
);

    // ============================================================
    // 1. 输入乘2
    //
    // 16位输入最大为65535：
    // 65535 × 2 = 131070
    // 因此使用17位保存。
    // ============================================================
    wire [16:0] datain_scaled;
    wire [31:0] datain_scaled_ext;

    assign datain_scaled =
        {1'b0, datain_Linearization} << 1;

    assign datain_scaled_ext =
        {15'd0, datain_scaled};


    // ============================================================
    // 2. 计算原始区间编号和区间内偏移
    //
    // raw_index_full = datain_scaled / STEP
    // rem_full       = datain_scaled % STEP
    //
    // STEP必须为非0参数。
    // ============================================================
    wire [31:0] raw_index_full;
    wire [31:0] rem_full;

    assign raw_index_full =
        datain_scaled_ext / STEP;

    assign rem_full =
        datain_scaled_ext % STEP;


    // ============================================================
    // 3. 区间边界处理
    //
    // 共33个点：
    // x0～x32
    //
    // 共32个有效插值区间：
    // 区间0： x0  ～ x1
    // ...
    // 区间31：x31 ～ x32
    //
    // 当raw_index >= 32时：
    // 固定使用最后一个区间，并令offset=STEP，
    // 这样插值结果正好等于x32。
    // ============================================================
    wire       clamp_to_x32;
    wire [4:0] segment_index;
    wire [16:0] offset;

    assign clamp_to_x32 =
        (raw_index_full >= 32'd32);

    assign segment_index =
        clamp_to_x32 ? 5'd31 :
                       raw_index_full[4:0];

    assign offset =
        clamp_to_x32 ? STEP[16:0] :
                       rem_full[16:0];


    // ============================================================
    // 4. 根据区间编号选择当前区间的两个端点
    //
    // 不再使用：
    // points[index]
    // points[index+1]
    //
    // 这样Formality不会再根据索引位宽报告数组越界。
    // ============================================================
    reg [15:0] y0;
    reg [15:0] y1;

    always @(*) begin
        // 默认值，防止组合逻辑锁存器
        y0 = x31;
        y1 = x32;

        case (segment_index)

            5'd0: begin
                y0 = x0;
                y1 = x1;
            end

            5'd1: begin
                y0 = x1;
                y1 = x2;
            end

            5'd2: begin
                y0 = x2;
                y1 = x3;
            end

            5'd3: begin
                y0 = x3;
                y1 = x4;
            end

            5'd4: begin
                y0 = x4;
                y1 = x5;
            end

            5'd5: begin
                y0 = x5;
                y1 = x6;
            end

            5'd6: begin
                y0 = x6;
                y1 = x7;
            end

            5'd7: begin
                y0 = x7;
                y1 = x8;
            end

            5'd8: begin
                y0 = x8;
                y1 = x9;
            end

            5'd9: begin
                y0 = x9;
                y1 = x10;
            end

            5'd10: begin
                y0 = x10;
                y1 = x11;
            end

            5'd11: begin
                y0 = x11;
                y1 = x12;
            end

            5'd12: begin
                y0 = x12;
                y1 = x13;
            end

            5'd13: begin
                y0 = x13;
                y1 = x14;
            end

            5'd14: begin
                y0 = x14;
                y1 = x15;
            end

            5'd15: begin
                y0 = x15;
                y1 = x16;
            end

            5'd16: begin
                y0 = x16;
                y1 = x17;
            end

            5'd17: begin
                y0 = x17;
                y1 = x18;
            end

            5'd18: begin
                y0 = x18;
                y1 = x19;
            end

            5'd19: begin
                y0 = x19;
                y1 = x20;
            end

            5'd20: begin
                y0 = x20;
                y1 = x21;
            end

            5'd21: begin
                y0 = x21;
                y1 = x22;
            end

            5'd22: begin
                y0 = x22;
                y1 = x23;
            end

            5'd23: begin
                y0 = x23;
                y1 = x24;
            end

            5'd24: begin
                y0 = x24;
                y1 = x25;
            end

            5'd25: begin
                y0 = x25;
                y1 = x26;
            end

            5'd26: begin
                y0 = x26;
                y1 = x27;
            end

            5'd27: begin
                y0 = x27;
                y1 = x28;
            end

            5'd28: begin
                y0 = x28;
                y1 = x29;
            end

            5'd29: begin
                y0 = x29;
                y1 = x30;
            end

            5'd30: begin
                y0 = x30;
                y1 = x31;
            end

            5'd31: begin
                y0 = x31;
                y1 = x32;
            end

            default: begin
                y0 = x31;
                y1 = x32;
            end

        endcase
    end


    // ============================================================
    // 5. 线性插值计算
    //
    // y = y0 + ((y1-y0) × offset) / STEP
    // ============================================================

    // y0、y1为16位无符号数。
    // 前面补0后转换成17位有符号数，保证相减正确。
    wire signed [16:0] diff_y;

    assign diff_y =
        $signed({1'b0, y1}) -
        $signed({1'b0, y0});


    // offset原本为17位无符号数。
    // 前面补0，转换成18位正有符号数。
    wire signed [17:0] offset_signed;

    assign offset_signed =
        $signed({1'b0, offset});


    // 17位 × 18位 = 35位
    wire signed [34:0] mult;

    assign mult =
        diff_y * offset_signed;


    // STEP前面补0，防止STEP[31]=1时被解释成负数
    wire signed [32:0] step_signed;

    assign step_signed =
        $signed({1'b0, STEP});


    // 除法结果先保留完整位宽
    wire signed [34:0] delta_wide;

    assign delta_wide =
        mult / step_signed;


    // 在当前插值约束下：
    // delta范围不会超过-65535～+65535，
    // 17位有符号数足够保存。
    wire signed [16:0] delta;

    assign delta =
        delta_wide[16:0];


    // 插值结果
    wire signed [16:0] y_interp_signed;
    wire        [15:0] y_interp;

    assign y_interp_signed =
        $signed({1'b0, y0}) + delta;

    assign y_interp =
        y_interp_signed[15:0];


    // ============================================================
    // 6. 输出寄存器
    // ============================================================
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            data_out <= 16'd0;
            o_valid  <= 1'b0;
        end else begin
            o_valid <= 1'b0;
            if (i_valid) begin
                if (en)
                    data_out <= y_interp;
                else
                    data_out <= datain_Linearization;
                o_valid <= 1'b1;
            end
        end
    end

endmodule