`timescale 1ns / 1ps

// ============================================================================
// Competition PS+PL version
//
// Design rule:
//   * PS calculates max/min, phase coarse/fine K/Gain and writes them to PL.
//   * PL only performs deterministic real-time processing.
//   * No automatic max/min scan and no automatic K/Gain calculation are used
//     in this top-level path.
//   * Every calibration stage has an explicit enable/bypass switch.
//
// Channel convention:
//   data_in1 = Y / Sin
//   data_in2 = X / Cos
// ============================================================================
module FIR_PHASE_NORM_CORDIC #(
    parameter DATA_WIDTH = 14,
    parameter K_WIDTH    = 16
)(
    input  wire                    clk,
    input  wire                    rst_n,

    // FIR/CIC configuration
    input  wire                    fir_mode,
    input  wire [2:0]              fre_ctrl,

    // Normalization: parameters are calculated by PS
    input  wire                    norm_en,
    input  wire [DATA_WIDTH-1:0]   manual_max_x,
    input  wire [DATA_WIDTH-1:0]   manual_min_x,
    input  wire [DATA_WIDTH-1:0]   manual_max_y,
    input  wire [DATA_WIDTH-1:0]   manual_min_y,

    // Phase coarse stage
    input  wire                    phase_coarse_en,
    input  wire signed [15:0]      manual_k_coarse,
    input  wire        [15:0]      manual_gain_coarse,

    // Phase fine stage.  When coarse+fine are both enabled the fine stage
    // operates on the coarse-corrected X/Y, matching the calibration flow.
    input  wire                    phase_fine_en,
    input  wire signed [15:0]      manual_k_fine,
    input  wire        [15:0]      manual_gain_fine,

    // Y/Sin and X/Cos input
    input  wire [DATA_WIDTH-1:0]   data_in1,
    input  wire [DATA_WIDTH-1:0]   data_in2,

    input  wire [15:0]             zero,

    // Final CORDIC output
    output wire [15:0]             angle_raw,
    output wire                    angle_valid,

    // Stage monitor ports for PS. PS can poll the corresponding valid/counter
    // in DSP_TOP and read the latest sample without a FIFO/BRAM.
    output wire [DATA_WIDTH-1:0]   filter_out_y,
    output wire [DATA_WIDTH-1:0]   filter_out_x,
    output wire                    filter_valid_out,

    output wire [DATA_WIDTH-1:0]   norm_out_y,
    output wire [DATA_WIDTH-1:0]   norm_out_x,
    output wire                    norm_valid_out,

    output wire [DATA_WIDTH-1:0]   coarse_out_y,
    output wire [DATA_WIDTH-1:0]   coarse_out_x,
    output wire                    coarse_valid_out,

    output wire [DATA_WIDTH-1:0]   calib_out_y,
    output wire [DATA_WIDTH-1:0]   calib_out_x,
    output wire                    phase_valid_out
);

// ---------------------------------------------------------------------------
// Reset: asynchronous assertion, synchronous release
// ---------------------------------------------------------------------------
reg rst_n_d1;
reg rst_n_d2;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        rst_n_d1 <= 1'b0;
        rst_n_d2 <= 1'b0;
    end else begin
        rst_n_d1 <= 1'b1;
        rst_n_d2 <= rst_n_d1;
    end
end
wire sys_rst_n = rst_n_d2;

// ---------------------------------------------------------------------------
// 1. Filter chain: median + average + CIC + FIR
// ---------------------------------------------------------------------------
wire [DATA_WIDTH-1:0] filter_y_w;
wire [DATA_WIDTH-1:0] filter_x_w;
wire                  filter_valid_w;

FILTER_TOP #(
    .DATA_WIDTH(DATA_WIDTH)
) u_filter_top (
    .clk               (clk),
    .rst_n             (sys_rst_n),
    .fir_mode          (fir_mode),
    .freq_sel          (fre_ctrl),
    .data_in1          (data_in1),
    .data_in2          (data_in2),
    .filter_data_out_1 (filter_y_w),
    .filter_data_out_2 (filter_x_w),
    .filter_valid      (filter_valid_w)
);

assign filter_out_y     = filter_y_w;
assign filter_out_x     = filter_x_w;
assign filter_valid_out = filter_valid_w;

// ---------------------------------------------------------------------------
// 2. Manual normalization controlled by PS
// ---------------------------------------------------------------------------
wire [DATA_WIDTH-1:0] norm_x_calc;
wire [DATA_WIDTH-1:0] norm_y_calc;
wire                  norm_x_valid;
wire                  norm_y_valid;
wire                  norm_calc_valid = norm_x_valid & norm_y_valid;

normalization #(
    .DATA_WIDTH (DATA_WIDTH),
    .MAX_VAL    (14'd16383),
    .TARGET_MAX (14'd16000),
    .TARGET_MIN (14'd384)
) u_norm_x (
    .clk          (clk),
    .rst_n        (sys_rst_n),
    .i_valid      (filter_valid_w & norm_en),
    .data_in_nor  (filter_x_w),
    .datamax      (manual_max_x),
    .datamin      (manual_min_x),
    .data_out_nor (norm_x_calc),
    .o_valid      (norm_x_valid)
);

normalization #(
    .DATA_WIDTH (DATA_WIDTH),
    .MAX_VAL    (14'd16383),
    .TARGET_MAX (14'd16000),
    .TARGET_MIN (14'd384)
) u_norm_y (
    .clk          (clk),
    .rst_n        (sys_rst_n),
    .i_valid      (filter_valid_w & norm_en),
    .data_in_nor  (filter_y_w),
    .datamax      (manual_max_y),
    .datamin      (manual_min_y),
    .data_out_nor (norm_y_calc),
    .o_valid      (norm_y_valid)
);

wire [DATA_WIDTH-1:0] norm_sel_x = norm_en ? norm_x_calc : filter_x_w;
wire [DATA_WIDTH-1:0] norm_sel_y = norm_en ? norm_y_calc : filter_y_w;
wire                  norm_sel_valid = norm_en ? norm_calc_valid : filter_valid_w;

assign norm_out_x     = norm_sel_x;
assign norm_out_y     = norm_sel_y;
assign norm_valid_out = norm_sel_valid;

// ---------------------------------------------------------------------------
// 3. Coarse phase correction: Ycorr = Y - k*X, then gain compensation
// ---------------------------------------------------------------------------
wire [DATA_WIDTH-1:0] coarse_corr_x;
wire [DATA_WIDTH-1:0] coarse_corr_y;
wire                  coarse_corr_valid;
wire [DATA_WIDTH-1:0] coarse_calc_x;
wire [DATA_WIDTH-1:0] coarse_calc_y;
wire                  coarse_calc_valid;

phase_calib #(
    .DATA_WIDTH (DATA_WIDTH),
    .ADC_OFFSET (16'sd8192)
) u_phase_coarse (
    .clk            (clk),
    .rst_n          (sys_rst_n),
    .i_valid        (norm_sel_valid & phase_coarse_en),
    .x_in_unsigned  (norm_sel_x),
    .y_in_unsigned  (norm_sel_y),
    .k_factor       (manual_k_coarse),
    .x_out_unsigned (coarse_corr_x),
    .y_out_unsigned (coarse_corr_y),
    .o_valid        (coarse_corr_valid)
);

amp_compensation #(
    .DATA_WIDTH (DATA_WIDTH),
    .ADC_OFFSET (16'sd8192)
) u_gain_coarse (
    .clk            (clk),
    .rst_n          (sys_rst_n),
    .i_valid        (coarse_corr_valid),
    .x_in_unsigned  (coarse_corr_x),
    .y_in_unsigned  (coarse_corr_y),
    .gain_factor    (manual_gain_coarse),
    .x_out_unsigned (coarse_calc_x),
    .y_out_unsigned (coarse_calc_y),
    .o_valid        (coarse_calc_valid)
);

wire [DATA_WIDTH-1:0] coarse_sel_x = phase_coarse_en ? coarse_calc_x : norm_sel_x;
wire [DATA_WIDTH-1:0] coarse_sel_y = phase_coarse_en ? coarse_calc_y : norm_sel_y;
wire                  coarse_sel_valid = phase_coarse_en ? coarse_calc_valid : norm_sel_valid;

assign coarse_out_x     = coarse_sel_x;
assign coarse_out_y     = coarse_sel_y;
assign coarse_valid_out = coarse_sel_valid;

// ---------------------------------------------------------------------------
// 4. Fine phase correction.  Fine operates on coarse output when coarse is on.
// ---------------------------------------------------------------------------
wire [DATA_WIDTH-1:0] fine_corr_x;
wire [DATA_WIDTH-1:0] fine_corr_y;
wire                  fine_corr_valid;
wire [DATA_WIDTH-1:0] fine_calc_x;
wire [DATA_WIDTH-1:0] fine_calc_y;
wire                  fine_calc_valid;

phase_calib #(
    .DATA_WIDTH (DATA_WIDTH),
    .ADC_OFFSET (16'sd8192)
) u_phase_fine (
    .clk            (clk),
    .rst_n          (sys_rst_n),
    .i_valid        (coarse_sel_valid & phase_fine_en),
    .x_in_unsigned  (coarse_sel_x),
    .y_in_unsigned  (coarse_sel_y),
    .k_factor       (manual_k_fine),
    .x_out_unsigned (fine_corr_x),
    .y_out_unsigned (fine_corr_y),
    .o_valid        (fine_corr_valid)
);

amp_compensation #(
    .DATA_WIDTH (DATA_WIDTH),
    .ADC_OFFSET (16'sd8192)
) u_gain_fine (
    .clk            (clk),
    .rst_n          (sys_rst_n),
    .i_valid        (fine_corr_valid),
    .x_in_unsigned  (fine_corr_x),
    .y_in_unsigned  (fine_corr_y),
    .gain_factor    (manual_gain_fine),
    .x_out_unsigned (fine_calc_x),
    .y_out_unsigned (fine_calc_y),
    .o_valid        (fine_calc_valid)
);

wire [DATA_WIDTH-1:0] phase_sel_x = phase_fine_en ? fine_calc_x : coarse_sel_x;
wire [DATA_WIDTH-1:0] phase_sel_y = phase_fine_en ? fine_calc_y : coarse_sel_y;
wire                  phase_sel_valid = phase_fine_en ? fine_calc_valid : coarse_sel_valid;

assign calib_out_x     = phase_sel_x;
assign calib_out_y     = phase_sel_y;
assign phase_valid_out = phase_sel_valid;

// ---------------------------------------------------------------------------
// 5. CORDIC angle, 0..36000 (0.01 degree/LSB)
// ---------------------------------------------------------------------------
cordic_top u_cordic_top (
    .clk             (clk),
    .rst_n           (sys_rst_n),
    .i_valid         (phase_sel_valid),
    .data_in1        (phase_sel_x),
    .data_in2        (phase_sel_y),
    .zero            (zero),
    .angle_slove_raw (angle_raw),
    .angle_valid     (angle_valid)
);

endmodule

module FILTER_TOP #(
    parameter DATA_WIDTH = 14
)(
    input  wire [DATA_WIDTH-1:0] data_in1,
    input  wire [DATA_WIDTH-1:0] data_in2,

    input  wire                  fir_mode,
    input  wire                  clk,
    input  wire [2:0]            freq_sel,
    input  wire                  rst_n,

    output wire [DATA_WIDTH-1:0] filter_data_out_1,
    output wire [DATA_WIDTH-1:0] filter_data_out_2,
    output wire                  filter_valid
);

    wire filter_valid_1;
    wire filter_valid_2;

    assign filter_valid = filter_valid_1 & filter_valid_2;

    // ------------------------------------------------------------------------
    // Channel 1
    // ------------------------------------------------------------------------
    FIR_filter #(
        .DATA_WIDTH(DATA_WIDTH)
    ) FIR_filter_1 (
        .clk        (clk),
        .rst_n      (rst_n),

        .fir_mode   (fir_mode),
        .freq_sel   (freq_sel),

        .data_in    (data_in1),

        .data_out   (filter_data_out_1),
        .data_valid (filter_valid_1)
    );

    // ------------------------------------------------------------------------
    // Channel 2
    // ------------------------------------------------------------------------
    FIR_filter #(
        .DATA_WIDTH(DATA_WIDTH)
    ) FIR_filter_2 (
        .clk        (clk),
        .rst_n      (rst_n),

        .fir_mode   (fir_mode),
        .freq_sel   (freq_sel),

        .data_in    (data_in2),

        .data_out   (filter_data_out_2),
        .data_valid (filter_valid_2)
    );

endmodule


// ============================================================================
// FIR_filter
//
// 10 MHz
//   -> 中值滤波
//   -> 均值滤波
//   -> CIC降采样：10 MHz -> 1 kHz
//   -> 16-Tap FIR
// ============================================================================
`timescale 1ns / 1ps

module FIR_filter #(
    parameter DATA_WIDTH = 14
)(
    input  wire [DATA_WIDTH-1:0] data_in,
    input  wire                  fir_mode,
    input  wire [2:0]            freq_sel,

    input  wire                  clk,
    input  wire                  rst_n,

    output wire [DATA_WIDTH-1:0] data_out,
    output reg                   data_valid
);

    wire [DATA_WIDTH-1:0] data_out_m;
    wire [DATA_WIDTH-1:0] data_out_a;
    wire [DATA_WIDTH-1:0] data_out_cic;

    reg sample_en;

    reg [5:0] warmup_samples;

    // ========================================================================
    // 10 MHz / 10000 = 1 kHz
    // ========================================================================
    localparam integer DECIMATION = 10000;

    reg [13:0] cnt;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            cnt       <= 14'd0;
            sample_en <= 1'b0;
        end
        else begin
            if (cnt == DECIMATION - 1) begin
                cnt       <= 14'd0;
                sample_en <= 1'b1;
            end
            else begin
                cnt       <= cnt + 1'b1;
                sample_en <= 1'b0;
            end
        end
    end

    // ========================================================================
    // 启动等待
    // ========================================================================
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            data_valid    <= 1'b0;
            warmup_samples <= 6'd0;
        end
        else begin
            data_valid <= 1'b0;

            if (sample_en) begin
                if (warmup_samples < 6'd32)
                    warmup_samples <= warmup_samples + 1'b1;

                if (warmup_samples >= 6'd31)
                    data_valid <= 1'b1;
            end
        end
    end

    // ========================================================================
    // 1. 中值滤波
    // ========================================================================
    mfilter #(
        .DATA_WIDTH(DATA_WIDTH)
    ) mfilter_1 (
        .clk      (clk),
        .rst_n    (rst_n),
        .data_in  (data_in),
        .data_out (data_out_m)
    );

    // ========================================================================
    // 2. 均值滤波
    // ========================================================================
    afilter #(
        .DATA_WIDTH(DATA_WIDTH)
    ) afilter_1 (
        .clk      (clk),
        .rst_n    (rst_n),
        .data_in  (data_out_m),
        .data_out (data_out_a)
    );

    // ========================================================================
    // 3. CIC：10 MHz -> 1 kHz
    // ========================================================================
    cic_decimator #(
        .DATA_WIDTH(DATA_WIDTH)
    ) cic_1 (
        .clk       (clk),
        .rst_n     (rst_n),

        .sample_en (sample_en),

        .data_in   (data_out_a),
        .data_out  (data_out_cic)
    );

    // ========================================================================
    // 4. FIR
    // ========================================================================
    FIR #(
        .DATA_WIDTH(DATA_WIDTH)
    ) firr_1 (
        .clk           (clk),
        .rst_n         (rst_n),

        .sample_en     (sample_en),

        .fir_mode      (fir_mode),
        .freq_sel      (freq_sel),

        .din_unsigned  (data_out_cic),
        .dout_unsigned (data_out)
    );

endmodule


// ============================================================================
// CIC Decimator
//
// 三级 CIC：
// 10 MHz -> 1 kHz
//
// R = 10000
// N = 3
// CIC Gain = 10000^3 = 1e12
// ============================================================================
`timescale 1ns / 1ps

module cic_decimator #(
    parameter DATA_WIDTH = 14
)(
    input  wire                  clk,
    input  wire                  rst_n,
    input  wire                  sample_en,

    input  wire [DATA_WIDTH-1:0] data_in,
    output wire [DATA_WIDTH-1:0] data_out
);

    localparam CIC_WIDTH = 54;

    // ========================================================================
    // Offset Binary -> Signed
    // ========================================================================
    wire signed [14:0]          din_signed;
    wire signed [CIC_WIDTH-1:0] din_ext;

    assign din_signed =
        $signed({1'b0, data_in}) - 15'sd8192;

    assign din_ext = din_signed;

    // ========================================================================
    // 3级积分器
    // ========================================================================
    reg signed [CIC_WIDTH-1:0] int1;
    reg signed [CIC_WIDTH-1:0] int2;
    reg signed [CIC_WIDTH-1:0] int3;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            int1 <= 0;
            int2 <= 0;
            int3 <= 0;
        end
        else begin
            int1 <= int1 + din_ext;
            int2 <= int2 + int1;
            int3 <= int3 + int2;
        end
    end

    // ========================================================================
    // 3级梳状器
    // ========================================================================
    reg signed [CIC_WIDTH-1:0] int3_d;

    reg signed [CIC_WIDTH-1:0] comb1;
    reg signed [CIC_WIDTH-1:0] comb1_d;

    reg signed [CIC_WIDTH-1:0] comb2;
    reg signed [CIC_WIDTH-1:0] comb2_d;

    reg signed [CIC_WIDTH-1:0] comb3;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            int3_d  <= 0;

            comb1   <= 0;
            comb1_d <= 0;

            comb2   <= 0;
            comb2_d <= 0;

            comb3   <= 0;
        end
        else if (sample_en) begin
            int3_d <= int3;

            comb1   <= int3 - int3_d;
            comb1_d <= comb1;

            comb2   <= comb1 - comb1_d;
            comb2_d <= comb2;

            comb3   <= comb2 - comb2_d;
        end
    end

    // ========================================================================
    // CIC 增益补偿
    //
    // comb3 / 10000^3
    //
    // 近似：
    // 先除 2^40
    // 再乘约 1.1
    // ========================================================================
    wire signed [53:0] cic_shift;

    assign cic_shift = comb3 >>> 40;

    wire signed [53:0] cic_gain_comp;

    assign cic_gain_comp =
        cic_shift +
        cic_shift / 10;

    // ========================================================================
    // 饱和
    // ========================================================================
    reg signed [13:0] cic_signed;

    always @(*) begin
        if (cic_gain_comp > 8191)
            cic_signed = 14'sd8191;
        else if (cic_gain_comp < -8192)
            cic_signed = -14'sd8192;
        else
            cic_signed = cic_gain_comp[13:0];
    end

    // ========================================================================
    // Signed -> Offset Binary
    // ========================================================================
    assign data_out =
        $unsigned(cic_signed + 14'sd8192);

endmodule
module FIR #(
    parameter DATA_WIDTH = 14
)(
    input  wire                  clk,
    input  wire                  rst_n,

    input  wire                  sample_en,

    input  wire                  fir_mode,
    input  wire [2:0]            freq_sel,

    input  wire [DATA_WIDTH-1:0] din_unsigned,
    output wire [DATA_WIDTH-1:0] dout_unsigned
);

    // ========================================================================
    // Q1.15 系数
    // 对称16阶滤波器，只需要保存8个系数
    // ========================================================================
    reg signed [15:0] c0;
    reg signed [15:0] c1;
    reg signed [15:0] c2;
    reg signed [15:0] c3;
    reg signed [15:0] c4;
    reg signed [15:0] c5;
    reg signed [15:0] c6;
    reg signed [15:0] c7;

    always @(*) begin
        if (!fir_mode) begin
            c0 = 16'd178;
            c1 = 16'd323;
            c2 = 16'd729;
            c3 = 16'd1406;
            c4 = 16'd2275;
            c5 = 16'd3181;
            c6 = 16'd3933;
            c7 = 16'd4360;
        end
        else begin
            case (freq_sel)

                // ------------------------------------------------------------
                // 10 Hz
                // ------------------------------------------------------------
                3'd0: begin
                    c0 = 16'd311;
                    c1 = 16'd469;
                    c2 = 16'd917;
                    c3 = 16'd1582;
                    c4 = 16'd2352;
                    c5 = 16'd3091;
                    c6 = 16'd3671;
                    c7 = 16'd3990;
                end

                // ------------------------------------------------------------
                // 50 Hz
                // ------------------------------------------------------------
                3'd1: begin
                    c0 = 16'd112;
                    c1 = 16'd243;
                    c2 = 16'd618;
                    c3 = 16'd1293;
                    c4 = 16'd2217;
                    c5 = 16'd3225;
                    c6 = 16'd4089;
                    c7 = 16'd4587;
                end

                // ------------------------------------------------------------
                // 100 Hz
                // ------------------------------------------------------------
                3'd2: begin
                    c0 = -16'd114;
                    c1 = -16'd159;
                    c2 = -16'd139;
                    c3 =  16'd291;
                    c4 =  16'd1450;
                    c5 =  16'd3284;
                    c6 =  16'd5246;
                    c7 =  16'd6524;
                end

                // ------------------------------------------------------------
                // 150 Hz
                // ------------------------------------------------------------
                3'd3: begin
                    c0 =  16'd78;
                    c1 = -16'd30;
                    c2 = -16'd390;
                    c3 = -16'd817;
                    c4 = -16'd273;
                    c5 =  16'd2259;
                    c6 =  16'd6231;
                    c7 =  16'd9325;
                end

                // ------------------------------------------------------------
                // 200 Hz
                // ------------------------------------------------------------
                3'd4: begin
                    c0 =  16'd0;
                    c1 =  16'd183;
                    c2 =  16'd259;
                    c3 = -16'd541;
                    c4 = -16'd1665;
                    c5 =  16'd0;
                    c6 =  16'd6025;
                    c7 =  16'd12124;
                end

                // ------------------------------------------------------------
                // 250 Hz
                // ------------------------------------------------------------
                3'd5: begin
                    c0 = -16'd79;
                    c1 = -16'd136;
                    c2 =  16'd312;
                    c3 =  16'd654;
                    c4 = -16'd1244;
                    c5 = -16'd2280;
                    c6 =  16'd4501;
                    c7 =  16'd14655;
                end

                // ------------------------------------------------------------
                // 300 Hz
                // ------------------------------------------------------------
                3'd6: begin
                    c0 =  16'd111;
                    c1 = -16'd59;
                    c2 = -16'd355;
                    c3 =  16'd744;
                    c4 =  16'd540;
                    c5 = -16'd3202;
                    c6 =  16'd1954;
                    c7 =  16'd16652;
                end

                // ------------------------------------------------------------
                // 400 Hz
                // ------------------------------------------------------------
                3'd7: begin
                    c0 =  16'd0;
                    c1 = -16'd113;
                    c2 =  16'd419;
                    c3 = -16'd878;
                    c4 =  16'd1031;
                    c5 =  16'd0;
                    c6 = -16'd3731;
                    c7 =  16'd19656;
                end

                // ------------------------------------------------------------
                // 默认：100 Hz
                // ------------------------------------------------------------
                default: begin
                    c0 = -16'd114;
                    c1 = -16'd159;
                    c2 = -16'd139;
                    c3 =  16'd291;
                    c4 =  16'd1450;
                    c5 =  16'd3284;
                    c6 =  16'd5246;
                    c7 =  16'd6524;
                end

            endcase
        end
    end

    // ========================================================================
    // Offset Binary -> Signed
    // ========================================================================
    reg signed [DATA_WIDTH-1:0] din_signed;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            din_signed <= 0;
        end
        else if (sample_en) begin
            din_signed <= {
                ~din_unsigned[DATA_WIDTH-1],
                 din_unsigned[DATA_WIDTH-2:0]
            };
        end
    end

    // ========================================================================
    // 16 Tap Delay Line
    // ========================================================================
    reg signed [DATA_WIDTH-1:0] tap [0:15];

    integer tap_idx;
    integer pre_idx;
    integer prod_idx;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            for (tap_idx = 0; tap_idx < 16; tap_idx = tap_idx + 1)
                tap[tap_idx] <= 0;
        end
        else if (sample_en) begin
            tap[0] <= din_signed;

            for (tap_idx = 1; tap_idx < 16; tap_idx = tap_idx + 1)
                tap[tap_idx] <= tap[tap_idx-1];
        end
    end

    // ========================================================================
    // Pre-Adder
    // ========================================================================
    reg signed [DATA_WIDTH:0] pre_add [0:7];

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            for (pre_idx = 0; pre_idx < 8; pre_idx = pre_idx + 1)
                pre_add[pre_idx] <= 0;
        end
        else if (sample_en) begin
            pre_add[0] <= tap[0] + tap[15];
            pre_add[1] <= tap[1] + tap[14];
            pre_add[2] <= tap[2] + tap[13];
            pre_add[3] <= tap[3] + tap[12];
            pre_add[4] <= tap[4] + tap[11];
            pre_add[5] <= tap[5] + tap[10];
            pre_add[6] <= tap[6] + tap[9];
            pre_add[7] <= tap[7] + tap[8];
        end
    end

    // ========================================================================
    // Multipliers
    // ========================================================================
    reg signed [DATA_WIDTH+16:0] prod [0:7];

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            for (prod_idx = 0; prod_idx < 8; prod_idx = prod_idx + 1)
                prod[prod_idx] <= 0;
        end
        else if (sample_en) begin
            prod[0] <= pre_add[0] * c0;
            prod[1] <= pre_add[1] * c1;
            prod[2] <= pre_add[2] * c2;
            prod[3] <= pre_add[3] * c3;
            prod[4] <= pre_add[4] * c4;
            prod[5] <= pre_add[5] * c5;
            prod[6] <= pre_add[6] * c6;
            prod[7] <= pre_add[7] * c7;
        end
    end

    // ========================================================================
    // Adder Tree
    // ========================================================================
    reg signed [DATA_WIDTH+17:0] sum_stg1 [0:3];
    reg signed [DATA_WIDTH+18:0] sum_stg2 [0:1];
    reg signed [DATA_WIDTH+19:0] acc;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            sum_stg1[0] <= 0;
            sum_stg1[1] <= 0;
            sum_stg1[2] <= 0;
            sum_stg1[3] <= 0;

            sum_stg2[0] <= 0;
            sum_stg2[1] <= 0;

            acc <= 0;
        end
        else if (sample_en) begin
            // 8 -> 4
            sum_stg1[0] <= prod[0] + prod[1];
            sum_stg1[1] <= prod[2] + prod[3];
            sum_stg1[2] <= prod[4] + prod[5];
            sum_stg1[3] <= prod[6] + prod[7];

            // 4 -> 2
            sum_stg2[0] <= sum_stg1[0] + sum_stg1[1];
            sum_stg2[1] <= sum_stg1[2] + sum_stg1[3];

            // 2 -> 1
            acc <= sum_stg2[0] + sum_stg2[1];
        end
    end

    // ========================================================================
    // Rounding + 输出
    // ========================================================================
    wire signed [DATA_WIDTH+19:0] acc_rounded;

    assign acc_rounded = acc + 16'd16384;

    reg [DATA_WIDTH-1:0] dout_reg;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            dout_reg <= 0;
        end
        else if (sample_en) begin
            dout_reg <= {
                ~acc_rounded[DATA_WIDTH+15-1],
                 acc_rounded[DATA_WIDTH+15-2:15]
            };
        end
    end

    assign dout_unsigned = dout_reg;

endmodule

`timescale 1ns / 1ps
// ==========================================================================
// ????????: phase_top (???????-????????????????????????????????)
// ????????: [Raw???¤????] -> [?′?????ˇ???????? Coarse] -> [????????????] -> [???????ˇ???????? Fine] -> [???????????¤????]
// ==========================================================================
//module phase_top #(
//    parameter DATA_WIDTH = 14,
//    parameter K_WIDTH    = 16, 
//    parameter FRAC_WIDTH = 14  
//)(
//    input  wire                      clk,   
//    input  wire                      rst_n,

//    // =====================================
//    // ????????????????????????
//    // =====================================
//    // ???????????????′ 2 ?????????????????????ˇ???????????????????′???????????ˇ??????????
//    // 00: ???????????????¨
//    // 01: ???????????′?′?????ˇ (???????ˇ???????¨)
//    // 10: ???????′?′?????ˇ + ???????ˇ
//    input  wire [1:0]                calib_mode, 
    
//    // ???????????????? (?ˇ?????ˇ????????????????????????????????)
//    input  wire signed [K_WIDTH-1:0] manual_k_coarse,    
//    input  wire signed [K_WIDTH-1:0] manual_k_fine,      
//    input  wire signed [K_WIDTH-1:0] manual_gain_coarse, 
//    input  wire signed [K_WIDTH-1:0] manual_gain_fine,   

//    // ????????????????
//    input  wire [DATA_WIDTH-1:0]     raw_data_x,
//    input  wire [DATA_WIDTH-1:0]     raw_data_y,
    
//    output wire [DATA_WIDTH-1:0]     final_out_x,
//    output wire [DATA_WIDTH-1:0]     final_out_y,
//    output wire                      o_valid             
//);

//    // =============================================================
//    // 1. ???????????????? (?°?? 2 ???????????????????????????°???????????? 1 ???????? Enable ????????)
//    // =============================================================
//    // ???????????????? 00?????′?????ˇ????????????????
//    wire en_coarse = (calib_mode == 2'b01) || (calib_mode == 2'b10); 
//    // ???????????????? 10???????????ˇ????????????
//    wire en_fine   = (calib_mode == 2'b10);                          

//    // =============================================================
//    // 2. ???????????????????? (????????????????????????????????????????????)
//    // =============================================================
//    wire [DATA_WIDTH-1:0] mid_x;
//    wire [DATA_WIDTH-1:0] mid_y;
//    wire                  mid_valid;

//    // =============================================================
//    // 3. ???????????????¨?????′?????ˇ???????? (???????????????????′???? phase_amp_coarse)
//    // =============================================================
//    phase_amp_coarse #( 
//        .DATA_WIDTH(DATA_WIDTH), 
//        .K_WIDTH(K_WIDTH), 
//        .FRAC_WIDTH(FRAC_WIDTH) 
//    ) u_coarse_stage (
//        .clk                 (clk),
//        .rst_n               (rst_n),
//        .i_valid             (1'b1),               // ???????????′???ˇ???????????????????§
//        .calib_mode          (en_coarse),          // ?′?????? 1???? ????????????????
        
//        .manual_k_coarse     (manual_k_coarse),    // ?????????′?????ˇ K
//        .manual_gain_coarse  (manual_gain_coarse), // ?????????′?????ˇ Gain
        
//        .x_in                (raw_data_x), 
//        .y_in                (raw_data_y),
        
//        .x_out               (mid_x),              // ???¤????????????????????
//        .y_out               (mid_y),
//        .o_valid             (mid_valid)           // ???¤???????????????????§????????
//    );

//    // =============================================================
//    // 4. ???????????????¨???????????ˇ???????? (???????????????????′???? phase_amp_fine)
//    // =============================================================
//    phase_amp_fine #( 
//        .DATA_WIDTH(DATA_WIDTH), 
//        .K_WIDTH(K_WIDTH), 
//        .FRAC_WIDTH(FRAC_WIDTH) 
//    ) u_fine_stage (
//        .clk                 (clk),
//        .rst_n               (rst_n),
//        .i_valid             (mid_valid),          // ?????????′?????ˇ???????????? Valid
//        .calib_mode          (en_fine),            // ?′?????? 1???? ????????????????
        
//        .manual_k_fine       (manual_k_fine),      // ???????????????ˇ K
//        .manual_gain_fine    (manual_gain_fine),   // ???????????????ˇ Gain
        
//        .x_in                (mid_x),              // ????????????????????????????
//        .y_in                (mid_y),
        
//        .x_out               (final_out_x),        // ???????????¤????
//        .y_out               (final_out_y),
//        .o_valid             (o_valid)             // ???????? Valid ????????
//    );

//endmodule


//`timescale 1ns / 1ps
//// ==========================================================================
//// ????????: phase_amp_stage (???????????????????????????????¨)
//// ????????: [???¤????] -> [??? ????????????] -> [?ˇ??????????????] -> [???¤????] (???????ˇ????????????????????????)
//// ==========================================================================
//module phase_amp_coarse #(
//    parameter DATA_WIDTH = 14,
//    parameter K_WIDTH    = 16, 
//    parameter FRAC_WIDTH = 14  
//)(
//    input  wire                      clk,   
//    input  wire                      rst_n,
//    input  wire                      i_valid,

//    // ????????????????: 0 = ???????¨ (Bypass), 1 = ???′????????????
//    input  wire                      calib_mode,         
    
//    // ???¤???????????? (?????????????′?????ˇ???????????????????????????ˇ???????????????????????????????¨)
//    input  wire signed [K_WIDTH-1:0] manual_k_coarse,    // ???¤???? K ????
//    input  wire signed [K_WIDTH-1:0] manual_gain_coarse, // ???¤???? Gain ????

//    input  wire [DATA_WIDTH-1:0]     x_in,
//    input  wire [DATA_WIDTH-1:0]     y_in,

//    output reg  [DATA_WIDTH-1:0]     x_out,
//    output reg  [DATA_WIDTH-1:0]     y_out,
//    output reg                       o_valid             
//);

//    // =============================================================
//    // 0. ???????????????§???????¨????
//    // =============================================================
//    localparam signed [16:0] DC_OFFSET = 1 << (DATA_WIDTH - 1);
//    localparam signed [16:0] MAX_DATA  = (1 << DATA_WIDTH) - 1;
//    localparam signed [16:0] MIN_DATA  = 0;

//    localparam MULT_W  = 16 + K_WIDTH; 
//    localparam TRUNC_W = MULT_W - FRAC_WIDTH;
//    localparam signed [MULT_W-1:0] ROUND_HALF = 64'sd1 << (FRAC_WIDTH - 1); 

//    // =============================================================
//    // 1. ???????????¤?′?????- (???????????ˇ)
//    // =============================================================
//    wire signed [15:0] x_signed = $signed({2'b0, x_in}) - DC_OFFSET[15:0];
//    wire signed [15:0] y_signed = $signed({2'b0, y_in}) - DC_OFFSET[15:0];

//    // ???????? Enable ???????¨???????? (1.0???? ???????????? Gain ???? 16384)
//    wire signed [K_WIDTH-1:0] active_k    = calib_mode ? manual_k_coarse    : 16'sd0;
//    wire signed [K_WIDTH-1:0] active_gain = calib_mode ? manual_gain_coarse : (16'sd1 << FRAC_WIDTH);

//    // =============================================================
//    // 2. ???ˇ???????? Stage 1: ??? ?????????????????ˇ?¨
//    // =============================================================
//    reg signed [MULT_W-1:0] phase_mult_s1;
//    reg signed [15:0]       x_s1, y_s1;
//    reg                     valid_s1;

//    always @(posedge clk or negedge rst_n) begin
//        if (!rst_n) begin
//            phase_mult_s1 <= 0;
//            x_s1 <= 0; y_s1 <= 0;
//            valid_s1 <= 0;
//        end else begin
//            valid_s1      <= i_valid;
//            if (i_valid) begin
//                phase_mult_s1 <= x_signed * active_k; // X * K
//                x_s1          <= x_signed;            // ?????????′??????
//                y_s1          <= y_signed;
//            end
//        end
//    end

//    // =============================================================
//    // 3. ???ˇ???????? Stage 2: ??? ?????????????????ˇ?¨ & ?ˇ???????????????????ˇ?¨
//    // =============================================================
//    // ??????????? ????????????????Y_new = Y_old - (X * K)
//    wire signed [16:0] phase_y_ext = $signed({ {1{y_s1[15]}}, y_s1 });
//    wire signed [16:0] phase_y_raw = phase_y_ext - $signed(phase_mult_s1 >>> FRAC_WIDTH);
    
//    reg signed [MULT_W-1:0] amp_mult_s2;
//    reg signed [15:0]       x_s2;
//    reg                     valid_s2;

//    always @(posedge clk or negedge rst_n) begin
//        if (!rst_n) begin
//            amp_mult_s2 <= 0;
//            x_s2 <= 0;
//            valid_s2 <= 0;
//        end else begin
//            valid_s2 <= valid_s1;
//            if (valid_s1) begin
//                // ?????????????????ˇ???????ˇ???′??????Y_final = Y_new * Gain
//                amp_mult_s2 <= phase_y_raw * active_gain;
//                x_s2        <= x_s1;
//            end
//        end
//    end

//    // =============================================================
//    // 4. ???ˇ???????? Stage 3: ?ˇ?????????????????????????????????ˇ???????¤????????????
//    // =============================================================
//    wire signed [MULT_W-1:0] amp_add_half = amp_mult_s2 + ROUND_HALF;
//    wire signed [TRUNC_W-1:0] amp_trunc   = amp_add_half >>> FRAC_WIDTH;
    
//    // Y ???????′ DC
//    wire signed [TRUNC_W:0] y_final_dc = amp_trunc + DC_OFFSET;
//    // X ???????′ DC
//    wire signed [16:0] x_final_dc = $signed({ {1{x_s2[15]}}, x_s2 }) + DC_OFFSET;

//    always @(posedge clk or negedge rst_n) begin
//        if (!rst_n) begin
//            x_out   <= DC_OFFSET[DATA_WIDTH-1:0];
//            y_out   <= DC_OFFSET[DATA_WIDTH-1:0];
//            o_valid <= 0;
//        end else begin
//            o_valid <= valid_s2;
//            if (valid_s2) begin
//                // Y ???¨???????????????????¤
//                if (y_final_dc > MAX_DATA)       y_out <= MAX_DATA[DATA_WIDTH-1:0];
//                else if (y_final_dc < MIN_DATA)  y_out <= MIN_DATA[DATA_WIDTH-1:0];
//                else                             y_out <= y_final_dc[DATA_WIDTH-1:0];
                
//                // X ???¨???????????????????¤
//                if (x_final_dc > MAX_DATA)       x_out <= MAX_DATA[DATA_WIDTH-1:0];
//                else if (x_final_dc < MIN_DATA)  x_out <= MIN_DATA[DATA_WIDTH-1:0];
//                else                             x_out <= x_final_dc[DATA_WIDTH-1:0];
//            end
//        end
//    end

//endmodule

//`timescale 1ns / 1ps
//// ==========================================================================
//// ????????: phase_amp_stage (???????????????????????????????¨)
//// ????????: [???¤????] -> [??? ????????????] -> [?ˇ??????????????] -> [???¤????] (???????ˇ????????????????????????)
//// ==========================================================================
//module phase_amp_fine #(
//    parameter DATA_WIDTH = 14,
//    parameter K_WIDTH    = 16, 
//    parameter FRAC_WIDTH = 14  
//)(
//    input  wire                      clk,   
//    input  wire                      rst_n,
//    input  wire                      i_valid,

//    // ????????????????: 0 = ???????¨ (Bypass), 1 = ???′????????????
//    input  wire                      calib_mode,         
    
//    // ???¤???????????? (?????????????′?????ˇ???????????????????????????ˇ???????????????????????????????¨)
//    input  wire signed [K_WIDTH-1:0] manual_k_fine,    // ???¤???? K ????
//    input  wire signed [K_WIDTH-1:0] manual_gain_fine, // ???¤???? Gain ????

//    input  wire [DATA_WIDTH-1:0]     x_in,
//    input  wire [DATA_WIDTH-1:0]     y_in,

//    output reg  [DATA_WIDTH-1:0]     x_out,
//    output reg  [DATA_WIDTH-1:0]     y_out,
//    output reg                       o_valid             
//);

//    // =============================================================
//    // 0. ???????????????§???????¨????
//    // =============================================================
//    localparam signed [16:0] DC_OFFSET = 1 << (DATA_WIDTH - 1);
//    localparam signed [16:0] MAX_DATA  = (1 << DATA_WIDTH) - 1;
//    localparam signed [16:0] MIN_DATA  = 0;

//    localparam MULT_W  = 16 + K_WIDTH; 
//    localparam TRUNC_W = MULT_W - FRAC_WIDTH;
//    localparam signed [MULT_W-1:0] ROUND_HALF = 64'sd1 << (FRAC_WIDTH - 1); 

//    // =============================================================
//    // 1. ???????????¤?′?????- (???????????ˇ)
//    // =============================================================
//    wire signed [15:0] x_signed = $signed({2'b0, x_in}) - DC_OFFSET[15:0];
//    wire signed [15:0] y_signed = $signed({2'b0, y_in}) - DC_OFFSET[15:0];

//    // ???????? Enable ???????¨???????? (1.0???? ???????????? Gain ???? 16384)
//    wire signed [K_WIDTH-1:0] active_k    = calib_mode ? manual_k_fine    : 16'sd0;
//    wire signed [K_WIDTH-1:0] active_gain = calib_mode ? manual_gain_fine : (16'sd1 << FRAC_WIDTH);

//    // =============================================================
//    // 2. ???ˇ???????? Stage 1: ??? ?????????????????ˇ?¨
//    // =============================================================
//    reg signed [MULT_W-1:0] phase_mult_s1;
//    reg signed [15:0]       x_s1, y_s1;
//    reg                     valid_s1;

//    always @(posedge clk or negedge rst_n) begin
//        if (!rst_n) begin
//            phase_mult_s1 <= 0;
//            x_s1 <= 0; y_s1 <= 0;
//            valid_s1 <= 0;
//        end else begin
//            valid_s1      <= i_valid;
//            if (i_valid) begin
//                phase_mult_s1 <= x_signed * active_k; // X * K
//                x_s1          <= x_signed;            // ?????????′??????
//                y_s1          <= y_signed;
//            end
//        end
//    end

//    // =============================================================
//    // 3. ???ˇ???????? Stage 2: ??? ?????????????????ˇ?¨ & ?ˇ???????????????????ˇ?¨
//    // =============================================================
//    // ??????????? ????????????????Y_new = Y_old - (X * K)
//    wire signed [16:0] phase_y_ext = $signed({ {1{y_s1[15]}}, y_s1 });
//    wire signed [16:0] phase_y_raw = phase_y_ext - $signed(phase_mult_s1 >>> FRAC_WIDTH);
    
//    reg signed [MULT_W-1:0] amp_mult_s2;
//    reg signed [15:0]       x_s2;
//    reg                     valid_s2;

//    always @(posedge clk or negedge rst_n) begin
//        if (!rst_n) begin
//            amp_mult_s2 <= 0;
//            x_s2 <= 0;
//            valid_s2 <= 0;
//        end else begin
//            valid_s2 <= valid_s1;
//            if (valid_s1) begin
//                // ?????????????????ˇ???????ˇ???′??????Y_final = Y_new * Gain
//                amp_mult_s2 <= phase_y_raw * active_gain;
//                x_s2        <= x_s1;
//            end
//        end
//    end

//    // =============================================================
//    // 4. ???ˇ???????? Stage 3: ?ˇ?????????????????????????????????ˇ???????¤????????????
//    // =============================================================
//    wire signed [MULT_W-1:0] amp_add_half = amp_mult_s2 + ROUND_HALF;
//    wire signed [TRUNC_W-1:0] amp_trunc   = amp_add_half >>> FRAC_WIDTH;
    
//    // Y ???????′ DC
//    wire signed [TRUNC_W:0] y_final_dc = amp_trunc + DC_OFFSET;
//    // X ???????′ DC
//    wire signed [16:0] x_final_dc = $signed({ {1{x_s2[15]}}, x_s2 }) + DC_OFFSET;

//    always @(posedge clk or negedge rst_n) begin
//        if (!rst_n) begin
//            x_out   <= DC_OFFSET[DATA_WIDTH-1:0];
//            y_out   <= DC_OFFSET[DATA_WIDTH-1:0];
//            o_valid <= 0;
//        end else begin
//            o_valid <= valid_s2;
//            if (valid_s2) begin
//                // Y ???¨???????????????????¤
//                if (y_final_dc > MAX_DATA)       y_out <= MAX_DATA[DATA_WIDTH-1:0];
//                else if (y_final_dc < MIN_DATA)  y_out <= MIN_DATA[DATA_WIDTH-1:0];
//                else                             y_out <= y_final_dc[DATA_WIDTH-1:0];
                
//                // X ???¨???????????????????¤
//                if (x_final_dc > MAX_DATA)       x_out <= MAX_DATA[DATA_WIDTH-1:0];
//                else if (x_final_dc < MIN_DATA)  x_out <= MIN_DATA[DATA_WIDTH-1:0];
//                else                             x_out <= x_final_dc[DATA_WIDTH-1:0];
//            end
//        end
//    end

//endmodule




`timescale 1ns / 1ps
// ==========================================================================
// ????????: amp_dector (?′?????????¨???????????????????¤????????????????????)
// ==========================================================================
//module amp_dector #(
//    parameter DATA_WIDTH = 14
//)(
//    input  wire                    clk,    
//    input  wire                    rst_n,
//    input  wire                    i_valid,
    
//    // ???????????????????????????????? (0: ???????¨?????′?????-, 1: ????????????)
//    input  wire                    norm_mode, 

//    // ???????????¤????
//    input  wire [DATA_WIDTH-1 : 0] data_in1,
//    input  wire [DATA_WIDTH-1 : 0] data_in2,

//    // ???????????????????????¨????????????
//    input  wire [DATA_WIDTH-1 : 0] manual_max1,
//    input  wire [DATA_WIDTH-1 : 0] manual_min1,
//    input  wire [DATA_WIDTH-1 : 0] manual_max2,
//    input  wire [DATA_WIDTH-1 : 0] manual_min2,

//    // ???????????¤????
//    output wire [DATA_WIDTH-1 : 0] phase_sel_data_out1,
//    output wire [DATA_WIDTH-1 : 0] phase_sel_data_out2,
//    output wire                    o_valid
//);

//    wire o_valid1;
//    wire o_valid2;

//    assign o_valid = o_valid1 & o_valid2;

//    // =========================================================
//    // ???¨???? 1????????????????
//    // =========================================================
//    normalization #(
//        .DATA_WIDTH (DATA_WIDTH),
//        .MAX_VAL    ( (DATA_WIDTH == 8) ? 8'd255 : 14'd16383 ),
//        .TARGET_MAX ( (DATA_WIDTH == 8) ? 8'd234 : 14'd16000 ),
//        .TARGET_MIN ( (DATA_WIDTH == 8) ? 8'd10  : 14'd363   )
//    ) norm_ch1 (
//        .clk          (clk), 
//        .rst_n        (rst_n),
//        .i_valid      (i_valid),
//        .norm_mode    (norm_mode),   // <--- ?′??????????????????????
        
//        .data_in_nor  (data_in1),
//        .datamax      (manual_max1), 
//        .datamin      (manual_min1), 
        
//        .data_out_nor (phase_sel_data_out1),
//        .o_valid      (o_valid1)
//    );
    
//    // =========================================================
//    // ???¨???? 2????????????????
//    // =========================================================
//    normalization #(
//        .DATA_WIDTH (DATA_WIDTH),
//        .MAX_VAL    ( (DATA_WIDTH == 8) ? 8'd255 : 14'd16383 ),
//        .TARGET_MAX ( (DATA_WIDTH == 8) ? 8'd234 : 14'd16000 ),
//        .TARGET_MIN ( (DATA_WIDTH == 8) ? 8'd10  : 14'd363   )
//    ) norm_ch2 (
//        .clk          (clk), 
//        .rst_n        (rst_n),
//        .i_valid      (i_valid),
//        .norm_mode    (norm_mode),   // <--- ?′??????????????????????
        
//        .data_in_nor  (data_in2),
//        .datamax      (manual_max2), 
//        .datamin      (manual_min2), 
        
//        .data_out_nor (phase_sel_data_out2),
//        .o_valid      (o_valid2)
//    );

//endmodule



//`timescale 1ns / 1ps
//// ==========================================================================
//// ????????: normalization (???????ˇ?????????°???????????????′?????-????0?????°??)
//// ????????: ???????????? = 1 Data/Clock???????????¨???????? 4 ????????????????????
//// ==========================================================================
//module normalization #(
//    parameter DATA_WIDTH = 14,
//    parameter MAX_VAL    = 16383, 
//    parameter TARGET_MAX = 16000,
//    parameter TARGET_MIN = 363      
//)(
//    input  wire                  clk,
//    input  wire                  rst_n,
//    input  wire                  i_valid,    
//    input  wire                  norm_mode,  // 0: ???????¨, 1: ????????????
    
//    input  wire [DATA_WIDTH-1:0] data_in_nor, 
//    input  wire [DATA_WIDTH-1:0] datamax,      
//    input  wire [DATA_WIDTH-1:0] datamin,      
    
//    output reg  [DATA_WIDTH-1:0] data_out_nor,
//    output reg                   o_valid
//);

//    localparam [31:0] TARGET_RANGE = TARGET_MAX - TARGET_MIN;

//    // =========================================================
//    // Stage 1 ?????′?????ˇ: ???????????¤????????????????????????
//    // =========================================================
//    reg [DATA_WIDTH-1:0] s1_data_in, s1_max, s1_min;
//    reg                  s1_valid, s1_mode;

//    always @(posedge clk or negedge rst_n) begin
//        if (!rst_n) begin
//            s1_data_in <= 0; s1_max <= 0; s1_min <= 0;
//            s1_valid   <= 0; s1_mode <= 0;
//        end else begin
//            s1_valid <= i_valid;
//            s1_mode  <= norm_mode;
//            if (i_valid) begin // ???????????ˇ????????
//                s1_data_in <= data_in_nor;
//                s1_max     <= datamax;
//                s1_min     <= datamin;
//            end
//        end
//    end

//    // =========================================================
//    // Stage 2 ?????′?????ˇ: ???????????????????????????????? (?????ˇ?¨?????????ˇ?¨)
//    // =========================================================
//    reg [31:0]           s2_dividend;
//    reg [DATA_WIDTH-1:0] s2_divisor;
//    reg [DATA_WIDTH-1:0] s2_bypass;
//    reg                  s2_valid, s2_mode;

//    always @(posedge clk or negedge rst_n) begin
//        if (!rst_n) begin
//            s2_dividend <= 0; s2_divisor <= 0; s2_bypass <= 0;
//            s2_valid    <= 0; s2_mode    <= 0;
//        end else begin
//            s2_valid <= s1_valid;
//            s2_mode  <= s1_mode;
//            if (s1_valid) begin
//                s2_bypass   <= s1_data_in;
//                // ?ˇ?????§???????????¤????????????min?????°?′0????
//                s2_dividend <= (s1_data_in >= s1_min) ? (s1_data_in - s1_min) * TARGET_RANGE : 0;
//                // ?ˇ??????0????????
//                s2_divisor  <= (s1_max > s1_min) ? (s1_max - s1_min) : 1; 
//            end
//        end
//    end

//    // =========================================================
//    // Stage 3 ?????′?????ˇ: ?′?????????????????-?????ˇ?¨???ˇ (???????? 1MHz ????????????????)
//    // =========================================================
//    reg [31:0]           s3_quotient;
//    reg [DATA_WIDTH-1:0] s3_bypass;
//    reg                  s3_valid, s3_mode;

//    always @(posedge clk or negedge rst_n) begin
//        if (!rst_n) begin
//            s3_quotient <= 0; s3_bypass <= 0;
//            s3_valid    <= 0; s3_mode   <= 0;
//        end else begin
//            s3_valid <= s2_valid;
//            s3_mode  <= s2_mode;
//            if (s2_valid) begin
//                s3_bypass   <= s2_bypass;
//                // ???????????????????????????????????????????? 1MHz ????????Vivado ?????????????????????????ˇ?¨???ˇ????????????????????????
//                s3_quotient <= s2_dividend / s2_divisor; 
//            end
//        end
//    end

//    // =========================================================
//    // Stage 4 ?????′?????ˇ: ???????????????????????????????????????¤???¤????
//    // =========================================================
//    always @(posedge clk or negedge rst_n) begin
//        if (!rst_n) begin
//            data_out_nor <= 0;
//            o_valid      <= 0;
//        end else begin
//            o_valid <= s3_valid;
//            if (s3_valid) begin
//                if (s3_mode == 1'b0) begin
//                    data_out_nor <= s3_bypass; // ???????¨????????
//                end else begin
//                    // ???????????????????????????????? TARGET_MIN ???????????????????????¤
//                    if ((s3_quotient + TARGET_MIN) > MAX_VAL)
//                        data_out_nor <= MAX_VAL[DATA_WIDTH-1:0];
//                    else
//                        data_out_nor <= s3_quotient[DATA_WIDTH-1:0] + TARGET_MIN[DATA_WIDTH-1:0];
//                end
//            end
//        end
//    end

//endmodule

module cordic_top (
    input                 clk,
    input                 i_valid,
    input                 rst_n,

    input      [13:0]     data_in1,  // X / Cos
    input      [13:0]     data_in2,  // Y / Sin

    input      [15:0]     zero,

    output reg [15:0]     angle_slove_raw,
    output reg            angle_valid
);

    wire [15 : 0] angle_raw;         
    wire          cordic_out_valid;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            angle_slove_raw <= 16'd0;
            angle_valid     <= 1'b0;
        end else begin
            angle_valid <= cordic_out_valid;
            
            if (cordic_out_valid) begin
                if (angle_raw <= 16'd36000) begin
                    // á?????×????-
                    if (angle_raw >= zero) begin
                        angle_slove_raw <= angle_raw - zero;
                    end else begin
                        angle_slove_raw <= angle_raw + 16'd36000 - zero;
                    end
                end
            end
        end
    end

    CORDIC u_cordic (
        .clk     (clk),
        .rst_n   (rst_n), 
        .i_valid (i_valid),
        .x       (data_in1),
        .y       (data_in2),
        .angle   (angle_raw),
        .o_valid (cordic_out_valid) 
    );
endmodule


module CORDIC (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        i_valid,
    input  wire [13:0] x,
    input  wire [13:0] y,
    output reg  [15:0] angle,
    output reg         o_valid
);

    localparam integer PIPE_STAGES = 15;
    localparam integer XY_WIDTH    = 28;
    localparam integer Z_WIDTH     = 32;

    // atan(2^-i)，单位：degree × 2^16
    function signed [Z_WIDTH-1:0] get_angle_lut;
        input [3:0] index;
        begin
            case (index)
                4'd0 : get_angle_lut = 32'sd2949120;
                4'd1 : get_angle_lut = 32'sd1740967;
                4'd2 : get_angle_lut = 32'sd919879;
                4'd3 : get_angle_lut = 32'sd466945;
                4'd4 : get_angle_lut = 32'sd234378;
                4'd5 : get_angle_lut = 32'sd117303;
                4'd6 : get_angle_lut = 32'sd58666;
                4'd7 : get_angle_lut = 32'sd29335;
                4'd8 : get_angle_lut = 32'sd14668;
                4'd9 : get_angle_lut = 32'sd7334;
                4'd10: get_angle_lut = 32'sd3667;
                4'd11: get_angle_lut = 32'sd1833;
                4'd12: get_angle_lut = 32'sd917;
                4'd13: get_angle_lut = 32'sd458;
                4'd14: get_angle_lut = 32'sd229;
                default: get_angle_lut = 32'sd0;
            endcase
        end
    endfunction

    // 输入减去中点8192，范围为 -8192~8191
    wire signed [14:0] x_signed;
    wire signed [14:0] y_signed;
    wire signed [14:0] x_abs;
    wire signed [14:0] y_abs;
    wire               vector_nonzero;

    assign x_signed = $signed({1'b0, x}) - 15'sd8192;
    assign y_signed = $signed({1'b0, y}) - 15'sd8192;

    assign x_abs = x_signed[14] ? -x_signed : x_signed;
    assign y_abs = y_signed[14] ? -y_signed : y_signed;

    assign vector_nonzero =
        (x_signed != 15'sd0) || (y_signed != 15'sd0);

    // X/Y使用28bit、3bit小数；Z使用32bit、Q16角度格式
    reg signed [XY_WIDTH-1:0] x_pipe [0:PIPE_STAGES];
    reg signed [XY_WIDTH-1:0] y_pipe [0:PIPE_STAGES];
    reg signed [Z_WIDTH-1:0]  z_pipe [0:PIPE_STAGES];

    reg x_sign_pipe [0:PIPE_STAGES];
    reg y_sign_pipe [0:PIPE_STAGES];
    reg valid_pipe  [0:PIPE_STAGES];

    // z(Q16 degree)转换为0.01°/LSB：round(z × 100 / 2^16)
    wire signed [39:0] z_ext;
    wire signed [39:0] z_times_100;
    wire signed [39:0] z_rounded;
    wire        [23:0] angle_in_q1_full;
    wire        [15:0] angle_in_q1;

    assign z_ext =
        {{8{z_pipe[PIPE_STAGES][Z_WIDTH-1]}},
          z_pipe[PIPE_STAGES]};

    // ×100 = ×64 + ×32 + ×4
    assign z_times_100 =
        (z_ext <<< 6) +
        (z_ext <<< 5) +
        (z_ext <<< 2);

    assign z_rounded       = z_times_100 + 40'sd32768;
    assign angle_in_q1_full = z_rounded[39:16];

    assign angle_in_q1 =
        z_pipe[PIPE_STAGES][Z_WIDTH-1] ? 16'd0 :
        (angle_in_q1_full > 24'd9000) ? 16'd9000 :
                                        angle_in_q1_full[15:0];

    // ------------------------------------------------------------------------
    // 关键修复：所有流水寄存器都显式异步复位。
    //
    // 原先X/Y/Z数据寄存器没有复位。DC可能基于流水线可达状态进行
    // sequential optimization，而Formality仍把这些内部DFF按任意初态比较，
    // 因而在x_pipe/y_pipe/z_pipe的第3~5级出现内部状态不等价。
    // 显式复位后，两侧状态空间一致，不再依赖SVF恢复初态映射。
    // ------------------------------------------------------------------------
    integer i;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            for (i = 0; i <= PIPE_STAGES; i = i + 1) begin
                x_pipe[i]      <= {XY_WIDTH{1'b0}};
                y_pipe[i]      <= {XY_WIDTH{1'b0}};
                z_pipe[i]      <= {Z_WIDTH{1'b0}};
                x_sign_pipe[i] <= 1'b0;
                y_sign_pipe[i] <= 1'b0;
                valid_pipe[i]  <= 1'b0;
            end

            angle   <= 16'd0;
            o_valid <= 1'b0;
        end else begin
            // Stage 0：输入预处理结果进入流水线
            x_sign_pipe[0] <= x_signed[14];
            y_sign_pipe[0] <= y_signed[14];
            valid_pipe[0]  <= i_valid && vector_nonzero;

            x_pipe[0] <= $signed({10'b0, x_abs, 3'b0});
            y_pipe[0] <= $signed({10'b0, y_abs, 3'b0});
            z_pipe[0] <= 32'sd0;

            // Stage 1~15：CORDIC vectoring迭代
            for (i = 0; i < PIPE_STAGES; i = i + 1) begin
                x_sign_pipe[i+1] <= x_sign_pipe[i];
                y_sign_pipe[i+1] <= y_sign_pipe[i];
                valid_pipe[i+1]  <= valid_pipe[i];

                if (y_pipe[i][XY_WIDTH-1] == 1'b1) begin
                    // Y < 0
                    x_pipe[i+1] <=
                        $signed(x_pipe[i]) -
                        ($signed(y_pipe[i]) >>> i);

                    y_pipe[i+1] <=
                        $signed(y_pipe[i]) +
                        ($signed(x_pipe[i]) >>> i);

                    z_pipe[i+1] <=
                        $signed(z_pipe[i]) -
                        $signed(get_angle_lut(i[3:0]));
                end else begin
                    // Y >= 0
                    x_pipe[i+1] <=
                        $signed(x_pipe[i]) +
                        ($signed(y_pipe[i]) >>> i);

                    y_pipe[i+1] <=
                        $signed(y_pipe[i]) -
                        ($signed(x_pipe[i]) >>> i);

                    z_pipe[i+1] <=
                        $signed(z_pipe[i]) +
                        $signed(get_angle_lut(i[3:0]));
                end
            end

            // 输出与第15级流水数据对齐
            o_valid <= valid_pipe[PIPE_STAGES];

            if (valid_pipe[PIPE_STAGES]) begin
                case ({x_sign_pipe[PIPE_STAGES],
                       y_sign_pipe[PIPE_STAGES]})
                    2'b00: angle <= angle_in_q1;
                    2'b10: angle <= 16'd18000 - angle_in_q1;
                    2'b11: angle <= 16'd18000 + angle_in_q1;
                    2'b01: angle <= 16'd36000 - angle_in_q1;
                    default: angle <= 16'd0;
                endcase
            end
        end
    end

endmodule

module afilter #(
    parameter DATA_WIDTH = 14
)(
    input  wire                  clk,        
    input  wire                  rst_n,    
    input  wire [DATA_WIDTH-1:0] data_in,  
    output reg  [DATA_WIDTH-1:0] data_out  
);

    reg [DATA_WIDTH-1:0] shift_reg [0:15]; 
    integer i;

    wire [DATA_WIDTH-1:0] data_old;
    assign data_old = shift_reg[15];

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            for (i=0; i<16; i=i+1) begin
                shift_reg[i] <= {DATA_WIDTH{1'b0}};
            end
        end
        else begin
            shift_reg[0] <= data_in;
            for (i=1; i<16; i=i+1) begin
                shift_reg[i] <= shift_reg[i-1];
            end
        end
    end

    // à??ó?÷???í = êy?Y???í + log2(16) = DATA_WIDTH + 4
    reg [DATA_WIDTH+3:0] accumulator; 

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            accumulator <= 0;
        end
        else begin
            // à??1·?o?????DD?ó?? (?ùéèê??T·?o?êy￡?????210)
            accumulator <= accumulator + {4'd0, data_in} - {4'd0, data_old};
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            data_out <= {DATA_WIDTH{1'b0}};
        end
        else begin
            // ê?3??àμ±óú3yò?16￡??′óòò?4??
            data_out <= accumulator[DATA_WIDTH+3:4];
        end
    end

endmodule

module mfilter #(
    parameter DATA_WIDTH = 14 // ??è??μ
) (
    input  wire                  clk,       
    input  wire                  rst_n,
    input  wire [DATA_WIDTH-1:0] data_in,
    output reg  [DATA_WIDTH-1:0] data_out
);

    reg [DATA_WIDTH-1:0] p0, p1, p2, p3, p4; 

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            p0 <= {DATA_WIDTH{1'b0}}; // í¨ó???á?
            p1 <= {DATA_WIDTH{1'b0}};
            p2 <= {DATA_WIDTH{1'b0}};
            p3 <= {DATA_WIDTH{1'b0}};
            p4 <= {DATA_WIDTH{1'b0}};
        end else begin 
            p0 <= data_in;
            p1 <= p0;
            p2 <= p1;
            p3 <= p2;
            p4 <= p3;
        end
    end

    // ×éo????-??Dò
    reg [DATA_WIDTH-1:0] t0, t1, t2, t3, t4;
    reg [DATA_WIDTH-1:0] swap_temp;

    always @(*) begin
        t0 = p0; t1 = p1; t2 = p2; t3 = p3; t4 = p4;
        // ±è?????-±?éíó????í?T1?￡??±?ó?′ó?
        // Round 1
        if (t0 > t1) begin swap_temp = t0; t0 = t1; t1 = swap_temp; end
        if (t1 > t2) begin swap_temp = t1; t1 = t2; t2 = swap_temp; end
        if (t2 > t3) begin swap_temp = t2; t2 = t3; t3 = swap_temp; end
        if (t3 > t4) begin swap_temp = t3; t3 = t4; t4 = swap_temp; end
        // Round 2
        if (t0 > t1) begin swap_temp = t0; t0 = t1; t1 = swap_temp; end
        if (t1 > t2) begin swap_temp = t1; t1 = t2; t2 = swap_temp; end
        if (t2 > t3) begin swap_temp = t2; t2 = t3; t3 = swap_temp; end
        // Round 3
        if (t0 > t1) begin swap_temp = t0; t0 = t1; t1 = swap_temp; end
        if (t1 > t2) begin swap_temp = t1; t1 = t2; t2 = swap_temp; end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            data_out <= {DATA_WIDTH{1'b0}};
        end else begin
            data_out <= t2;
        end
    end

endmodule
module amp_dector #(
    parameter DATA_WIDTH = 14,

    // 自动模式统计完整周期数
    parameter integer CYCLES_TO_DETECT = 3,

    // X通道负区阈值
    parameter signed [15:0] CROSS_TH = 16'sd20,

    parameter signed [15:0] ADC_OFFSET = 16'sd8192
)(
    input  wire                  clk,
    input  wire                  rst_n,
    input  wire                  i_valid,

    // ============================================================
    // 归一化模式
    //
    // 0：自动检测max/min
    // 1：使用外部手动输入max/min
    // ============================================================
    input  wire                  norm_mode,

    input  wire [DATA_WIDTH-1:0] manual_max_x,
    input  wire [DATA_WIDTH-1:0] manual_min_x,

    input  wire [DATA_WIDTH-1:0] manual_max_y,
    input  wire [DATA_WIDTH-1:0] manual_min_y,

    input  wire [DATA_WIDTH-1:0] x_in,
    input  wire [DATA_WIDTH-1:0] y_in,

    // 自动模式：
    // 最大最小值检测完成后保持高
    //
    // 手动模式：
    // 直接保持高
    output reg                   norm_done,

    // 每组归一化输出有效
    output wire                  o_valid,

    output wire [DATA_WIDTH-1:0] x_out,
    output wire [DATA_WIDTH-1:0] y_out
);

    // ============================================================
    // 1. X去直流，用于自动模式过零检测
    // ============================================================

    wire signed [15:0] x_ac;

    assign x_ac =
        $signed({2'b00, x_in}) - ADC_OFFSET;


    // ============================================================
    // 2. 自动模式负->正过零检测
    // ============================================================

    reg cross_arm;

    wire x_pos_cross;

    assign x_pos_cross =
        (!norm_mode) &&
        i_valid &&
        cross_arm &&
        (x_ac >= 16'sd0);


    always @(posedge clk or negedge rst_n) begin

        if (!rst_n) begin

            cross_arm <= 1'b0;

        end

        // 手动模式不用做过零检测
        else if (norm_mode) begin

            cross_arm <= 1'b0;

        end

        else if (norm_done) begin

            cross_arm <= 1'b0;

        end

        else if (i_valid) begin

            if (x_ac <= -CROSS_TH) begin

                cross_arm <= 1'b1;

            end
            else if (x_pos_cross) begin

                cross_arm <= 1'b0;

            end

        end

    end


    // ============================================================
    // 3. 自动最大最小值检测
    // ============================================================

    localparam S_WAIT_SYNC = 2'd0;
    localparam S_SCAN      = 2'd1;
    localparam S_HOLD      = 2'd2;

    reg [1:0] state;

    reg [7:0] cycle_count;

    reg [DATA_WIDTH-1:0] x_max;
    reg [DATA_WIDTH-1:0] x_min;

    reg [DATA_WIDTH-1:0] y_max;
    reg [DATA_WIDTH-1:0] y_min;


    localparam [DATA_WIDTH-1:0] DATA_MAX =
        {DATA_WIDTH{1'b1}};


    always @(posedge clk or negedge rst_n) begin

        if (!rst_n) begin

            state       <= S_WAIT_SYNC;
            cycle_count <= 8'd0;

            norm_done <= 1'b0;

            x_max <= {DATA_WIDTH{1'b0}};
            x_min <= DATA_MAX;

            y_max <= {DATA_WIDTH{1'b0}};
            y_min <= DATA_MAX;

        end

        // ========================================================
        // 手动模式
        //
        // 不需要检测极值
        // 直接认为归一化参数已经准备好
        //
        // 同时复位自动检测状态，
        // 这样切回自动模式以后会重新检测3圈
        // ========================================================
        else if (norm_mode) begin

            norm_done <= 1'b1;

            state       <= S_WAIT_SYNC;
            cycle_count <= 8'd0;

            x_max <= {DATA_WIDTH{1'b0}};
            x_min <= DATA_MAX;

            y_max <= {DATA_WIDTH{1'b0}};
            y_min <= DATA_MAX;

        end

        // ========================================================
        // 自动模式
        // ========================================================
        else begin

            case (state)

                // ------------------------------------------------
                // 等待第一个负->正过零点
                // ------------------------------------------------
                S_WAIT_SYNC: begin

                    norm_done   <= 1'b0;
                    cycle_count <= 8'd0;

                    if (x_pos_cross) begin

                        x_max <= x_in;
                        x_min <= x_in;

                        y_max <= y_in;
                        y_min <= y_in;

                        cycle_count <= 8'd0;

                        state <= S_SCAN;

                    end

                end


                // ------------------------------------------------
                // 连续统计CYCLES_TO_DETECT个完整周期
                // ------------------------------------------------
                S_SCAN: begin

                    if (i_valid) begin

                        if (x_in > x_max)
                            x_max <= x_in;

                        if (x_in < x_min)
                            x_min <= x_in;

                        if (y_in > y_max)
                            y_max <= y_in;

                        if (y_in < y_min)
                            y_min <= y_in;


                        if (x_pos_cross) begin

                            if (cycle_count >=
                                CYCLES_TO_DETECT - 1) begin

                                norm_done <= 1'b1;

                                state <= S_HOLD;

                            end
                            else begin

                                cycle_count <=
                                    cycle_count + 8'd1;

                            end

                        end

                    end

                end


                // ------------------------------------------------
                // 自动检测完成
                // ------------------------------------------------
                S_HOLD: begin

                    norm_done <= 1'b1;

                    state <= S_HOLD;

                end


                default: begin

                    norm_done <= 1'b0;

                    state <= S_WAIT_SYNC;

                end

            endcase

        end

    end


    // ============================================================
    // 4. 自动/手动最大最小值选择
    // ============================================================

    wire [DATA_WIDTH-1:0] selected_x_max;
    wire [DATA_WIDTH-1:0] selected_x_min;

    wire [DATA_WIDTH-1:0] selected_y_max;
    wire [DATA_WIDTH-1:0] selected_y_min;


    assign selected_x_max =
        norm_mode ? manual_max_x : x_max;

    assign selected_x_min =
        norm_mode ? manual_min_x : x_min;

    assign selected_y_max =
        norm_mode ? manual_max_y : y_max;

    assign selected_y_min =
        norm_mode ? manual_min_y : y_min;


    // ============================================================
    // 5. 归一化输入使能
    // ============================================================

    wire norm_enable;

    assign norm_enable =
        norm_done & i_valid;


    // ============================================================
    // 6. 两通道valid
    // ============================================================

    wire x_norm_valid;
    wire y_norm_valid;


    assign o_valid =
        x_norm_valid & y_norm_valid;


    // ============================================================
    // 7. X通道归一化
    //
    // 自动和手动模式使用完全相同公式
    // ============================================================

    normalization #(
        .DATA_WIDTH (DATA_WIDTH),

        .MAX_VAL    (14'd16383),

        .TARGET_MAX (14'd16000),
        .TARGET_MIN (14'd384)

    ) u_norm_x (

        .clk          (clk),
        .rst_n        (rst_n),

        .i_valid      (norm_enable),

        .data_in_nor  (x_in),

        .datamax      (selected_x_max),
        .datamin      (selected_x_min),

        .data_out_nor (x_out),

        .o_valid      (x_norm_valid)

    );


    // ============================================================
    // 8. Y通道归一化
    // ============================================================

    normalization #(
        .DATA_WIDTH (DATA_WIDTH),

        .MAX_VAL    (14'd16383),

        .TARGET_MAX (14'd16000),
        .TARGET_MIN (14'd384)

    ) u_norm_y (

        .clk          (clk),
        .rst_n        (rst_n),

        .i_valid      (norm_enable),

        .data_in_nor  (y_in),

        .datamax      (selected_y_max),
        .datamin      (selected_y_min),

        .data_out_nor (y_out),

        .o_valid      (y_norm_valid)

    );

endmodule
module normalization #(
    parameter DATA_WIDTH = 14,
    parameter MAX_VAL    = 0,
    parameter TARGET_MAX = 0,
    parameter TARGET_MIN = 0
)(
    input  wire                  clk,
    input  wire                  rst_n,
    input  wire                  i_valid,

    input  wire [DATA_WIDTH-1:0] data_in_nor,
    input  wire [DATA_WIDTH-1:0] datamax,
    input  wire [DATA_WIDTH-1:0] datamin,

    output reg  [DATA_WIDTH-1:0] data_out_nor,
    output reg                   o_valid
);

    // ============================================================
    // Normalization:
    // data_out = (data_in - datamin) * (TARGET_MAX - TARGET_MIN)
    //            / (datamax - datamin)
    //            + TARGET_MIN
    // ============================================================

    localparam integer DIV_WIDTH = 32;
    localparam [31:0] TARGET_RANGE = TARGET_MAX - TARGET_MIN;

    wire range_valid;

    wire [DATA_WIDTH-1:0] data_clamped;
    wire [DATA_WIDTH-1:0] diff_wire;
    wire [DATA_WIDTH-1:0] range_wire;

    wire [31:0] dividend_wire;
    wire [DATA_WIDTH-1:0] divisor_wire;

    assign range_valid = (datamax > datamin);

    assign data_clamped = (!range_valid)           ? data_in_nor :
                          (data_in_nor > datamax)  ? datamax     :
                          (data_in_nor < datamin)  ? datamin     :
                                                     data_in_nor;

    assign diff_wire  = range_valid ?
                        (data_clamped - datamin) :
                        {DATA_WIDTH{1'b0}};

    assign range_wire = range_valid ?
                        (datamax - datamin) :
                        {{DATA_WIDTH-1{1'b0}}, 1'b1};

    assign dividend_wire =
        {{(32-DATA_WIDTH){1'b0}}, diff_wire} * TARGET_RANGE;

    assign divisor_wire =
        (range_wire == {DATA_WIDTH{1'b0}}) ?
        {{DATA_WIDTH-1{1'b0}}, 1'b1} :
        range_wire;

    // ============================================================
    // 32-cycle unsigned restoring divider
    // ============================================================

    reg                  div_busy;
    reg [5:0]            div_cnt;

    reg [DIV_WIDTH-1:0]  dividend_shift;
    reg [DIV_WIDTH-1:0]  quotient;
    reg [DIV_WIDTH:0]    remainder;
    reg [DIV_WIDTH:0]    divisor_ext;

    // Combinational next-step values.
    // IMPORTANT: these are wires, not registers assigned in the clocked block.
    wire [DIV_WIDTH:0]   rem_shift;
    wire                 subtract_en;
    wire [DIV_WIDTH:0]   rem_calc;
    wire [DIV_WIDTH-1:0] quo_calc;

    assign rem_shift = {
        remainder[DIV_WIDTH-1:0],
        dividend_shift[DIV_WIDTH-1]
    };

    assign subtract_en = (rem_shift >= divisor_ext);

    assign rem_calc = subtract_en ?
                      (rem_shift - divisor_ext) :
                      rem_shift;

    assign quo_calc = {
        quotient[DIV_WIDTH-2:0],
        subtract_en
    };

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            div_busy       <= 1'b0;
            div_cnt        <= 6'd0;

            dividend_shift <= {DIV_WIDTH{1'b0}};
            quotient       <= {DIV_WIDTH{1'b0}};
            remainder      <= {(DIV_WIDTH+1){1'b0}};
            divisor_ext    <= {(DIV_WIDTH+1){1'b0}};

            data_out_nor   <= {DATA_WIDTH{1'b0}};
            o_valid        <= 1'b0;
        end
        else begin
            // Default: no output pulse.
            o_valid <= 1'b0;

            // Accept one new sample when idle.
            if (i_valid && !div_busy) begin
                div_busy <= 1'b1;
                div_cnt  <= 6'd32;

                dividend_shift <= dividend_wire;
                divisor_ext <= {
                    {(DIV_WIDTH+1-DATA_WIDTH){1'b0}},
                    divisor_wire
                };

                quotient  <= {DIV_WIDTH{1'b0}};
                remainder <= {(DIV_WIDTH+1){1'b0}};
            end
            else if (div_busy) begin
                dividend_shift <= {
                    dividend_shift[DIV_WIDTH-2:0],
                    1'b0
                };

                remainder <= rem_calc;
                quotient  <= quo_calc;

                if (div_cnt == 6'd1) begin
                    div_busy <= 1'b0;
                    div_cnt  <= 6'd0;

                    if (!range_valid) begin
                        // Defensive fallback; normally amp_dector only enables
                        // normalization after valid max/min are available.
                        data_out_nor <= data_in_nor;
                    end
                    else if (quo_calc > TARGET_RANGE) begin
                        data_out_nor <= TARGET_MAX[DATA_WIDTH-1:0];
                    end
                    else begin
                        data_out_nor <=
                            quo_calc[DATA_WIDTH-1:0] +
                            TARGET_MIN[DATA_WIDTH-1:0];
                    end

                    o_valid <= 1'b1;
                end
                else begin
                    div_cnt <= div_cnt - 6'd1;
                end
            end
        end
    end

endmodule
module phase_top #(
    parameter DATA_WIDTH = 14,

    parameter signed [15:0] ADC_OFFSET = 16'sd8192,
    parameter signed [31:0] DEAD_ZONE  = 32'sd0,

    parameter [31:0] STARTUP_DELAY = 32'd0,

    parameter signed [15:0] CROSS_TH = 16'sd20,

    parameter [31:0] MIN_PERIOD_SAMPLES = 32'd10,
    parameter [31:0] MAX_PERIOD_SAMPLES = 32'd10000000,

    parameter integer CYCLES_TO_CALIB = 3
)(
    input  wire                  clk,
    input  wire                  rst_n,

    // ============================================================
    // 相位校准模式
    //
    // 0：自动计算 k + gain
    // 1：手动输入 k + gain
    // ============================================================
    input  wire                  phase_mode,

    // 手动相位系数，signed Q2.14
    input  wire signed [15:0]    manual_k,

    // 手动幅值补偿系数，unsigned Q2.14
    // 16384 = 1.0
    input  wire [15:0]           manual_gain,

    // 归一化参数准备完成
    input  wire                  start,

    // 当前归一化X/Y数据有效
    input  wire                  i_valid,

    input  wire [DATA_WIDTH-1:0] x_in_unsigned,
    input  wire [DATA_WIDTH-1:0] y_in_unsigned,

    // 当前实际使用的系数
    output wire signed [15:0]    monitor_k,
    output wire [15:0]           monitor_gain,

    // 当前校准参数是否准备完成
    output wire                  calib_done,

    // 相位校准 + 幅值补偿后的输出
    output wire [DATA_WIDTH-1:0] x_out_unsigned,
    output wire [DATA_WIDTH-1:0] y_out_unsigned,

    output wire                  o_valid
);


    // ============================================================
    // 1. 自动计算参数
    // ============================================================

    wire signed [15:0] auto_k_factor;
    wire        [15:0] auto_gain_factor;

    wire k_calc_done;
    wire gain_calc_done;


    // ============================================================
    // 2. 自动模块独立复位
    //
    // phase_mode = 1：
    // 自动k/gain模块一直处于复位状态
    //
    // phase_mode从1重新变成0：
    // 自动模块重新开始工作
    // 因此可以实现：
    //
    // 自动 -> 手动 -> 自动重新校准
    // ============================================================
reg auto_rst_n_reg;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n)
        auto_rst_n_reg <= 1'b0;
    else if (phase_mode)
        auto_rst_n_reg <= 1'b0;
    else
        auto_rst_n_reg <= 1'b1;
end


    // ============================================================
    // 3. 自动/手动参数选择
    // ============================================================

    wire signed [15:0] selected_k_factor;
    wire        [15:0] selected_gain_factor;


    assign selected_k_factor =
        phase_mode ?
        manual_k :
        auto_k_factor;


    assign selected_gain_factor =
        phase_mode ?
        manual_gain :
        auto_gain_factor;


    // 当前真正参与计算的参数
    assign monitor_k =
        selected_k_factor;

    assign monitor_gain =
        selected_gain_factor;


    // ============================================================
    // 4. 参数完成标志
    //
    // 手动模式：
    // 参数由EEPROM/UART直接提供，所以直接完成
    //
    // 自动模式：
    // 必须等gain计算结束
    // ============================================================

    assign calib_done =
        phase_mode ?
        1'b1 :
        gain_calc_done;


    // ============================================================
    // 5. 自动计算k
    //
    // 自动模式下：
    // start = norm_done
    //
    // 手动模式下：
    // auto_rst_n=0，自动模块被复位
    // ============================================================

    auto_k_calc_cycle #(
        .DATA_WIDTH         (DATA_WIDTH),

        .ADC_OFFSET         (ADC_OFFSET),
        .DEAD_ZONE          (DEAD_ZONE),

        .STARTUP_DELAY      (STARTUP_DELAY),

        .CROSS_TH           (CROSS_TH),

        .MIN_PERIOD_SAMPLES (MIN_PERIOD_SAMPLES),
        .MAX_PERIOD_SAMPLES (MAX_PERIOD_SAMPLES),

        .CYCLES_TO_CALIB    (CYCLES_TO_CALIB)

    ) u_auto_k_calc_cycle (

        .clk        (clk),

        // 注意这里使用自动模块专用复位
        .rst_n      (auto_rst_n_reg),

        .start      (start),

        .i_valid    (i_valid),

        .raw_x      (x_in_unsigned),
        .raw_y      (y_in_unsigned),

        .k_factor   (auto_k_factor),

        .calib_done (k_calc_done)

    );


    // ============================================================
    // 6. 根据自动k计算自动gain
    //
    // gain = 1 / sqrt(1-k^2)
    // ============================================================

    phase_gain_calc #(
        .ITERATIONS(6)

    ) u_phase_gain_calc (

        .clk         (clk),

        // 同样使用自动模块专用复位
        .rst_n       (auto_rst_n_reg),

        .start       (k_calc_done),

        .k_factor    (auto_k_factor),

        .gain_factor (auto_gain_factor),

        .gain_done   (gain_calc_done)

    );


    // ============================================================
    // 7. 数据处理使能
    //
    // 手动模式：
    // calib_done恒为1
    //
    // 自动模式：
    // gain计算完成以后才允许数据进入相位校准
    // ============================================================

    wire phase_process_valid;

    assign phase_process_valid =
        i_valid & calib_done;


    // ============================================================
    // 8. 相位校准
    //
    // Ycorr = Y - kX
    //
    // k来源：
    //
    // phase_mode=0 -> auto_k_factor
    // phase_mode=1 -> manual_k
    // ============================================================

    wire [DATA_WIDTH-1:0] phase_corr_x;
    wire [DATA_WIDTH-1:0] phase_corr_y;

    wire phase_corr_valid;


    phase_calib #(
        .DATA_WIDTH (DATA_WIDTH),
        .ADC_OFFSET (ADC_OFFSET)

    ) u_phase_calib (

        .clk            (clk),

        // 数据处理模块始终使用系统复位
        .rst_n          (rst_n),

        .i_valid        (phase_process_valid),

        .x_in_unsigned  (x_in_unsigned),
        .y_in_unsigned  (y_in_unsigned),

        .k_factor       (selected_k_factor),

        .x_out_unsigned (phase_corr_x),
        .y_out_unsigned (phase_corr_y),

        .o_valid        (phase_corr_valid)

    );


    // ============================================================
    // 9. 幅值补偿
    //
    // Yout = Ycorr × gain
    //
    // gain来源：
    //
    // phase_mode=0 -> auto_gain_factor
    // phase_mode=1 -> manual_gain
    // ============================================================

    amp_compensation #(
        .DATA_WIDTH (DATA_WIDTH),
        .ADC_OFFSET (ADC_OFFSET)

    ) u_amp_compensation (

        .clk            (clk),

        // 数据处理模块仍然只受系统复位控制
        .rst_n          (rst_n),

        .i_valid        (phase_corr_valid),

        .x_in_unsigned  (phase_corr_x),
        .y_in_unsigned  (phase_corr_y),

        .gain_factor    (selected_gain_factor),

        .x_out_unsigned (x_out_unsigned),
        .y_out_unsigned (y_out_unsigned),

        .o_valid        (o_valid)

    );

endmodule
`timescale 1ns / 1ps

module auto_k_calc_cycle #(
    parameter DATA_WIDTH = 14,

    parameter signed [15:0] ADC_OFFSET = 16'sd8192,
    parameter signed [31:0] DEAD_ZONE  = 32'sd0,

    // 为保持原有例化接口而保留
    parameter [31:0] STARTUP_DELAY = 32'd0,

    parameter signed [15:0] CROSS_TH = 16'sd20,

    // 两个有效过零点之间最少有效数据数量
    parameter [31:0] MIN_PERIOD_SAMPLES = 32'd1000,

    parameter [31:0] MAX_PERIOD_SAMPLES = 32'd10000000,

    // 相位系数统计周期数
    parameter integer CYCLES_TO_CALIB = 3

)(
    input  wire                      clk,
    input  wire                      rst_n,

    // 归一化最大最小值检测完成
    input  wire                      start,

    // 当前归一化 X/Y 数据有效
    input  wire                      i_valid,

    input  wire [DATA_WIDTH-1:0]     raw_x,
    input  wire [DATA_WIDTH-1:0]     raw_y,

    output reg signed [15:0]         k_factor,
    output reg                       calib_done
);


// ============================================================
// 1. 去直流
// ============================================================

wire signed [15:0] x_ac;
wire signed [15:0] y_ac;

assign x_ac =
    $signed({2'b00, raw_x}) - ADC_OFFSET;

assign y_ac =
    $signed({2'b00, raw_y}) - ADC_OFFSET;


// ============================================================
// 2. 乘积
//
// 优先映射到 DSP48，减少 LUT 使用
// ============================================================

(* use_dsp = "yes" *)
wire signed [31:0] prod_xy;

(* use_dsp = "yes" *)
wire signed [31:0] prod_xx;

assign prod_xy = x_ac * y_ac;
assign prod_xx = x_ac * x_ac;


// ============================================================
// 3. 负到正过零检测
// ============================================================

reg cross_arm;

wire x_pos_cross;

assign x_pos_cross =
    start &&
    i_valid &&
    cross_arm &&
    (x_ac >= 16'sd0);


always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin

        cross_arm <= 1'b0;

    end
    else if (!start || calib_done) begin

        cross_arm <= 1'b0;

    end
    else if (i_valid) begin

        if (x_ac <= -CROSS_TH) begin

            cross_arm <= 1'b1;

        end
        else if (x_pos_cross) begin

            cross_arm <= 1'b0;

        end
    end
end


// ============================================================
// 4. 状态机
// ============================================================

localparam S_WAIT_START = 4'd0;
localparam S_WAIT_SYNC  = 4'd1;
localparam S_ACCUM      = 4'd2;

localparam S_DIV_PREP   = 4'd3;
localparam S_DIV_RUN    = 4'd4;
localparam S_DIV_DONE   = 4'd5;

localparam S_HOLD       = 4'd6;


reg [3:0] state;

reg [7:0]  cycle_count;
reg [31:0] period_cnt;


// ============================================================
// 5. 三周期累计值
// ============================================================

reg signed [63:0] sum_xy;
reg signed [63:0] sum_xx;


localparam signed [63:0] MIN_SUM_XX =
    64'sd1000000;


// ============================================================
// 6. 顺序除法器
//
// 原公式：
//
// k_factor = (sum_xy << 14) / sum_xx
//
// 原设计：
//     80bit / 64bit 单周期组合除法器
//
// 新设计：
//     78bit / 64bit 顺序恢复除法器
//
// sum_xy：64bit
// 左移14位：78bit
//
// 共78拍完成
// ============================================================


// ------------------------------------------------------------
// sum_xy 绝对值
// ------------------------------------------------------------

wire [63:0] abs_sum_xy;

assign abs_sum_xy =
    sum_xy[63]
    ? (~sum_xy[63:0] + 64'd1)
    : sum_xy[63:0];


// ------------------------------------------------------------
// Dividend：|sum_xy| << 14
// ------------------------------------------------------------

reg [77:0] div_dividend;


// ------------------------------------------------------------
// Divisor：sum_xx
// sum_xx正常情况下始终为正
// ------------------------------------------------------------

reg [63:0] div_divisor;


// ------------------------------------------------------------
// 余数
//
// 除数64bit，因此余数使用65bit
// ------------------------------------------------------------

reg [64:0] div_remainder;


// ------------------------------------------------------------
// 商
// ------------------------------------------------------------

reg [77:0] div_quotient;


// ------------------------------------------------------------
// 迭代次数
//
// 0 ~ 77
// ------------------------------------------------------------

reg [6:0] div_count;


// ------------------------------------------------------------
// 最终结果符号
// ------------------------------------------------------------

reg div_negative;


// ============================================================
// 顺序除法器组合比较量
// ============================================================

wire [64:0] div_rem_shift;

wire [64:0] div_divisor_ext;


// 每拍将 dividend 的最高位送入 remainder
assign div_rem_shift =
    {
        div_remainder[63:0],
        div_dividend[77]
    };


assign div_divisor_ext =
    {
        1'b0,
        div_divisor
    };


// ============================================================
// DEAD_ZONE 无符号幅值
// ============================================================

wire [77:0] dead_zone_mag;

assign dead_zone_mag =
    DEAD_ZONE[31]
    ? 78'd0
    : {{46{1'b0}}, DEAD_ZONE[31:0]};


// ============================================================
// 7. 三周期累计 + 顺序除法
// ============================================================

always @(posedge clk or negedge rst_n) begin

    if (!rst_n) begin

        state       <= S_WAIT_START;

        cycle_count <= 8'd0;
        period_cnt  <= 32'd0;

        sum_xy      <= 64'sd0;
        sum_xx      <= 64'sd0;

        k_factor    <= 16'sd0;
        calib_done  <= 1'b0;


        // ----------------------------------------------------
        // Divider reset
        // ----------------------------------------------------

        div_dividend  <= 78'd0;
        div_divisor   <= 64'd0;
        div_remainder <= 65'd0;
        div_quotient  <= 78'd0;

        div_count     <= 7'd0;
        div_negative  <= 1'b0;

    end
    else begin

        case (state)


// ============================================================
// 等待归一化完成
// ============================================================

            S_WAIT_START: begin

                cycle_count <= 8'd0;
                period_cnt  <= 32'd0;

                sum_xy <= 64'sd0;
                sum_xx <= 64'sd0;

                k_factor   <= 16'sd0;
                calib_done <= 1'b0;

                if (start) begin
                    state <= S_WAIT_SYNC;
                end

            end


// ============================================================
// 等待第一个负到正过零点
//
// 此过零点只作为统计起点
// ============================================================

            S_WAIT_SYNC: begin

                cycle_count <= 8'd0;
                period_cnt  <= 32'd0;

                sum_xy <= 64'sd0;
                sum_xx <= 64'sd0;

                if (!start) begin

                    state <= S_WAIT_START;

                end
                else if (x_pos_cross) begin

                    cycle_count <= 8'd0;
                    period_cnt  <= 32'd0;

                    sum_xy <= 64'sd0;
                    sum_xx <= 64'sd0;

                    state <= S_ACCUM;

                end

            end


// ============================================================
// 累计 CYCLES_TO_CALIB 个完整周期
// ============================================================

            S_ACCUM: begin

                if (!start) begin

                    state <= S_WAIT_START;

                end
                else if (i_valid) begin

                    // ------------------------------------------------
                    // 当前样本加入累计
                    // ------------------------------------------------

                    sum_xy <=
                        sum_xy +
                        {{32{prod_xy[31]}}, prod_xy};

                    sum_xx <=
                        sum_xx +
                        {{32{prod_xx[31]}}, prod_xx};


                    // ------------------------------------------------
                    // 检测完整周期结束
                    // ------------------------------------------------

                    if (
                        x_pos_cross &&
                        (period_cnt >= MIN_PERIOD_SAMPLES)
                    ) begin

                        period_cnt <= 32'd0;


                        // --------------------------------------------
                        // 最后一个完整周期结束
                        // --------------------------------------------

                        if (
                            cycle_count >=
                            CYCLES_TO_CALIB - 1
                        ) begin

                            state <= S_DIV_PREP;

                        end
                        else begin

                            cycle_count <=
                                cycle_count + 8'd1;

                        end

                    end
                    else if (
                        period_cnt >= MAX_PERIOD_SAMPLES
                    ) begin

                        // --------------------------------------------
                        // 超时保护
                        // --------------------------------------------

                        k_factor   <= 16'sd0;
                        calib_done <= 1'b1;

                        state <= S_HOLD;

                    end
                    else begin

                        period_cnt <=
                            period_cnt + 32'd1;

                    end

                end

            end


// ============================================================
// 准备顺序除法
//
// 原公式：
//
// k = sum_xy / sum_xx
//
// Q2.14：
//
// k_factor =
// (sum_xy << 14) / sum_xx
//
// 使用绝对值做无符号除法，最后恢复符号
// ============================================================

            S_DIV_PREP: begin

                if (sum_xx > MIN_SUM_XX) begin

                    // --------------------------------------------
                    // Dividend = |sum_xy| << 14
                    // --------------------------------------------

                    div_dividend <=
                        {
                            abs_sum_xy,
                            14'b0
                        };


                    // --------------------------------------------
                    // Divisor = sum_xx
                    // --------------------------------------------

                    div_divisor <=
                        sum_xx[63:0];


                    // --------------------------------------------
                    // Divider initialize
                    // --------------------------------------------

                    div_remainder <= 65'd0;
                    div_quotient  <= 78'd0;

                    div_count <= 7'd0;


                    // 保存最终符号
                    div_negative <= sum_xy[63];


                    state <= S_DIV_RUN;

                end
                else begin

                    k_factor   <= 16'sd0;
                    calib_done <= 1'b1;

                    state <= S_HOLD;

                end

            end


// ============================================================
// 78拍恢复除法
//
// 每拍处理 dividend 1bit
// ============================================================

            S_DIV_RUN: begin

                // ------------------------------------------------
                // Dividend 左移，依次送出最高位
                // ------------------------------------------------

                div_dividend <=
                    {
                        div_dividend[76:0],
                        1'b0
                    };


                // ------------------------------------------------
                // 恢复除法
                // ------------------------------------------------

                if (
                    div_rem_shift >= div_divisor_ext
                ) begin

                    div_remainder <=
                        div_rem_shift -
                        div_divisor_ext;

                    div_quotient <=
                        {
                            div_quotient[76:0],
                            1'b1
                        };

                end
                else begin

                    div_remainder <=
                        div_rem_shift;

                    div_quotient <=
                        {
                            div_quotient[76:0],
                            1'b0
                        };

                end


                // ------------------------------------------------
                // 78bit 全部计算完成
                // ------------------------------------------------

                if (div_count == 7'd77) begin

                    state <= S_DIV_DONE;

                end
                else begin

                    div_count <=
                        div_count + 7'd1;

                end

            end


// ============================================================
// 除法完成
//
// div_quotient =
//
// |sum_xy| × 16384 / sum_xx
//
// 恢复符号、死区及16bit饱和
// ============================================================

            S_DIV_DONE: begin

                // ------------------------------------------------
                // DEAD ZONE
                // ------------------------------------------------

                if (
                    div_quotient <= dead_zone_mag
                ) begin

                    k_factor <= 16'sd0;

                end


                // ====================================================
                // 正数
                // ====================================================

                else if (!div_negative) begin

                    // > +32767
                    if (
                        div_quotient > 78'd32767
                    ) begin

                        k_factor <= 16'sh7FFF;

                    end
                    else begin

                        k_factor <=
                            $signed(div_quotient[15:0]);

                    end

                end


                // ====================================================
                // 负数
                // ====================================================

                else begin

                    // < -32768
                    if (
                        div_quotient > 78'd32768
                    ) begin

                        k_factor <= 16'sh8000;

                    end
                    else begin

                        k_factor <=
                            -$signed(div_quotient[15:0]);

                    end

                end


                calib_done <= 1'b1;
                state      <= S_HOLD;

            end


// ============================================================
// 保持校准系数
// ============================================================

            S_HOLD: begin

                calib_done <= 1'b1;
                state      <= S_HOLD;

            end


// ============================================================
// Default
// ============================================================

            default: begin

                state <= S_WAIT_START;

            end

        endcase

    end

end


endmodule
`timescale 1ns / 1ps

module phase_gain_calc #(
    parameter integer ITERATIONS = 6
)(
    input  wire               clk,
    input  wire               rst_n,

    // k_factor计算完成后保持为高
    input  wire               start,

    // Q2.14有符号相位校准系数
    input  wire signed [15:0] k_factor,

    // Q2.14无符号幅值补偿系数
    output reg  [15:0]        gain_factor,

    // 幅值补偿系数计算完成后保持为高
    output reg                gain_done
);

    // ============================================================
    // Q2.14常数
    // ============================================================
    localparam [15:0] ONE_Q14      = 16'd16384;
    localparam [18:0] THREE_Q14    = 19'd49152;
    localparam [15:0] MAX_GAIN_Q14 = 16'd32767;

    // gain最大表示约2.0
    // 当|k| >= sqrt(0.75)时，理论gain >= 2
    localparam [15:0] K_LIMIT_Q14 = 16'd14189;

    // ============================================================
    // 状态机
    // ============================================================
    localparam S_WAIT = 3'd0;
    localparam S_SQUARE = 3'd1;
    localparam S_INIT = 3'd2;
    localparam S_ITER = 3'd3;
    localparam S_HOLD = 3'd4;

    reg [2:0] state;

    reg [15:0] k_abs_reg;
    reg [31:0] k_square_q28;

    // s = 1-k2，Q2.14
    reg [15:0] s_q14;

    // 当前牛顿迭代结果，Q2.14
    reg [15:0] g_q14;

    reg [3:0] iter_cnt;

    // ============================================================
    // k绝对值
    // ============================================================
    wire [15:0] k_abs_wire;

    assign k_abs_wire =
        k_factor[15] ? (~k_factor + 16'd1) : k_factor;

    // ============================================================
    // 牛顿迭代：
    //
    // g_next = g × (3-s×g2) / 2
    //
    // 最终收敛到：
    // g = 1/sqrt(s)
    // ============================================================
    wire [31:0] g_square_q28_wire;
    wire [17:0] g_square_q14_wire;

    wire [33:0] s_mul_g2_q28_wire;
    wire [17:0] s_mul_g2_q14_wire;

    wire [18:0] nr_term_q14_wire;
    wire [34:0] nr_mult_wire;
    wire [19:0] g_next_q14_wire;

    assign g_square_q28_wire =
        g_q14 * g_q14;

    assign g_square_q14_wire =
        g_square_q28_wire >> 14;

    assign s_mul_g2_q28_wire =
        s_q14 * g_square_q14_wire;

    assign s_mul_g2_q14_wire =
        s_mul_g2_q28_wire >> 14;

    assign nr_term_q14_wire =
        THREE_Q14 - {1'b0, s_mul_g2_q14_wire};

    // 除以2并保持Q14，因此右移15位
    assign nr_mult_wire =
        g_q14 * nr_term_q14_wire;

    assign g_next_q14_wire =
        nr_mult_wire >> 15;

    // ============================================================
    // 主状态机
    // ============================================================
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state          <= S_WAIT;

            k_abs_reg      <= 16'd0;
            k_square_q28   <= 32'd0;

            s_q14          <= ONE_Q14;
            g_q14          <= ONE_Q14;

            iter_cnt       <= 4'd0;

            gain_factor    <= ONE_Q14;
            gain_done      <= 1'b0;
        end
        else begin
            case (state)

                // ------------------------------------------------
                // 等待相位系数计算完成
                // ------------------------------------------------
                S_WAIT: begin
                    gain_done   <= 1'b0;
                    gain_factor <= ONE_Q14;
                    iter_cnt    <= 4'd0;

                    if (start) begin
                        k_abs_reg <= k_abs_wire;
                        state     <= S_SQUARE;
                    end
                end

                // ------------------------------------------------
                // 计算k2
                // ------------------------------------------------
                S_SQUARE: begin
                    // 相位误差过大，16位Q2.14无法表示大于2的增益
                    if (k_abs_reg >= K_LIMIT_Q14) begin
                        gain_factor <= MAX_GAIN_Q14;
                        gain_done   <= 1'b1;
                        state       <= S_HOLD;
                    end
                    else begin
                        k_square_q28 <= k_abs_reg * k_abs_reg;
                        state        <= S_INIT;
                    end
                end

                // ------------------------------------------------
                // s = 1-k2
                // k2为Q4.28，右移14位变成Q2.14
                // ------------------------------------------------
                S_INIT: begin
                    if ((k_square_q28 >> 14) >= ONE_Q14) begin
                        gain_factor <= MAX_GAIN_Q14;
                        gain_done   <= 1'b1;
                        state       <= S_HOLD;
                    end
                    else begin
                        s_q14 <= ONE_Q14 -
                                 (k_square_q28 >> 14);

                        // 初始值1.0
                        g_q14    <= ONE_Q14;
                        iter_cnt <= 4'd0;
                        state    <= S_ITER;
                    end
                end

                // ------------------------------------------------
                // 牛顿迭代
                // ------------------------------------------------
                S_ITER: begin
                    if (g_next_q14_wire >= MAX_GAIN_Q14) begin
                        g_q14 <= MAX_GAIN_Q14;
                    end
                    else begin
                        g_q14 <= g_next_q14_wire[15:0];
                    end

                    if (iter_cnt >= ITERATIONS - 1) begin
                        if (g_next_q14_wire >= MAX_GAIN_Q14) begin
                            gain_factor <= MAX_GAIN_Q14;
                        end
                        else begin
                            gain_factor <= g_next_q14_wire[15:0];
                        end

                        gain_done <= 1'b1;
                        state     <= S_HOLD;
                    end
                    else begin
                        iter_cnt <= iter_cnt + 4'd1;
                    end
                end

                // ------------------------------------------------
                // 保持补偿系数
                // ------------------------------------------------
                S_HOLD: begin
                    gain_done   <= 1'b1;
                    gain_factor <= gain_factor;
                    state       <= S_HOLD;
                end

                default: begin
                    state <= S_WAIT;
                end

            endcase
        end
    end

endmodule
module phase_calib #(
    parameter DATA_WIDTH = 14,
    parameter signed [15:0] ADC_OFFSET = 16'sd8192
)(
    input  wire                  clk,
    input  wire                  rst_n,
    input  wire                  i_valid,

    input  wire [DATA_WIDTH-1:0] x_in_unsigned,
    input  wire [DATA_WIDTH-1:0] y_in_unsigned,

    input  wire signed [15:0]    k_factor,

    output reg  [DATA_WIDTH-1:0] x_out_unsigned,
    output reg  [DATA_WIDTH-1:0] y_out_unsigned,
    output reg                   o_valid
);

    wire signed [15:0] x_signed;
    wire signed [15:0] y_signed;

    assign x_signed =
        $signed({2'b00, x_in_unsigned}) - ADC_OFFSET;

    assign y_signed =
        $signed({2'b00, y_in_unsigned}) - ADC_OFFSET;

    reg signed [15:0] x_s1;
    reg signed [15:0] y_s1;
    reg signed [31:0] mult_s1;
    reg               valid_s1;

    reg signed [15:0] x_s2;
    reg signed [16:0] y_corr_s2;
    reg               valid_s2;

    wire signed [16:0] kx_s1;

    assign kx_s1 = mult_s1 >>> 14;

    function [DATA_WIDTH-1:0] sat_to_unsigned;
        input signed [16:0] val;
        reg signed [17:0] temp;
        begin
            if (val > 17'sd8191) begin
                sat_to_unsigned = {DATA_WIDTH{1'b1}};
            end
            else if (val < -17'sd8192) begin
                sat_to_unsigned = {DATA_WIDTH{1'b0}};
            end
            else begin
                temp = val + ADC_OFFSET;
                sat_to_unsigned = temp[DATA_WIDTH-1:0];
            end
        end
    endfunction

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            x_s1           <= 16'sd0;
            y_s1           <= 16'sd0;
            mult_s1        <= 32'sd0;
            valid_s1       <= 1'b0;

            x_s2           <= 16'sd0;
            y_corr_s2      <= 17'sd0;
            valid_s2       <= 1'b0;

            x_out_unsigned <= ADC_OFFSET[DATA_WIDTH-1:0];
            y_out_unsigned <= ADC_OFFSET[DATA_WIDTH-1:0];
            o_valid        <= 1'b0;
        end
        else begin
            valid_s1 <= i_valid;

            if (i_valid) begin
                x_s1    <= x_signed;
                y_s1    <= y_signed;
                mult_s1 <= x_signed * k_factor;
            end

            valid_s2 <= valid_s1;

            if (valid_s1) begin
                x_s2 <= x_s1;

                y_corr_s2 <=
                    $signed({y_s1[15], y_s1}) -
                    $signed(kx_s1);
            end

            o_valid <= valid_s2;

            if (valid_s2) begin
                x_out_unsigned <=
                    sat_to_unsigned({x_s2[15], x_s2});

                y_out_unsigned <=
                    sat_to_unsigned(y_corr_s2);
            end
        end
    end

endmodule
`timescale 1ns / 1ps

module amp_compensation #(
    parameter DATA_WIDTH = 14,
    parameter signed [15:0] ADC_OFFSET = 16'sd8192
)(
    input  wire                  clk,
    input  wire                  rst_n,
    input  wire                  i_valid,

    // 相位校准后的数据
    input  wire [DATA_WIDTH-1:0] x_in_unsigned,
    input  wire [DATA_WIDTH-1:0] y_in_unsigned,

    // Q2.14格式
    input  wire [15:0]           gain_factor,

    // 幅值补偿后的数据
    output reg  [DATA_WIDTH-1:0] x_out_unsigned,
    output reg  [DATA_WIDTH-1:0] y_out_unsigned,

    output reg                   o_valid
);

    // ============================================================
    // Y去除8192偏置
    // ============================================================
    wire signed [15:0] y_signed;

    assign y_signed =
        $signed({2'b00, y_in_unsigned}) - ADC_OFFSET;

    // ============================================================
    // 流水线寄存器
    // ============================================================
    reg [DATA_WIDTH-1:0] x_s1;
    reg signed [31:0]    y_mult_s1;
    reg                  valid_s1;

    // gain_factor为Q2.14，因此乘法结果右移14位
    wire signed [31:0] y_gain_signed;

    assign y_gain_signed =
        y_mult_s1 >>> 14;

    // ============================================================
    // 饱和并恢复ADC偏置
    // ============================================================
    function [DATA_WIDTH-1:0] sat_to_unsigned;
        input signed [31:0] val;

        reg signed [32:0] temp;

        begin
            if (val > 32'sd8191) begin
                sat_to_unsigned = {DATA_WIDTH{1'b1}};
            end
            else if (val < -32'sd8192) begin
                sat_to_unsigned = {DATA_WIDTH{1'b0}};
            end
            else begin
                temp = val + ADC_OFFSET;
                sat_to_unsigned = temp[DATA_WIDTH-1:0];
            end
        end
    endfunction

    // ============================================================
    // 幅值补偿流水线
    // ============================================================
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            x_s1           <= ADC_OFFSET[DATA_WIDTH-1:0];
            y_mult_s1      <= 32'sd0;
            valid_s1       <= 1'b0;

            x_out_unsigned <= ADC_OFFSET[DATA_WIDTH-1:0];
            y_out_unsigned <= ADC_OFFSET[DATA_WIDTH-1:0];
            o_valid        <= 1'b0;
        end
        else begin
            // ----------------------------------------------------
            // 第1拍：Y乘补偿增益，X延迟对齐
            // ----------------------------------------------------
            valid_s1 <= i_valid;

            if (i_valid) begin
                x_s1 <= x_in_unsigned;

                y_mult_s1 <=
                    y_signed * $signed({1'b0, gain_factor});
            end

            // ----------------------------------------------------
            // 第2拍：恢复偏置并限幅
            // ----------------------------------------------------
            o_valid <= valid_s1;

            if (valid_s1) begin
                x_out_unsigned <= x_s1;

                y_out_unsigned <=
                    sat_to_unsigned(y_gain_signed);
            end
        end
    end

endmodule
