`timescale 1ns / 1ps

module dnc_filter (
    input                 clk,
    input                 rst_n,
    input                 enable,
    input                 sample_valid,
    input      [15:0]     angle_in,
    input      [7:0]      dnc_threshold,
    input      [7:0]      dnc_alpha,
    output reg [15:0]     angle_out,
    output reg            o_valid
);

    localparam signed [25:0] MAX_ANGLE_Q8 = 26'sd9216000; // 36000 << 8

    reg signed [25:0] angle_internal;
    wire [15:0] current_angle_int = angle_internal[23:8];

    wire signed [17:0] err_raw =
        $signed({2'b00, angle_in}) - $signed({2'b00, current_angle_int});

    reg signed [17:0] err_corr;
    always @(*) begin
        if (err_raw > 18'sd18000)
            err_corr = err_raw - 18'sd36000;
        else if (err_raw < -18'sd18000)
            err_corr = err_raw + 18'sd36000;
        else
            err_corr = err_raw;
    end

    wire [17:0] abs_err = (err_corr < 0) ? -err_corr : err_corr;

    // Explicit enable is controlled by PS. threshold=0/alpha=0 is also a
    // defensive bypass condition for backward compatibility.
    wire bypass_en = !enable ||
                     (abs_err >= {10'd0, dnc_threshold}) ||
                     (dnc_threshold == 8'd0 && dnc_alpha == 8'd0);

    wire signed [26:0] filter_step_q8 =
        err_corr * $signed({1'b0, dnc_alpha});

    reg signed [25:0] next_internal_raw;
    always @(*) begin
        if (bypass_en)
            next_internal_raw = {2'b00, angle_in, 8'd0};
        else
            next_internal_raw = angle_internal + filter_step_q8;
    end

    reg signed [25:0] next_internal_wrapped;
    always @(*) begin
        if (next_internal_raw >= MAX_ANGLE_Q8)
            next_internal_wrapped = next_internal_raw - MAX_ANGLE_Q8;
        else if (next_internal_raw < 0)
            next_internal_wrapped = next_internal_raw + MAX_ANGLE_Q8;
        else
            next_internal_wrapped = next_internal_raw;
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            angle_internal <= 26'd0;
            angle_out      <= 16'd0;
            o_valid        <= 1'b0;
        end else begin
            o_valid <= 1'b0;
            if (sample_valid) begin
                angle_internal <= next_internal_wrapped;
                angle_out      <= next_internal_wrapped[23:8];
                o_valid        <= 1'b1;
            end
        end
    end

endmodule
