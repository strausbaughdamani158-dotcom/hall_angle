`timescale 1ns / 1ps
`default_nettype none

module ANGLE_SENSOR_AXI_TOP #(
    parameter integer C_S_AXI_DATA_WIDTH = 32,
    parameter integer C_S_AXI_ADDR_WIDTH = 10
)(
    // ============================================================
    // AXI4-Lite Slave
    //
    // 推荐：
    // S_AXI_ACLK = PS FCLK_CLK0 = 10 MHz
    // DSP_TOP也直接使用这个10 MHz
    // ============================================================

    input  wire                              S_AXI_ACLK,
    input  wire                              S_AXI_ARESETN,

    input  wire [C_S_AXI_ADDR_WIDTH-1:0]     S_AXI_AWADDR,
    input  wire [2:0]                        S_AXI_AWPROT,
    input  wire                              S_AXI_AWVALID,
    output wire                              S_AXI_AWREADY,

    input  wire [C_S_AXI_DATA_WIDTH-1:0]     S_AXI_WDATA,
    input  wire [(C_S_AXI_DATA_WIDTH/8)-1:0] S_AXI_WSTRB,
    input  wire                              S_AXI_WVALID,
    output wire                              S_AXI_WREADY,

    output reg  [1:0]                        S_AXI_BRESP,
    output reg                               S_AXI_BVALID,
    input  wire                              S_AXI_BREADY,

    input  wire [C_S_AXI_ADDR_WIDTH-1:0]     S_AXI_ARADDR,
    input  wire [2:0]                        S_AXI_ARPROT,
    input  wire                              S_AXI_ARVALID,
    output wire                              S_AXI_ARREADY,

    output reg  [C_S_AXI_DATA_WIDTH-1:0]     S_AXI_RDATA,
    output reg  [1:0]                        S_AXI_RRESP,
    output reg                               S_AXI_RVALID,
    input  wire                              S_AXI_RREADY
);


// ============================================================================
// 0. AXI写通道缓存
// ============================================================================

reg                                  aw_hold_valid;
reg [C_S_AXI_ADDR_WIDTH-1:0]         awaddr_hold;

reg                                  w_hold_valid;
reg [C_S_AXI_DATA_WIDTH-1:0]         wdata_hold;
reg [(C_S_AXI_DATA_WIDTH/8)-1:0]     wstrb_hold;


assign S_AXI_AWREADY = !aw_hold_valid;
assign S_AXI_WREADY  = !w_hold_valid;

assign S_AXI_ARREADY = !S_AXI_RVALID;


// word address
wire [7:0] wr_word_addr;
wire [7:0] rd_word_addr;

assign wr_word_addr = awaddr_hold[9:2];
assign rd_word_addr = S_AXI_ARADDR[9:2];


// ============================================================================
// 1. PS控制寄存器
// ============================================================================

// --------------------------------------------------------------------------
// CONTROL 0x000
// --------------------------------------------------------------------------

reg test_gen_en;

reg offset_comp_en;
reg sensitivity_comp_en;
reg norm_en;
reg phase_coarse_en;
reg phase_fine_en;
reg linear_en;
reg dnc_en;

reg       fir_mode;
reg [2:0] fre_ctrl;


// --------------------------------------------------------------------------
// DDS控制
//
// 0x004 freq_word
// 0x008 phase_error
// --------------------------------------------------------------------------

reg [31:0] dds_freq_word;
reg [15:0] dds_phase_error;


// --------------------------------------------------------------------------
// 0x00C temperature
// --------------------------------------------------------------------------

reg [9:0] tempin;


// --------------------------------------------------------------------------
// 0x010 DNC
// --------------------------------------------------------------------------

reg [7:0] dnc_threshold;
reg [7:0] dnc_alpha;


// --------------------------------------------------------------------------
// Normalization
//
// 0x014 ~ 0x020
// --------------------------------------------------------------------------

reg [13:0] norm_max_x;
reg [13:0] norm_min_x;
reg [13:0] norm_max_y;
reg [13:0] norm_min_y;


// --------------------------------------------------------------------------
// Phase coefficient
//
// Q2.14
// --------------------------------------------------------------------------

reg signed [15:0] phase_k_coarse;
reg        [15:0] phase_gain_coarse;

reg signed [15:0] phase_k_fine;
reg        [15:0] phase_gain_fine;


// --------------------------------------------------------------------------
// Zero
// --------------------------------------------------------------------------

reg [15:0] zero;


// ============================================================================
// 2. Calibration tables
// ============================================================================

// sensitivity table

reg [9:0] parameter1 [0:8];
reg [9:0] parameter2 [0:8];


// temperature points

reg [9:0] temp_table [0:8];


// operating-point compensation

reg signed [13:0] offset1_table [0:8];
reg signed [13:0] offset2_table [0:8];


// 33 point linearization

reg [15:0] linear_x [0:32];


integer i;


// ============================================================================
// 3. Sin/Cos generator
// ============================================================================

wire [13:0] test_sin;
wire [13:0] test_cos;
wire        test_data_valid;


sincos_generator #(
    .DATA_WIDTH(14)
) u_sincos_generator (
    .clk         (S_AXI_ACLK),
    .rst_n       (S_AXI_ARESETN),

    .enable      (test_gen_en),

    .freq_word   (dds_freq_word),
    .phase_error (dds_phase_error),

    .sin_out     (test_sin),
    .cos_out     (test_cos),

    .data_valid  (test_data_valid)
);


// ============================================================================
// 4. DSP monitor signals
// ============================================================================

wire [13:0] raw_ch1_mon;
wire [13:0] raw_ch2_mon;

wire [13:0] offset_ch1_mon;
wire [13:0] offset_ch2_mon;

wire signed [13:0] current_offset1_mon;
wire signed [13:0] current_offset2_mon;

wire [13:0] temp_comp_ch1_mon;
wire [13:0] temp_comp_ch2_mon;

wire [13:0] filter_y_mon;
wire [13:0] filter_x_mon;
wire        filter_valid_mon;

wire [13:0] norm_y_mon;
wire [13:0] norm_x_mon;
wire        norm_valid_mon;

wire [13:0] coarse_y_mon;
wire [13:0] coarse_x_mon;
wire        coarse_valid_mon;

wire [13:0] phase_y_mon;
wire [13:0] phase_x_mon;
wire        phase_valid_mon;

wire [15:0] angle_raw_out;
wire        angle_raw_valid;

wire [15:0] angle_linear_out;
wire        angle_linear_valid;

wire [15:0] angle_final_out;
wire        angle_final_valid;

wire [31:0] filter_sample_seq;
wire [31:0] norm_sample_seq;
wire [31:0] phase_sample_seq;
wire [31:0] angle_sample_seq;


// ============================================================================
// 5. DSP_TOP
//
// DSP_TOP要求：
// adc_ch1_in = Y / Sin
// adc_ch2_in = X / Cos
// ============================================================================

DSP_TOP u_dsp_top (

    .sys_clk                (S_AXI_ACLK),
    .sys_rst_n              (S_AXI_ARESETN),

    .adc_ch1_in             (test_sin),
    .adc_ch2_in             (test_cos),

    .tempin                 (tempin),

    // ============================================================
    // enable
    // ============================================================

    .offset_comp_en         (offset_comp_en),
    .sensitivity_comp_en    (sensitivity_comp_en),

    .norm_en                (norm_en),

    .phase_coarse_en        (phase_coarse_en),
    .phase_fine_en          (phase_fine_en),

    .linear_en              (linear_en),
    .dnc_en                 (dnc_en),

    // ============================================================
    // FIR / DNC
    // ============================================================

    .fir_mode               (fir_mode),
    .fre_ctrl               (fre_ctrl),

    .dnc_threshold          (dnc_threshold),
    .dnc_alpha              (dnc_alpha),

    // ============================================================
    // sensitivity CH1
    // ============================================================

    .parameter1_0           (parameter1[0]),
    .parameter1_1           (parameter1[1]),
    .parameter1_2           (parameter1[2]),
    .parameter1_3           (parameter1[3]),
    .parameter1_4           (parameter1[4]),
    .parameter1_5           (parameter1[5]),
    .parameter1_6           (parameter1[6]),
    .parameter1_7           (parameter1[7]),
    .parameter1_8           (parameter1[8]),

    // ============================================================
    // sensitivity CH2
    // ============================================================

    .parameter2_0           (parameter2[0]),
    .parameter2_1           (parameter2[1]),
    .parameter2_2           (parameter2[2]),
    .parameter2_3           (parameter2[3]),
    .parameter2_4           (parameter2[4]),
    .parameter2_5           (parameter2[5]),
    .parameter2_6           (parameter2[6]),
    .parameter2_7           (parameter2[7]),
    .parameter2_8           (parameter2[8]),

    // ============================================================
    // temperature table
    // ============================================================

    .temp0                  (temp_table[0]),
    .temp1                  (temp_table[1]),
    .temp2                  (temp_table[2]),
    .temp3                  (temp_table[3]),
    .temp4                  (temp_table[4]),
    .temp5                  (temp_table[5]),
    .temp6                  (temp_table[6]),
    .temp7                  (temp_table[7]),
    .temp8                  (temp_table[8]),

    // ============================================================
    // offset CH1
    // ============================================================

    .offset1_param0         (offset1_table[0]),
    .offset1_param1         (offset1_table[1]),
    .offset1_param2         (offset1_table[2]),
    .offset1_param3         (offset1_table[3]),
    .offset1_param4         (offset1_table[4]),
    .offset1_param5         (offset1_table[5]),
    .offset1_param6         (offset1_table[6]),
    .offset1_param7         (offset1_table[7]),
    .offset1_param8         (offset1_table[8]),

    // ============================================================
    // offset CH2
    // ============================================================

    .offset2_param0         (offset2_table[0]),
    .offset2_param1         (offset2_table[1]),
    .offset2_param2         (offset2_table[2]),
    .offset2_param3         (offset2_table[3]),
    .offset2_param4         (offset2_table[4]),
    .offset2_param5         (offset2_table[5]),
    .offset2_param6         (offset2_table[6]),
    .offset2_param7         (offset2_table[7]),
    .offset2_param8         (offset2_table[8]),

    // ============================================================
    // normalization
    // ============================================================

    .norm_max_x             (norm_max_x),
    .norm_min_x             (norm_min_x),

    .norm_max_y             (norm_max_y),
    .norm_min_y             (norm_min_y),

    // ============================================================
    // phase
    // ============================================================

    .phase_k_coarse         (phase_k_coarse),
    .phase_gain_coarse      (phase_gain_coarse),

    .phase_k_fine           (phase_k_fine),
    .phase_gain_fine        (phase_gain_fine),

    .zero                   (zero),

    // ============================================================
    // 33-point linearization
    // ============================================================

    .x0                     (linear_x[0]),
    .x1                     (linear_x[1]),
    .x2                     (linear_x[2]),
    .x3                     (linear_x[3]),
    .x4                     (linear_x[4]),
    .x5                     (linear_x[5]),
    .x6                     (linear_x[6]),
    .x7                     (linear_x[7]),
    .x8                     (linear_x[8]),
    .x9                     (linear_x[9]),
    .x10                    (linear_x[10]),
    .x11                    (linear_x[11]),
    .x12                    (linear_x[12]),
    .x13                    (linear_x[13]),
    .x14                    (linear_x[14]),
    .x15                    (linear_x[15]),
    .x16                    (linear_x[16]),
    .x17                    (linear_x[17]),
    .x18                    (linear_x[18]),
    .x19                    (linear_x[19]),
    .x20                    (linear_x[20]),
    .x21                    (linear_x[21]),
    .x22                    (linear_x[22]),
    .x23                    (linear_x[23]),
    .x24                    (linear_x[24]),
    .x25                    (linear_x[25]),
    .x26                    (linear_x[26]),
    .x27                    (linear_x[27]),
    .x28                    (linear_x[28]),
    .x29                    (linear_x[29]),
    .x30                    (linear_x[30]),
    .x31                    (linear_x[31]),
    .x32                    (linear_x[32]),

    // ============================================================
    // monitor outputs
    // ============================================================

    .raw_ch1_mon            (raw_ch1_mon),
    .raw_ch2_mon            (raw_ch2_mon),

    .offset_ch1_mon         (offset_ch1_mon),
    .offset_ch2_mon         (offset_ch2_mon),

    .current_offset1_mon    (current_offset1_mon),
    .current_offset2_mon    (current_offset2_mon),

    .temp_comp_ch1_mon      (temp_comp_ch1_mon),
    .temp_comp_ch2_mon      (temp_comp_ch2_mon),

    .filter_y_mon           (filter_y_mon),
    .filter_x_mon           (filter_x_mon),
    .filter_valid_mon       (filter_valid_mon),

    .norm_y_mon             (norm_y_mon),
    .norm_x_mon             (norm_x_mon),
    .norm_valid_mon         (norm_valid_mon),

    .coarse_y_mon           (coarse_y_mon),
    .coarse_x_mon           (coarse_x_mon),
    .coarse_valid_mon       (coarse_valid_mon),

    .phase_y_mon            (phase_y_mon),
    .phase_x_mon            (phase_x_mon),
    .phase_valid_mon        (phase_valid_mon),

    .angle_raw_out          (angle_raw_out),
    .angle_raw_valid        (angle_raw_valid),

    .angle_linear_out       (angle_linear_out),
    .angle_linear_valid     (angle_linear_valid),

    .angle_final_out        (angle_final_out),
    .angle_final_valid      (angle_final_valid),

    .filter_sample_seq      (filter_sample_seq),
    .norm_sample_seq        (norm_sample_seq),
    .phase_sample_seq       (phase_sample_seq),
    .angle_sample_seq       (angle_sample_seq)
);


// ============================================================================
// 6. AXI Write
//
// Xil_Out32产生完整32bit写，正常WSTRB = 4'b1111
// ============================================================================

always @(posedge S_AXI_ACLK or negedge S_AXI_ARESETN) begin
    if (!S_AXI_ARESETN) begin

        aw_hold_valid <= 1'b0;
        awaddr_hold   <= {C_S_AXI_ADDR_WIDTH{1'b0}};

        w_hold_valid  <= 1'b0;
        wdata_hold    <= {C_S_AXI_DATA_WIDTH{1'b0}};
        wstrb_hold    <= {(C_S_AXI_DATA_WIDTH/8){1'b0}};

        S_AXI_BRESP   <= 2'b00;
        S_AXI_BVALID  <= 1'b0;

        // --------------------------------------------------------
        // basic control
        // --------------------------------------------------------

        test_gen_en          <= 1'b1;

        offset_comp_en       <= 1'b0;
        sensitivity_comp_en  <= 1'b0;

        norm_en              <= 1'b0;

        phase_coarse_en      <= 1'b0;
        phase_fine_en        <= 1'b0;

        linear_en            <= 1'b0;
        dnc_en               <= 1'b0;

        fir_mode             <= 1'b0;
        fre_ctrl             <= 3'd2;

        // 50 Hz @ 10 MHz
        dds_freq_word        <= 32'd21475;

        dds_phase_error      <= 16'd0;

        tempin               <= 10'd512;

        dnc_threshold        <= 8'd20;
        dnc_alpha            <= 8'd32;

        norm_max_x           <= 14'd14675;
        norm_min_x           <= 14'd1709;

        norm_max_y           <= 14'd14675;
        norm_min_y           <= 14'd1709;

        phase_k_coarse       <= 16'sd0;
        phase_gain_coarse    <= 16'd16384;

        phase_k_fine         <= 16'sd0;
        phase_gain_fine      <= 16'd16384;

        zero                 <= 16'd0;

        // --------------------------------------------------------
        // sensitivity table
        // --------------------------------------------------------

        for (i = 0; i < 9; i = i + 1) begin
            parameter1[i] <= 10'd256;
            parameter2[i] <= 10'd256;

            offset1_table[i] <= 14'sd0;
            offset2_table[i] <= 14'sd0;
        end

        // --------------------------------------------------------
        // temperature table
        // --------------------------------------------------------

        temp_table[0] <= 10'd0;
        temp_table[1] <= 10'd128;
        temp_table[2] <= 10'd256;
        temp_table[3] <= 10'd384;
        temp_table[4] <= 10'd512;
        temp_table[5] <= 10'd640;
        temp_table[6] <= 10'd768;
        temp_table[7] <= 10'd896;
        temp_table[8] <= 10'd1023;

        // --------------------------------------------------------
        // Identity 33-point linearization
        // --------------------------------------------------------

        for (i = 0; i < 33; i = i + 1) begin
            linear_x[i] <= i * 16'd1125;
        end

    end
    else begin

        // ========================================================
        // AW capture
        // ========================================================

        if (!aw_hold_valid && S_AXI_AWVALID) begin
            awaddr_hold   <= S_AXI_AWADDR;
            aw_hold_valid <= 1'b1;
        end


        // ========================================================
        // W capture
        // ========================================================

        if (!w_hold_valid && S_AXI_WVALID) begin
            wdata_hold   <= S_AXI_WDATA;
            wstrb_hold   <= S_AXI_WSTRB;
            w_hold_valid <= 1'b1;
        end


        // ========================================================
        // Execute write when both address and data are available
        // ========================================================

        if (aw_hold_valid &&
            w_hold_valid  &&
            !S_AXI_BVALID) begin

            if (|wstrb_hold) begin

                // =================================================
                // normal registers
                // =================================================

                case (wr_word_addr)

                    // ------------------------------------------------
                    // 0x000 CONTROL
                    // ------------------------------------------------
                    8'h00: begin

                        test_gen_en         <= wdata_hold[0];

                        offset_comp_en      <= wdata_hold[1];
                        sensitivity_comp_en <= wdata_hold[2];

                        norm_en             <= wdata_hold[3];

                        phase_coarse_en     <= wdata_hold[4];
                        phase_fine_en       <= wdata_hold[5];

                        linear_en           <= wdata_hold[6];
                        dnc_en              <= wdata_hold[7];

                        fir_mode            <= wdata_hold[8];
                        fre_ctrl            <= wdata_hold[11:9];

                    end


                    // 0x004
                    8'h01:
                        dds_freq_word <= wdata_hold;


                    // 0x008
                    8'h02:
                        dds_phase_error <= wdata_hold[15:0];


                    // 0x00C
                    8'h03:
                        tempin <= wdata_hold[9:0];


                    // 0x010
                    8'h04: begin
                        dnc_threshold <= wdata_hold[7:0];
                        dnc_alpha     <= wdata_hold[15:8];
                    end


                    // 0x014
                    8'h05:
                        norm_max_x <= wdata_hold[13:0];

                    // 0x018
                    8'h06:
                        norm_min_x <= wdata_hold[13:0];

                    // 0x01C
                    8'h07:
                        norm_max_y <= wdata_hold[13:0];

                    // 0x020
                    8'h08:
                        norm_min_y <= wdata_hold[13:0];


                    // 0x024
                    8'h09:
                        phase_k_coarse <= wdata_hold[15:0];

                    // 0x028
                    8'h0A:
                        phase_gain_coarse <= wdata_hold[15:0];

                    // 0x02C
                    8'h0B:
                        phase_k_fine <= wdata_hold[15:0];

                    // 0x030
                    8'h0C:
                        phase_gain_fine <= wdata_hold[15:0];

                    // 0x034
                    8'h0D:
                        zero <= wdata_hold[15:0];

                    default: begin
                    end

                endcase


                // =================================================
                // CH1 sensitivity
                //
                // 0x040 ~ 0x060
                // =================================================

                if ((wr_word_addr >= 8'h10) &&
                    (wr_word_addr <= 8'h18)) begin

                    parameter1[wr_word_addr - 8'h10]
                        <= wdata_hold[9:0];

                end


                // =================================================
                // CH2 sensitivity
                //
                // 0x080 ~ 0x0A0
                // =================================================

                if ((wr_word_addr >= 8'h20) &&
                    (wr_word_addr <= 8'h28)) begin

                    parameter2[wr_word_addr - 8'h20]
                        <= wdata_hold[9:0];

                end


                // =================================================
                // temperature table
                //
                // 0x0C0 ~ 0x0E0
                // =================================================

                if ((wr_word_addr >= 8'h30) &&
                    (wr_word_addr <= 8'h38)) begin

                    temp_table[wr_word_addr - 8'h30]
                        <= wdata_hold[9:0];

                end


                // =================================================
                // offset CH1
                //
                // 0x100 ~ 0x120
                // =================================================

                if ((wr_word_addr >= 8'h40) &&
                    (wr_word_addr <= 8'h48)) begin

                    offset1_table[wr_word_addr - 8'h40]
                        <= wdata_hold[13:0];

                end


                // =================================================
                // offset CH2
                //
                // 0x140 ~ 0x160
                // =================================================

                if ((wr_word_addr >= 8'h50) &&
                    (wr_word_addr <= 8'h58)) begin

                    offset2_table[wr_word_addr - 8'h50]
                        <= wdata_hold[13:0];

                end


                // =================================================
                // 33-point linearization
                //
                // 0x200 ~ 0x280
                // =================================================

                if ((wr_word_addr >= 8'h80) &&
                    (wr_word_addr <= 8'hA0)) begin

                    linear_x[wr_word_addr - 8'h80]
                        <= wdata_hold[15:0];

                end

            end


            aw_hold_valid <= 1'b0;
            w_hold_valid  <= 1'b0;

            S_AXI_BRESP  <= 2'b00;
            S_AXI_BVALID <= 1'b1;

        end


        // ========================================================
        // write response complete
        // ========================================================

        if (S_AXI_BVALID && S_AXI_BREADY) begin
            S_AXI_BVALID <= 1'b0;
        end

    end
end


// ============================================================================
// 7. AXI Read MUX
// ============================================================================

reg [31:0] read_data_mux;

always @(*) begin

    read_data_mux = 32'd0;


    case (rd_word_addr)

        // ========================================================
        // control readback
        // ========================================================

        8'h00: begin

            read_data_mux[0]    = test_gen_en;

            read_data_mux[1]    = offset_comp_en;
            read_data_mux[2]    = sensitivity_comp_en;

            read_data_mux[3]    = norm_en;

            read_data_mux[4]    = phase_coarse_en;
            read_data_mux[5]    = phase_fine_en;

            read_data_mux[6]    = linear_en;
            read_data_mux[7]    = dnc_en;

            read_data_mux[8]    = fir_mode;
            read_data_mux[11:9] = fre_ctrl;

        end


        8'h01:
            read_data_mux = dds_freq_word;


        8'h02:
            read_data_mux = {16'd0, dds_phase_error};


        8'h03:
            read_data_mux = {22'd0, tempin};


        8'h04:
            read_data_mux = {
                16'd0,
                dnc_alpha,
                dnc_threshold
            };


        8'h05:
            read_data_mux = {18'd0, norm_max_x};

        8'h06:
            read_data_mux = {18'd0, norm_min_x};

        8'h07:
            read_data_mux = {18'd0, norm_max_y};

        8'h08:
            read_data_mux = {18'd0, norm_min_y};


        8'h09:
            read_data_mux = {
                {16{phase_k_coarse[15]}},
                phase_k_coarse
            };


        8'h0A:
            read_data_mux = {16'd0, phase_gain_coarse};


        8'h0B:
            read_data_mux = {
                {16{phase_k_fine[15]}},
                phase_k_fine
            };


        8'h0C:
            read_data_mux = {16'd0, phase_gain_fine};


        8'h0D:
            read_data_mux = {16'd0, zero};


        // ========================================================
        // STATUS
        //
        // 0x300 -> word C0
        // ========================================================

        // DDS
        8'hC0:
            read_data_mux = {
                test_data_valid,
                3'd0,
                test_cos,
                test_sin
            };


        // raw input
        8'hC1:
            read_data_mux = {
                4'd0,
                raw_ch2_mon,
                raw_ch1_mon
            };


        // offset compensated
        8'hC2:
            read_data_mux = {
                4'd0,
                offset_ch2_mon,
                offset_ch1_mon
            };


        // current signed offset
        8'hC3:
            read_data_mux = {
                4'd0,
                current_offset2_mon,
                current_offset1_mon
            };


        // sensitivity / temperature compensated
        8'hC4:
            read_data_mux = {
                4'd0,
                temp_comp_ch2_mon,
                temp_comp_ch1_mon
            };


        // filter
        8'hC5:
            read_data_mux = {
                filter_valid_mon,
                3'd0,
                filter_x_mon,
                filter_y_mon
            };


        // normalization
        8'hC6:
            read_data_mux = {
                norm_valid_mon,
                3'd0,
                norm_x_mon,
                norm_y_mon
            };


        // coarse
        8'hC7:
            read_data_mux = {
                coarse_valid_mon,
                3'd0,
                coarse_x_mon,
                coarse_y_mon
            };


        // phase
        8'hC8:
            read_data_mux = {
                phase_valid_mon,
                3'd0,
                phase_x_mon,
                phase_y_mon
            };


        // raw angle
        8'hC9:
            read_data_mux = {
                angle_raw_valid,
                15'd0,
                angle_raw_out
            };


        // linear angle
        8'hCA:
            read_data_mux = {
                angle_linear_valid,
                15'd0,
                angle_linear_out
            };


        // final angle
        8'hCB:
            read_data_mux = {
                angle_final_valid,
                15'd0,
                angle_final_out
            };


        8'hCC:
            read_data_mux = filter_sample_seq;


        8'hCD:
            read_data_mux = norm_sample_seq;


        8'hCE:
            read_data_mux = phase_sample_seq;


        8'hCF:
            read_data_mux = angle_sample_seq;


        default: begin

            // ====================================================
            // sensitivity CH1
            // ====================================================

            if ((rd_word_addr >= 8'h10) &&
                (rd_word_addr <= 8'h18)) begin

                read_data_mux =
                    {22'd0,
                     parameter1[rd_word_addr - 8'h10]};

            end


            // ====================================================
            // sensitivity CH2
            // ====================================================

            else if ((rd_word_addr >= 8'h20) &&
                     (rd_word_addr <= 8'h28)) begin

                read_data_mux =
                    {22'd0,
                     parameter2[rd_word_addr - 8'h20]};

            end


            // ====================================================
            // temperature
            // ====================================================

            else if ((rd_word_addr >= 8'h30) &&
                     (rd_word_addr <= 8'h38)) begin

                read_data_mux =
                    {22'd0,
                     temp_table[rd_word_addr - 8'h30]};

            end


            // ====================================================
            // offset CH1
            // ====================================================

            else if ((rd_word_addr >= 8'h40) &&
                     (rd_word_addr <= 8'h48)) begin

                read_data_mux =
                    {{18{offset1_table[
                        rd_word_addr - 8'h40
                    ][13]}},
                    offset1_table[
                        rd_word_addr - 8'h40
                    ]};

            end


            // ====================================================
            // offset CH2
            // ====================================================

            else if ((rd_word_addr >= 8'h50) &&
                     (rd_word_addr <= 8'h58)) begin

                read_data_mux =
                    {{18{offset2_table[
                        rd_word_addr - 8'h50
                    ][13]}},
                    offset2_table[
                        rd_word_addr - 8'h50
                    ]};

            end


            // ====================================================
            // linearization x0 ~ x32
            // ====================================================

            else if ((rd_word_addr >= 8'h80) &&
                     (rd_word_addr <= 8'hA0)) begin

                read_data_mux =
                    {16'd0,
                     linear_x[rd_word_addr - 8'h80]};

            end


            else begin
                read_data_mux = 32'd0;
            end

        end

    endcase

end


// ============================================================================
// 8. AXI Read Channel
// ============================================================================

always @(posedge S_AXI_ACLK or negedge S_AXI_ARESETN) begin
    if (!S_AXI_ARESETN) begin

        S_AXI_RDATA  <= 32'd0;
        S_AXI_RRESP  <= 2'b00;
        S_AXI_RVALID <= 1'b0;

    end
    else begin

        if (!S_AXI_RVALID && S_AXI_ARVALID) begin

            S_AXI_RDATA  <= read_data_mux;
            S_AXI_RRESP  <= 2'b00;
            S_AXI_RVALID <= 1'b1;

        end
        else if (S_AXI_RVALID && S_AXI_RREADY) begin

            S_AXI_RVALID <= 1'b0;

        end

    end
end


endmodule

`default_nettype wire