`timescale 1ns / 1ps
module temp_eeprom_top(
    input wire clk,
    input wire rst_n,
    input wire entp,
    input wire enof,

 // CH1灵敏度系数
   input wire [9:0] parameter1_0,
   input wire [9:0] parameter1_1,
   input wire [9:0] parameter1_2,
   input wire [9:0] parameter1_3,
   input wire [9:0] parameter1_4,
   input wire [9:0] parameter1_5,
   input wire [9:0] parameter1_6,
   input wire [9:0] parameter1_7,
   input wire [9:0] parameter1_8,


// CH2灵敏度系数
   input wire [9:0] parameter2_0,
   input wire [9:0] parameter2_1,
   input wire [9:0] parameter2_2,
   input wire [9:0] parameter2_3,
   input wire [9:0] parameter2_4,
   input wire [9:0] parameter2_5,
   input wire [9:0] parameter2_6,
   input wire [9:0] parameter2_7,
   input wire [9:0] parameter2_8,

    // Signed static-offset calibration points.
    input wire signed [13:0] offset1_param0, offset1_param1, offset1_param2,
    input wire signed [13:0] offset1_param3, offset1_param4, offset1_param5,
    input wire signed [13:0] offset1_param6, offset1_param7, offset1_param8,

    input wire signed [13:0] offset2_param0, offset2_param1, offset2_param2,
    input wire signed [13:0] offset2_param3, offset2_param4, offset2_param5,
    input wire signed [13:0] offset2_param6, offset2_param7, offset2_param8,

    input wire [9:0] temp1, temp2, temp3, temp4, temp5,
    input wire [9:0] temp6, temp7, temp8, temp9,

    input wire [13:0] data_in1,
    input wire [13:0] data_in2,

    output reg  [13:0] tpout1,
    output reg  [13:0] tpout2,

    // Competition monitor ports for PS display/debug
    output wire [13:0] offset_comp_out1,
    output wire [13:0] offset_comp_out2,
    output wire signed [13:0] current_offset1_mon,
    output wire signed [13:0] current_offset2_mon,

    input wire [9:0] tempin
);


// ============================================================
// 当前温度对应的工作点补偿量
//
// 注意：
// offset_interp 输出的是 signed 补偿量
//
// 假设 EEPROM 中存储的是：
//
//     offset = 8192 - 实际工作点
//
// 那么：
//
//     corrected_data = raw_data + offset
//
// 就会把工作点拉回8192。
// ============================================================
wire signed [13:0] current_offset1;
wire signed [13:0] current_offset2;

reg [13:0] offset_comp_data1;
reg [13:0] offset_comp_data2;

assign offset_comp_out1 = offset_comp_data1;
assign offset_comp_out2 = offset_comp_data2;
assign current_offset1_mon = current_offset1;
assign current_offset2_mon = current_offset2;
// ============================================================
// 工作点补偿模块
// ============================================================
offset_interp off_calc_ch1 (
    .clk(clk),
    .rst_n(rst_n),
    .tempin(tempin),

    .temp1(temp1),
    .temp2(temp2),
    .temp3(temp3),
    .temp4(temp4),
    .temp5(temp5),
    .temp6(temp6),
    .temp7(temp7),
    .temp8(temp8),
    .temp9(temp9),

    .offset_param0(offset1_param0),
    .offset_param1(offset1_param1),
    .offset_param2(offset1_param2),
    .offset_param3(offset1_param3),
    .offset_param4(offset1_param4),
    .offset_param5(offset1_param5),
    .offset_param6(offset1_param6),
    .offset_param7(offset1_param7),
    .offset_param8(offset1_param8),

    .offset_out(current_offset1)
);


offset_interp off_calc_ch2 (
    .clk(clk),
    .rst_n(rst_n),
    .tempin(tempin),

    .temp1(temp1),
    .temp2(temp2),
    .temp3(temp3),
    .temp4(temp4),
    .temp5(temp5),
    .temp6(temp6),
    .temp7(temp7),
    .temp8(temp8),
    .temp9(temp9),

    .offset_param0(offset2_param0),
    .offset_param1(offset2_param1),
    .offset_param2(offset2_param2),
    .offset_param3(offset2_param3),
    .offset_param4(offset2_param4),
    .offset_param5(offset2_param5),
    .offset_param6(offset2_param6),
    .offset_param7(offset2_param7),
    .offset_param8(offset2_param8),

    .offset_out(current_offset2)
);


// ============================================================
// offset_interp 是8级流水线。
//
// 为了让ADC数据与current_offset严格对应，
// data_in1/data_in2也必须延迟8拍。
//
// tempin、entp、enof同样进行8拍延迟。
// ============================================================

reg [13:0] data1_d1, data1_d2, data1_d3, data1_d4;
reg [13:0] data1_d5, data1_d6, data1_d7, data1_d8;

reg [13:0] data2_d1, data2_d2, data2_d3, data2_d4;
reg [13:0] data2_d5, data2_d6, data2_d7, data2_d8;

reg [9:0] tempin_d1, tempin_d2, tempin_d3, tempin_d4;
reg [9:0] tempin_d5, tempin_d6, tempin_d7, tempin_d8;

reg entp_d1, entp_d2, entp_d3, entp_d4;
reg entp_d5, entp_d6, entp_d7, entp_d8;

reg enof_d1, enof_d2, enof_d3, enof_d4;
reg enof_d5, enof_d6, enof_d7, enof_d8;


// ============================================================
// 8拍数据对齐
// ============================================================
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin

        data1_d1 <= 14'd0;
        data1_d2 <= 14'd0;
        data1_d3 <= 14'd0;
        data1_d4 <= 14'd0;
        data1_d5 <= 14'd0;
        data1_d6 <= 14'd0;
        data1_d7 <= 14'd0;
        data1_d8 <= 14'd0;

        data2_d1 <= 14'd0;
        data2_d2 <= 14'd0;
        data2_d3 <= 14'd0;
        data2_d4 <= 14'd0;
        data2_d5 <= 14'd0;
        data2_d6 <= 14'd0;
        data2_d7 <= 14'd0;
        data2_d8 <= 14'd0;

        tempin_d1 <= 10'd0;
        tempin_d2 <= 10'd0;
        tempin_d3 <= 10'd0;
        tempin_d4 <= 10'd0;
        tempin_d5 <= 10'd0;
        tempin_d6 <= 10'd0;
        tempin_d7 <= 10'd0;
        tempin_d8 <= 10'd0;

        entp_d1 <= 1'b0;
        entp_d2 <= 1'b0;
        entp_d3 <= 1'b0;
        entp_d4 <= 1'b0;
        entp_d5 <= 1'b0;
        entp_d6 <= 1'b0;
        entp_d7 <= 1'b0;
        entp_d8 <= 1'b0;

        enof_d1 <= 1'b0;
        enof_d2 <= 1'b0;
        enof_d3 <= 1'b0;
        enof_d4 <= 1'b0;
        enof_d5 <= 1'b0;
        enof_d6 <= 1'b0;
        enof_d7 <= 1'b0;
        enof_d8 <= 1'b0;

    end else begin

        // ----------------------------------------------------
        // CH1
        // ----------------------------------------------------
        data1_d1 <= data_in1;
        data1_d2 <= data1_d1;
        data1_d3 <= data1_d2;
        data1_d4 <= data1_d3;
        data1_d5 <= data1_d4;
        data1_d6 <= data1_d5;
        data1_d7 <= data1_d6;
        data1_d8 <= data1_d7;

        // ----------------------------------------------------
        // CH2
        // ----------------------------------------------------
        data2_d1 <= data_in2;
        data2_d2 <= data2_d1;
        data2_d3 <= data2_d2;
        data2_d4 <= data2_d3;
        data2_d5 <= data2_d4;
        data2_d6 <= data2_d5;
        data2_d7 <= data2_d6;
        data2_d8 <= data2_d7;

        // ----------------------------------------------------
        // 温度
        // ----------------------------------------------------
        tempin_d1 <= tempin;
        tempin_d2 <= tempin_d1;
        tempin_d3 <= tempin_d2;
        tempin_d4 <= tempin_d3;
        tempin_d5 <= tempin_d4;
        tempin_d6 <= tempin_d5;
        tempin_d7 <= tempin_d6;
        tempin_d8 <= tempin_d7;

        // ----------------------------------------------------
        // 灵敏度补偿使能
        // ----------------------------------------------------
        entp_d1 <= entp;
        entp_d2 <= entp_d1;
        entp_d3 <= entp_d2;
        entp_d4 <= entp_d3;
        entp_d5 <= entp_d4;
        entp_d6 <= entp_d5;
        entp_d7 <= entp_d6;
        entp_d8 <= entp_d7;

        // ----------------------------------------------------
        // 工作点补偿使能
        // ----------------------------------------------------
        enof_d1 <= enof;
        enof_d2 <= enof_d1;
        enof_d3 <= enof_d2;
        enof_d4 <= enof_d3;
        enof_d5 <= enof_d4;
        enof_d6 <= enof_d5;
        enof_d7 <= enof_d6;
        enof_d8 <= enof_d7;

    end
end


// ============================================================
// 第一步：工作点补偿
//
// raw_data + offset
//
// 扩展为signed 18bit，避免溢出。
// ============================================================

wire signed [17:0] ext_data1 =
    $signed({4'b0000, data1_d8});

wire signed [17:0] ext_data2 =
    $signed({4'b0000, data2_d8});

wire signed [17:0] ext_offset1 =
    $signed({
        {4{current_offset1[13]}},
        current_offset1
    });

wire signed [17:0] ext_offset2 =
    $signed({
        {4{current_offset2[13]}},
        current_offset2
    });


wire signed [17:0] offset_sum1 =
    ext_data1 + ext_offset1;

wire signed [17:0] offset_sum2 =
    ext_data2 + ext_offset2;


// ============================================================
// 工作点补偿后数据
//
// enof = 0：
//      不做工作点补偿
//
// enof = 1：
//      data + offset
//
// 并进行 0~16383 饱和。
// ============================================================




always @(*) begin

    // ========================================================
    // CH1
    // ========================================================
    if (!enof_d8) begin

        offset_comp_data1 = data1_d8;

    end else if (offset_sum1 < 18'sd0) begin

        offset_comp_data1 = 14'd0;

    end else if (offset_sum1 > 18'sd16383) begin

        offset_comp_data1 = 14'h3fff;

    end else begin

        offset_comp_data1 = offset_sum1[13:0];

    end


    // ========================================================
    // CH2
    // ========================================================
    if (!enof_d8) begin

        offset_comp_data2 = data2_d8;

    end else if (offset_sum2 < 18'sd0) begin

        offset_comp_data2 = 14'd0;

    end else if (offset_sum2 > 18'sd16383) begin

        offset_comp_data2 = 14'h3fff;

    end else begin

        offset_comp_data2 = offset_sum2[13:0];

    end

end


// ============================================================
// 第二步：灵敏度补偿
//
// 输入已经经过工作点补偿。
//
// temp_top内部现在执行：
//
//     OUT = 8192 +
//           (IN - 8192) * K
//
// 因此只改变幅值，不改变8192工作点。
// ============================================================

wire [13:0] sens_out1;
wire [13:0] sens_out2;


temp_top tp1 (
    .clk(clk),
    .rst(rst_n),

    .entp(entp_d8),

    .parameter0(parameter1_0),
    .parameter1(parameter1_1),
    .parameter2(parameter1_2),
    .parameter3(parameter1_3),
    .parameter4(parameter1_4),
    .parameter5(parameter1_5),
    .parameter6(parameter1_6),
    .parameter7(parameter1_7),
    .parameter8(parameter1_8),

    .temp1(temp1),
    .temp2(temp2),
    .temp3(temp3),
    .temp4(temp4),
    .temp5(temp5),
    .temp6(temp6),
    .temp7(temp7),
    .temp8(temp8),
    .temp9(temp9),

    .tempin(tempin_d8),

    .datain(offset_comp_data1),

    .data_out(sens_out1)
);


temp_top tp2 (
    .clk(clk),
    .rst(rst_n),

    .entp(entp_d8),

    .parameter0(parameter2_0),
    .parameter1(parameter2_1),
    .parameter2(parameter2_2),
    .parameter3(parameter2_3),
    .parameter4(parameter2_4),
    .parameter5(parameter2_5),
    .parameter6(parameter2_6),
    .parameter7(parameter2_7),
    .parameter8(parameter2_8),

    .temp1(temp1),
    .temp2(temp2),
    .temp3(temp3),
    .temp4(temp4),
    .temp5(temp5),
    .temp6(temp6),
    .temp7(temp7),
    .temp8(temp8),
    .temp9(temp9),

    .tempin(tempin_d8),

    .datain(offset_comp_data2),

    .data_out(sens_out2)
);


// ============================================================
// 最终输出
//
// 此处不再进行工作点相加。
// 因为工作点补偿已经在temp_top之前完成。
// ============================================================
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin

        tpout1 <= 14'd0;
        tpout2 <= 14'd0;

    end else begin

        tpout1 <= sens_out1;
        tpout2 <= sens_out2;

    end
end


endmodule

// Eight-stage signed interpolation pipeline for the static offset table.
module offset_interp(
    input wire clk,
    input wire rst_n,
    input wire [9:0] tempin,
    input wire [9:0] temp1, temp2, temp3, temp4, temp5, temp6, temp7, temp8, temp9,
    input wire signed [13:0] offset_param0, offset_param1, offset_param2,
    input wire signed [13:0] offset_param3, offset_param4, offset_param5,
    input wire signed [13:0] offset_param6, offset_param7, offset_param8,
    output reg signed [13:0] offset_out
);

    // Stage 1: interval selection and endpoint clamping.
    reg [9:0] tempin_s1;
    reg [9:0] lower_temp_s1, upper_temp_s1;
    reg signed [13:0] lower_param_s1, upper_param_s1;

    // Stage 2: aligned differences.
    reg [9:0] temp_span_s2;
    reg [9:0] temp_offset_s2;
    reg signed [14:0] param_diff_s2;
    reg signed [13:0] lower_param_s2;

    // Stages 3 and 4: full-width signed numerator and quotient.
    reg signed [25:0] numerator_s3;
    reg [9:0] temp_span_s3;
    reg signed [13:0] lower_param_s3;
    reg signed [25:0] delta_s4;
    reg signed [13:0] lower_param_s4;

    // Stages 5 through 8: saturated result and alignment registers.
    reg signed [13:0] interp_s5;
    reg signed [13:0] interp_s6;
    reg signed [13:0] interp_s7;

    wire signed [25:0] temp_offset_ext_s2 = $signed({16'b0, temp_offset_s2});
    wire signed [25:0] param_diff_ext_s2 =
        $signed({{11{param_diff_s2[14]}}, param_diff_s2});
    wire signed [25:0] numerator_w = temp_offset_ext_s2 * param_diff_ext_s2;

    wire signed [26:0] lower_param_ext_s4 =
        $signed({{13{lower_param_s4[13]}}, lower_param_s4});
    wire signed [26:0] delta_ext_s4 = $signed({delta_s4[25], delta_s4});
    wire signed [26:0] offset_sum_w = lower_param_ext_s4 + delta_ext_s4;

    // Stage 1
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            tempin_s1      <= 10'd0;
            lower_temp_s1  <= 10'd0;
            upper_temp_s1  <= 10'd0;
            lower_param_s1 <= 14'sd0;
            upper_param_s1 <= 14'sd0;
        end else begin
            tempin_s1 <= tempin;
            if (tempin <= temp1) begin
                lower_temp_s1  <= temp1;
                upper_temp_s1  <= temp1;
                lower_param_s1 <= offset_param0;
                upper_param_s1 <= offset_param0;
            end else if (tempin < temp2) begin
                lower_temp_s1  <= temp1;
                upper_temp_s1  <= temp2;
                lower_param_s1 <= offset_param0;
                upper_param_s1 <= offset_param1;
            end else if (tempin < temp3) begin
                lower_temp_s1  <= temp2;
                upper_temp_s1  <= temp3;
                lower_param_s1 <= offset_param1;
                upper_param_s1 <= offset_param2;
            end else if (tempin < temp4) begin
                lower_temp_s1  <= temp3;
                upper_temp_s1  <= temp4;
                lower_param_s1 <= offset_param2;
                upper_param_s1 <= offset_param3;
            end else if (tempin < temp5) begin
                lower_temp_s1  <= temp4;
                upper_temp_s1  <= temp5;
                lower_param_s1 <= offset_param3;
                upper_param_s1 <= offset_param4;
            end else if (tempin < temp6) begin
                lower_temp_s1  <= temp5;
                upper_temp_s1  <= temp6;
                lower_param_s1 <= offset_param4;
                upper_param_s1 <= offset_param5;
            end else if (tempin < temp7) begin
                lower_temp_s1  <= temp6;
                upper_temp_s1  <= temp7;
                lower_param_s1 <= offset_param5;
                upper_param_s1 <= offset_param6;
            end else if (tempin < temp8) begin
                lower_temp_s1  <= temp7;
                upper_temp_s1  <= temp8;
                lower_param_s1 <= offset_param6;
                upper_param_s1 <= offset_param7;
            end else if (tempin < temp9) begin
                lower_temp_s1  <= temp8;
                upper_temp_s1  <= temp9;
                lower_param_s1 <= offset_param7;
                upper_param_s1 <= offset_param8;
            end else begin
                lower_temp_s1  <= temp9;
                upper_temp_s1  <= temp9;
                lower_param_s1 <= offset_param8;
                upper_param_s1 <= offset_param8;
            end
        end
    end

    // Stage 2
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            temp_span_s2   <= 10'd0;
            temp_offset_s2 <= 10'd0;
            param_diff_s2  <= 15'sd0;
            lower_param_s2 <= 14'sd0;
        end else begin
            if (upper_temp_s1 > lower_temp_s1) begin
                temp_span_s2   <= upper_temp_s1 - lower_temp_s1;
                temp_offset_s2 <= tempin_s1 - lower_temp_s1;
            end else begin
                temp_span_s2   <= 10'd0;
                temp_offset_s2 <= 10'd0;
            end
            param_diff_s2 <=
                $signed({upper_param_s1[13], upper_param_s1}) -
                $signed({lower_param_s1[13], lower_param_s1});
            lower_param_s2 <= lower_param_s1;
        end
    end

    // Stage 3
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            numerator_s3   <= 26'sd0;
            temp_span_s3   <= 10'd0;
            lower_param_s3 <= 14'sd0;
        end else begin
            numerator_s3   <= numerator_w;
            temp_span_s3   <= temp_span_s2;
            lower_param_s3 <= lower_param_s2;
        end
    end

    // Stage 4
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            delta_s4       <= 26'sd0;
            lower_param_s4 <= 14'sd0;
        end else begin
            if (temp_span_s3 != 10'd0)
                delta_s4 <= numerator_s3 / $signed({1'b0, temp_span_s3});
            else
                delta_s4 <= 26'sd0;
            lower_param_s4 <= lower_param_s3;
        end
    end

    // Stage 5: signed addition and saturation to [-8192, 8191].
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            interp_s5 <= 14'sd0;
        end else if (offset_sum_w > 27'sd8191) begin
            interp_s5 <= 14'sd8191;
        end else if (offset_sum_w < -27'sd8192) begin
            interp_s5 <= 14'sh2000;
        end else begin
            interp_s5 <= offset_sum_w[13:0];
        end
    end

    // Stages 6, 7 and 8.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            interp_s6 <= 14'sd0;
            interp_s7 <= 14'sd0;
            offset_out <= 14'sd0;
        end else begin
            interp_s6 <= interp_s5;
            interp_s7 <= interp_s6;
            offset_out <= interp_s7;
        end
    end

endmodule

// Q8 sensitivity compensation with a strict, fully aligned 8-stage pipeline.
module temp_top(
    input wire clk,
    input wire rst,
    input wire entp,
    input wire [9:0] parameter0,
    input wire [9:0] parameter1,
    input wire [9:0] parameter2,
    input wire [9:0] parameter3,
    input wire [9:0] parameter4,
    input wire [9:0] parameter5,
    input wire [9:0] parameter6,
    input wire [9:0] parameter7,
    input wire [9:0] parameter8,
    input wire [9:0] temp1,
    input wire [9:0] temp2,
    input wire [9:0] temp3,
    input wire [9:0] temp4,
    input wire [9:0] temp5,
    input wire [9:0] temp6,
    input wire [9:0] temp7,
    input wire [9:0] temp8,
    input wire [9:0] temp9,
    input wire [9:0] tempin,
    input wire [13:0] datain,
    output reg [13:0] data_out
);

// ============================================================
// 灵敏度系数格式保持不变
//
// 输入 parameter 为 Q8：
//      256 = 1.0
//      307 ≈ 1.2
//      128 = 0.5
//
// 插值过程中额外保留 8bit 小数，内部使用 Q16。
// ============================================================
localparam [18:0] COEFF_Q16_MAX = 19'd261888; // 1023 << 8

// 工作点补偿前一级已经把波形中心校准到 8192
localparam signed [14:0] ADC_CENTER = 15'sd8192;


// ============================================================
// Stage 1:
// 温度区间选择、端点钳位、数据同步
// ============================================================
reg [9:0] tempin_s1;
reg [9:0] lower_temp_s1, upper_temp_s1;
reg [9:0] lower_param_s1, upper_param_s1;
reg [13:0] datain_d1;
reg entp_d1;


// ============================================================
// Stage 2:
// 温度差值、参数差值
// ============================================================
reg [9:0] temp_span_s2;
reg [9:0] temp_offset_s2;
reg signed [10:0] param_diff_s2;
reg [9:0] lower_param_s2;
reg [13:0] datain_d2;
reg entp_d2;


// ============================================================
// Stage 3:
// 插值分子，Q16
// ============================================================
reg signed [29:0] numerator_q16_s3;
reg [9:0] temp_span_s3;
reg signed [29:0] lower_q16_s3;
reg [13:0] datain_d3;
reg entp_d3;


// ============================================================
// Stage 4:
// 插值除法
// ============================================================
reg signed [29:0] delta_q16_s4;
reg signed [29:0] lower_q16_s4;
reg [13:0] datain_d4;
reg entp_d4;


// ============================================================
// Stage 5:
// 得到最终 Q16 灵敏度系数
// ============================================================
reg [18:0] coeff_q16_s5;
reg [13:0] datain_d5;
reg entp_d5;


// ============================================================
// Stage 6:
// 先减去 8192，再乘灵敏度系数
//
// delta范围：
//     -8192 ~ +8191
//
// coeff_q16：Q16
// ============================================================
reg signed [33:0] product_s6;
reg [13:0] datain_d6;
reg entp_d6;


// ============================================================
// Stage 7:
// Q16结果右移16bit，再重新加回8192
// ============================================================
reg signed [17:0] scaled_data_s7;
reg [13:0] datain_d7;
reg entp_d7;


// ============================================================
// 系数插值相关组合逻辑
// ============================================================
wire signed [21:0] temp_offset_ext_s2 =
    $signed({12'b0, temp_offset_s2});

wire signed [21:0] param_diff_ext_s2 =
    $signed({{11{param_diff_s2[10]}}, param_diff_s2});

wire signed [21:0] param_temp_product_w =
    temp_offset_ext_s2 * param_diff_ext_s2;

wire signed [29:0] param_temp_product_ext_w =
    $signed({
        {8{param_temp_product_w[21]}},
        param_temp_product_w
    });

wire signed [29:0] numerator_q16_w =
    param_temp_product_ext_w <<< 8;


// ============================================================
// Stage 4 -> Stage 5 系数求和
// ============================================================
wire signed [30:0] lower_q16_ext_s4 =
    $signed({
        lower_q16_s4[29],
        lower_q16_s4
    });

wire signed [30:0] delta_q16_ext_s4 =
    $signed({
        delta_q16_s4[29],
        delta_q16_s4
    });

wire signed [30:0] coeff_sum_q16_w =
    lower_q16_ext_s4 + delta_q16_ext_s4;


// ============================================================
// 灵敏度补偿数据通路
//
// 原来：
//     datain × K
//
// 现在：
//     8192 + (datain - 8192) × K
// ============================================================

// datain 转成有符号 15bit
wire signed [14:0] datain_signed_s5 =
    $signed({1'b0, datain_d5});

// 以8192为中心
wire signed [14:0] centered_data_s5 =
    datain_signed_s5 - ADC_CENTER;

// 系数虽然物理意义为无符号，但为了完成 signed × signed，
// 前面补0转换为正的有符号20bit数
wire signed [19:0] coeff_signed_s5 =
    $signed({1'b0, coeff_q16_s5});

// 15bit × 20bit
wire signed [34:0] centered_product_w =
    centered_data_s5 * coeff_signed_s5;


// ============================================================
// Stage 1
// ============================================================
always @(posedge clk or negedge rst) begin
    if (!rst) begin
        tempin_s1      <= 10'd0;
        lower_temp_s1  <= 10'd0;
        upper_temp_s1  <= 10'd0;
        lower_param_s1 <= 10'd0;
        upper_param_s1 <= 10'd0;
        datain_d1      <= 14'd0;
        entp_d1        <= 1'b0;
    end
    else begin
        tempin_s1 <= tempin;
        datain_d1 <= datain;
        entp_d1   <= entp;

        if (tempin <= temp1) begin
            lower_temp_s1  <= temp1;
            upper_temp_s1  <= temp1;
            lower_param_s1 <= parameter0;
            upper_param_s1 <= parameter0;
        end
        else if (tempin < temp2) begin
            lower_temp_s1  <= temp1;
            upper_temp_s1  <= temp2;
            lower_param_s1 <= parameter0;
            upper_param_s1 <= parameter1;
        end
        else if (tempin < temp3) begin
            lower_temp_s1  <= temp2;
            upper_temp_s1  <= temp3;
            lower_param_s1 <= parameter1;
            upper_param_s1 <= parameter2;
        end
        else if (tempin < temp4) begin
            lower_temp_s1  <= temp3;
            upper_temp_s1  <= temp4;
            lower_param_s1 <= parameter2;
            upper_param_s1 <= parameter3;
        end
        else if (tempin < temp5) begin
            lower_temp_s1  <= temp4;
            upper_temp_s1  <= temp5;
            lower_param_s1 <= parameter3;
            upper_param_s1 <= parameter4;
        end
        else if (tempin < temp6) begin
            lower_temp_s1  <= temp5;
            upper_temp_s1  <= temp6;
            lower_param_s1 <= parameter4;
            upper_param_s1 <= parameter5;
        end
        else if (tempin < temp7) begin
            lower_temp_s1  <= temp6;
            upper_temp_s1  <= temp7;
            lower_param_s1 <= parameter5;
            upper_param_s1 <= parameter6;
        end
        else if (tempin < temp8) begin
            lower_temp_s1  <= temp7;
            upper_temp_s1  <= temp8;
            lower_param_s1 <= parameter6;
            upper_param_s1 <= parameter7;
        end
        else if (tempin < temp9) begin
            lower_temp_s1  <= temp8;
            upper_temp_s1  <= temp9;
            lower_param_s1 <= parameter7;
            upper_param_s1 <= parameter8;
        end
        else begin
            lower_temp_s1  <= temp9;
            upper_temp_s1  <= temp9;
            lower_param_s1 <= parameter8;
            upper_param_s1 <= parameter8;
        end
    end
end


// ============================================================
// Stage 2
// ============================================================
always @(posedge clk or negedge rst) begin
    if (!rst) begin
        temp_span_s2   <= 10'd0;
        temp_offset_s2 <= 10'd0;
        param_diff_s2  <= 11'sd0;
        lower_param_s2 <= 10'd0;
        datain_d2      <= 14'd0;
        entp_d2        <= 1'b0;
    end
    else begin

        if (upper_temp_s1 > lower_temp_s1) begin
            temp_span_s2   <= upper_temp_s1 - lower_temp_s1;
            temp_offset_s2 <= tempin_s1 - lower_temp_s1;
        end
        else begin
            temp_span_s2   <= 10'd0;
            temp_offset_s2 <= 10'd0;
        end

        param_diff_s2 <=
            $signed({1'b0, upper_param_s1}) -
            $signed({1'b0, lower_param_s1});

        lower_param_s2 <= lower_param_s1;

        datain_d2 <= datain_d1;
        entp_d2   <= entp_d1;
    end
end


// ============================================================
// Stage 3
// ============================================================
always @(posedge clk or negedge rst) begin
    if (!rst) begin
        numerator_q16_s3 <= 30'sd0;
        temp_span_s3     <= 10'd0;
        lower_q16_s3     <= 30'sd0;
        datain_d3        <= 14'd0;
        entp_d3          <= 1'b0;
    end
    else begin
        numerator_q16_s3 <= numerator_q16_w;
        temp_span_s3     <= temp_span_s2;

        lower_q16_s3 <=
            $signed({1'b0, lower_param_s2, 8'b0});

        datain_d3 <= datain_d2;
        entp_d3   <= entp_d2;
    end
end


// ============================================================
// Stage 4
// ============================================================
always @(posedge clk or negedge rst) begin
    if (!rst) begin
        delta_q16_s4 <= 30'sd0;
        lower_q16_s4 <= 30'sd0;
        datain_d4    <= 14'd0;
        entp_d4      <= 1'b0;
    end
    else begin

        if (temp_span_s3 != 10'd0)
            delta_q16_s4 <=
                numerator_q16_s3 /
                $signed({1'b0, temp_span_s3});
        else
            delta_q16_s4 <= 30'sd0;

        lower_q16_s4 <= lower_q16_s3;

        datain_d4 <= datain_d3;
        entp_d4   <= entp_d3;
    end
end


// ============================================================
// Stage 5
// ============================================================
always @(posedge clk or negedge rst) begin
    if (!rst) begin
        coeff_q16_s5 <= 19'd0;
        datain_d5    <= 14'd0;
        entp_d5      <= 1'b0;
    end
    else begin

        if (coeff_sum_q16_w <= 31'sd0)
            coeff_q16_s5 <= 19'd0;

        else if (coeff_sum_q16_w >= 31'sd261888)
            coeff_q16_s5 <= COEFF_Q16_MAX;

        else
            coeff_q16_s5 <= coeff_sum_q16_w[18:0];

        datain_d5 <= datain_d4;
        entp_d5   <= entp_d4;
    end
end


// ============================================================
// Stage 6
//
// 关键修改：
// 不再直接 datain × K
//
// 改成：
//     (datain - 8192) × K
// ============================================================
always @(posedge clk or negedge rst) begin
    if (!rst) begin
        product_s6 <= 34'sd0;
        datain_d6  <= 14'd0;
        entp_d6    <= 1'b0;
    end
    else begin

        product_s6 <= centered_product_w;

        datain_d6 <= datain_d5;
        entp_d6   <= entp_d5;
    end
end


// ============================================================
// Stage 7
//
// product 为 Q16，因此 >>>16
//
// 然后重新加回8192：
//
// result = 8192 +
//          ((datain - 8192) * coeff)
// ============================================================
always @(posedge clk or negedge rst) begin
    if (!rst) begin
        scaled_data_s7 <= 18'sd0;
        datain_d7      <= 14'd0;
        entp_d7        <= 1'b0;
    end
    else begin

        scaled_data_s7 <=
            18'sd8192 +
            (product_s6 >>> 16);

        datain_d7 <= datain_d6;
        entp_d7   <= entp_d6;
    end
end


// ============================================================
// Stage 8
//
// entp = 0：原始数据旁路
//
// entp = 1：
//     灵敏度补偿结果
//
// 最终饱和：
//     < 0     -> 0
//     > 16383 -> 16383
// ============================================================
always @(posedge clk or negedge rst) begin
    if (!rst) begin
        data_out <= 14'd0;
    end
    else if (!entp_d7) begin

        data_out <= datain_d7;

    end
    else if (scaled_data_s7 < 18'sd0) begin

        data_out <= 14'd0;

    end
    else if (scaled_data_s7 > 18'sd16383) begin

        data_out <= 14'h3fff;

    end
    else begin

        data_out <= scaled_data_s7[13:0];

    end
end

endmodule