set_property PACKAGE_PIN N20 [get_ports UART_1_0_txd]
set_property PACKAGE_PIN P19 [get_ports UART_1_0_rxd]

set_property IOSTANDARD LVCMOS33 [get_ports UART_1_0_txd]
set_property IOSTANDARD LVCMOS33 [get_ports UART_1_0_rxd]

set_property PACKAGE_PIN L15 [get_ports {DataIn_1_0}]
set_property IOSTANDARD LVCMOS33 [get_ports {DataIn_1_0}]
set_property PACKAGE_PIN K14 [get_ports {DataIn_2_0}]
set_property IOSTANDARD LVCMOS33 [get_ports {DataIn_2_0}]
set_property PACKAGE_PIN J14 [get_ports {data_vaild_0}]
set_property IOSTANDARD LVCMOS33 [get_ports {data_vaild_0}]

set_property PACKAGE_PIN G14 [get_ports {hall_out_0[0]}]
set_property IOSTANDARD LVCMOS33 [get_ports {hall_out_0[0]}]
set_property PACKAGE_PIN F16 [get_ports {hall_out_0[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports {hall_out_0[1]}]
set_property PACKAGE_PIN H15 [get_ports {hall_out_0[2]}]
set_property IOSTANDARD LVCMOS33 [get_ports {hall_out_0[2]}]