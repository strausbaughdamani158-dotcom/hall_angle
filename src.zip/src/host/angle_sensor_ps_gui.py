import tkinter as tk
from tkinter import ttk, messagebox
import serial
import serial.tools.list_ports
import threading
import queue
import time
import numpy as np

import matplotlib
matplotlib.use('TkAgg')
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt

from PIL import Image, ImageTk
import os
import sys


plt.rcParams['font.sans-serif'] = [
    'SimHei',
    'Microsoft YaHei',
    'Arial'
]

plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.size'] = 11

GLOBAL_FONT = ("Microsoft YaHei", 11)
GLOBAL_BG = "#F0F0F0"


# ================================================================
# 资源路径
# ================================================================

def resource_path(relative_path):

    try:
        base_path = sys._MEIPASS

    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(
        base_path,
        relative_path
    )


# ================================================================
# 主界面
# ================================================================

# PS ASCII protocol v6, external CIC input and physical Hall output. Dependencies: pyserial numpy matplotlib pillow; Python with Tk.
UART_BAUD = 115200  # Must match the standalone BSP/PS UART configuration.
AXI_BASE = 0x43C00000
HALL_MODES = ('PWM', 'SENT', 'UVW', 'ABZ')
HALL_PWM_FREQUENCIES = (50, 500, 2000, 4000)
HALL_CONTROL_MASK = 0xF
HALL_PIN_TEXT = (
    'G14：PWM',
    'G14：SENT',
    'G14：W    F16：V    H15：U',
    'G14：Z    F16：B    H15：A',
)


def encode_hall_control(mode, frequency):
    if mode not in range(4) or frequency not in range(4):
        raise ValueError('请选择输出模式和 PWM 频率')
    return (mode & 1) | ((mode & 2) << 2) | (frequency << 1)


def decode_hall_control(value):
    return (value & 1) | ((value >> 2) & 2), (value >> 1) & 3


RW_OFFSETS = {0x000} | set(range(0x00C, 0x03C, 4))
for _base, _count in [(0x040,9),(0x080,9),(0x0C0,9),(0x100,9),(0x140,9),(0x200,33)]:
    RW_OFFSETS.update(_base + 4*i for i in range(_count))
RO_OFFSETS = set(range(0x300, 0x340, 4))

# Legacy GUI logical word addresses -> actual AXI byte offsets. Never sent on wire.
WORD_MAP = {37:0x024, 39:0x02C, 41:0x028, 43:0x030,
            46:0x014,48:0x018,50:0x01C,52:0x020,121:0x034}
for _old, _new, _count in [(1,0x040,9),(164,0x080,9),(19,0x0C0,9),
                            (128,0x140,9),(146,0x100,9),(54,0x200,33)]:
    WORD_MAP.update({_old+2*i:_new+4*i for i in range(_count)})
BYTE_MAP = {addr+j:(offset, j*8) for addr,offset in WORD_MAP.items() for j in (0,1)}
BYTE_MAP.update({123:(0x010,0),124:(0x010,8)})

class AsciiLink:
    """One request outstanding. Timeout/corrupt reply poisons connection; no write retry."""
    def __init__(self, port):
        self.port = port
        self.lock = threading.RLock()
        self.capturing=False
        self.sample_count=0

    def request(self, command):
        with self.lock:
            if not self.port.is_open:
                raise RuntimeError('串口未连接；请关闭再打开串口开关')
            try:
                wire = (command + '\n').encode('ascii')
                if self.port.write(wire) != len(wire):
                    raise IOError('串口发送不完整')
                deadline = time.monotonic() + (10.0 if command == 'e' else 3.0)
                data = bytearray()
                while time.monotonic() < deadline:
                    c = self.port.read(1)
                    if not c:
                        continue
                    if c == b'\n':
                        line = data.decode('ascii').strip()
                        data.clear()
                        if not line or line.startswith('READY '):
                            continue
                        fields = line.split()
                        if fields[0] == 'ERR':
                            raise RuntimeError('PS拒绝请求: ' + line)
                        if fields[0] != 'OK':
                            raise IOError('协议不匹配: ' + line)
                        return fields
                    data.extend(c)
                    if len(data) > 8192:
                        raise IOError('PS响应过长')
                raise TimeoutError('PS响应超时；写入结果未知，请重连后读回确认，未自动重发')
            except Exception:
                self.port.close()
                raise

    def validate(self, condition):
        if not condition:
            self.port.close()
            raise IOError('PS响应内容不匹配，连接已关闭')

    def hello(self):
        with self.lock:
            self.port.write(b'\n')
            time.sleep(0.15)
            self.port.reset_input_buffer()
            f=self.request('hello')
            if len(f)!=5 or f[:4]!=['OK','HELLO','6','0x43C00000']:
                self.port.close()
                raise RuntimeError('需要外部CIC/Hall协议v6的PS程序；请更新main.c、链接数学库m并重新下载ELF')
            try:
                self.max_samples=int(f[4],16)
            except ValueError:
                self.validate(False)
            self.validate(1<=self.max_samples<=32768)
            self.validate(self.request('a')==['OK','A'])
            self.capturing=False

    def read(self, offset):
        if offset not in RW_OFFSETS | RO_OFFSETS:
            raise ValueError('地址未映射或未按4字节对齐')
        with self.lock:
            f = self.request(f'r 0x{offset:03X}')
            self.validate(len(f) == 4 and f[1] == 'R' and f[2] == f'0x{offset:03X}')
            try:
                value = int(f[3],16)
            except ValueError:
                self.validate(False)
            self.validate(0 <= value <= 0xFFFFFFFF)
            return value

    def write(self, offset, value):
        return self.change('w', offset, 0xFFFFFFFF, value)

    def hall_config(self, mode=None, frequency=None):
        """Read or set all Hall fields through the PS, with readback validation."""
        with self.lock:
            expected = None
            if mode is None:
                if frequency is not None:
                    raise ValueError('缺少输出模式')
                command = 'hall'
            else:
                expected = encode_hall_control(mode, frequency)
                if self.capturing:
                    raise RuntimeError('采集期间不能改写参数，请先结束采样')
                command = f'hall {mode} {frequency}'
            fields = self.request(command)
            self.validate(len(fields) == 5 and fields[:2] == ['OK', 'HALL'])
            try:
                actual_mode, actual_frequency, control = (int(v, 16) for v in fields[2:])
            except ValueError:
                self.validate(False)
            self.validate(0 <= control <= 0xFFFFFFFF)
            self.validate(actual_mode in range(4) and actual_frequency in range(4))
            self.validate(decode_hall_control(control) == (actual_mode, actual_frequency))
            if expected is not None:
                self.validate((control & HALL_CONTROL_MASK) == expected)
            return control

    def modify(self, offset, mask, value):
        return self.change('m', offset, mask, value)

    def change(self, op, offset, mask, value):
        if offset not in RW_OFFSETS:
            raise ValueError('该地址不可写')
        if not (0 <= value <= 0xFFFFFFFF and 0 <= mask <= 0xFFFFFFFF):
            raise ValueError('掩码和值必须为无符号32位整数')
        with self.lock:
            if self.capturing:
                raise RuntimeError('采集期间不能改写参数，请先结束采样并等待PS统计完成')
            args = f'0x{mask:08X} ' if op == 'm' else ''
            f = self.request(f'{op} 0x{offset:03X} {args}0x{value:08X}')
            self.validate(len(f) == 5 and f[1] == op.upper() and f[2] == f'0x{offset:03X}')
            try:
                intended, actual = int(f[3],16), int(f[4],16)
            except ValueError:
                self.validate(False)
            self.validate(0 <= intended <= 0xFFFFFFFF and 0 <= actual <= 0xFFFFFFFF)
            self.validate((intended & mask) == (value & mask))
            if intended != actual:
                raise IOError(f'写后读回不一致: 预期0x{intended:08X}, 实际0x{actual:08X}')
            return actual




    def begin_capture(self,offset):
        with self.lock:
            self.validate(self.request(f'b 0x{offset:03X}')==['OK','B',f'0x{offset:03X}'])
            self.capture_offset=offset
            self.sample_count=0
            self.capturing=True

    def capture_sample(self):
        with self.lock:
            f=self.request('s')
            self.validate(len(f)==5 and f[:3]==['OK','S',f'0x{self.capture_offset:03X}'])
            try:
                n,v=int(f[3],16),int(f[4],16)
            except ValueError:self.validate(False)
            self.validate(n==self.sample_count+1 and 0<=v<=0xFFFFFFFF)
            self.sample_count=n
            return v

    def capture_stats(self,final=False):
        with self.lock:
            op='e' if final else 'p'
            f=self.request(op)
            self.validate(len(f)==24 and f[:3]==['OK',op.upper(),f'0x{self.capture_offset:03X}'])
            names=['count','xmin','xmax','ymin','ymax','phase_mdeg','k','gain','flags','cycles','used','rate_milli','control','stage','work_x2','work_y2','lin_status','lin_percent_u6','lin_error_mdeg','lin_points','lin_direction']
            try:values=[int(v,16) for v in f[3:]]
            except ValueError:self.validate(False)
            self.validate(all(0<=v<=0xFFFFFFFF for v in values))
            d=dict(zip(names,values))
            self.validate(d['count']==self.sample_count)
            for key in ('xmin','xmax','ymin','ymax','k','work_x2','work_y2','lin_direction'):
                if d[key]&0x80000000:d[key]-=1<<32
            d['offset']=self.capture_offset
            if final:self.capturing=False
            return d


# Verified against uploaded angle_sensor_axi_slave_lite_v1_0_S00_AXI.
# Clock frequency is not specified by the AXI wrapper. 10 MHz is the prior system setting.
SOURCES = {'CIC输出 0x300':0x300,'RAW 0x304':0x304,'工作点补偿 0x308':0x308,
    '当前偏移 0x30C':0x30C,'灵敏度补偿 0x310':0x310,'滤波 0x314':0x314,
    '归一化 0x318':0x318,'粗相位 0x31C':0x31C,'细相位 0x320':0x320}

def decode_pair(offset,value):
    low,high=value & 0x3FFF,(value >> 14) & 0x3FFF
    if offset == 0x30C:
        return tuple(v-16384 if v & 8192 else v for v in (low,high))
    if offset in (0x300,0x304,0x308,0x310):
        return low,high
    return high,low  # DSP x,y downstream

def pair_labels(offset):
    if offset == 0x300:return 'CIC CH1','CIC CH2'
    if offset == 0x30C:return 'offset1（有符号）','offset2（有符号）'
    if offset in (0x304,0x308,0x310):return 'CH1','CH2'
    return 'X（14位原始码）','Y（14位原始码）'

def decode_status(offset,value):
    if 0x300 <= offset <= 0x320:
        a,b=decode_pair(offset,value)
        labels=pair_labels(offset)
        valid=f' valid={(value >> 31) & 1}' if offset in (0x300,0x314,0x318,0x31C,0x320) else ''
        return f'{labels[0]}={a}, {labels[1]}={b}{valid}'
    if offset in (0x324,0x328,0x32C):
        result = f'angle={value & 65535} ({(value & 65535)/100:.2f}°), valid={(value >> 31)&1}'
        if offset == 0x32C:
            hall_levels = (((value >> 28) & 3) << 1) | ((value >> 30) & 1)
            result += f', hall[2:0]={hall_levels:03b}'
        return result
    return f'seq={value}'

class AdvancedUI:

    def __init__(self, master):

        self.master = master

        self.master.title(
            "霍尔角度传感器上位机"
        )

        self.master.geometry(
            "1600x865"
        )

        self.master.configure(
            bg=GLOBAL_BG
        )

        self.master.protocol(
            "WM_DELETE_WINDOW",
            self.on_closing
        )

        self.master.option_add(
            "*Font",
            GLOBAL_FONT
        )

        self.master.option_add(
            "*Background",
            GLOBAL_BG
        )

        style = ttk.Style()

        style.configure(
            ".",
            font=GLOBAL_FONT,
            background=GLOBAL_BG
        )

        style.configure(
            "TCheckbutton",
            font=GLOBAL_FONT,
            background=GLOBAL_BG
        )

        style.configure(
            "TCombobox",
            font=GLOBAL_FONT,
            background=GLOBAL_BG
        )

        style.configure(
            "TLabelframe",
            background=GLOBAL_BG
        )

        style.configure(
            "TLabelframe.Label",
            font=(
                "Microsoft YaHei",
                11,
                "bold"
            ),
            background=GLOBAL_BG
        )

        self.port_var = tk.StringVar()

        self.mode_var = tk.IntVar(
            value=1
        )

        self.target_var = tk.StringVar(
            value="编程寄存器"
        )

        self.switch_vars = {

            "串口":
                tk.BooleanVar(),

            "灵敏度补偿":
                tk.BooleanVar(),

            "滤波器编程":
                tk.BooleanVar(),

            "归一化":
                tk.BooleanVar(),

            "线性插值":
                tk.BooleanVar(),

            "静态工作点补偿":
                tk.BooleanVar()
        }

        self.serial_port = None

        self.is_collecting = False

        self.ch1_dec = []
        self.ch2_dec = []
        self.angle_data = []

        self.link = None
        self.events = queue.Queue()
        self.closing = False
        self.collection_pending = False
        self.last_ps_stats = None
        self.setup_ui()
        self.configure_ps_ui()
        self.master.report_callback_exception = self.report_error
        self.master.after(30, self.drain_events)


    # ============================================================
    # 关闭程序
    # ============================================================

    def on_closing(self):
        self.is_collecting = False
        self.closing = True
        if self.serial_port:
            self.serial_port.close()
        self.master.destroy()



    # ============================================================
    # 通用按钮
    # ============================================================

    def create_btn(
        self,
        parent,
        text,
        command,
        width=8,
        bg="#E8E8E8",
        fg="black"
    ):

        return tk.Button(
            parent,
            text=text,
            command=command,
            width=width,
            bg=bg,
            fg=fg,
            relief=tk.RAISED,
            bd=1,
            font=GLOBAL_FONT
        )


    # ============================================================
    # UI
    # ============================================================

    def setup_ui(self):

        main_frame = tk.Frame(
            self.master,
            bg=GLOBAL_BG
        )

        main_frame.pack(
            fill=tk.BOTH,
            expand=True,
            padx=10,
            pady=10
        )

        # ========================================================
        # 底部容器
        # ========================================================

        bottom_container = tk.Frame(
            main_frame,
            bg=GLOBAL_BG
        )

        bottom_container.pack(
            side=tk.BOTTOM,
            fill=tk.BOTH,
            expand=False,
            pady=(5, 0)
        )

        top_section = tk.Frame(
            main_frame,
            bg=GLOBAL_BG
        )

        top_section.pack(
            side=tk.TOP,
            fill=tk.BOTH,
            expand=True,
            pady=(0, 10)
        )

        left_panel = tk.Frame(
            top_section,
            bg=GLOBAL_BG
        )

        left_panel.pack(
            side=tk.LEFT,
            fill=tk.Y,
            padx=(0, 10)
        )

        left_top_frame = tk.Frame(
            left_panel,
            bg=GLOBAL_BG
        )

        left_top_frame.pack(
            side=tk.TOP,
            fill=tk.X
        )

        left_top_col1 = tk.Frame(
            left_top_frame,
            bg=GLOBAL_BG
        )

        left_top_col1.pack(
            side=tk.LEFT,
            fill=tk.BOTH,
            expand=True,
            padx=(0, 5)
        )

        # ========================================================
        # 系统全局开关
        # ========================================================

        switch_frame = tk.LabelFrame(
            left_top_col1,
            text="系统全局开关",
            padx=5,
            pady=5,
            bg=GLOBAL_BG
        )

        switch_frame.pack(
            side=tk.TOP,
            fill=tk.BOTH,
            expand=True
        )

        tk.Label(
            switch_frame,
            text="COM口:",
            bg=GLOBAL_BG
        ).grid(
            row=0,
            column=0,
            padx=2,
            pady=3,
            sticky=tk.E
        )

        self.port_combo = ttk.Combobox(
            switch_frame,
            textvariable=self.port_var,
            width=11,
            postcommand=self.refresh_ports
        )

        self.port_combo.grid(
            row=0,
            column=1,
            padx=2,
            pady=3,
            sticky=tk.W
        )

        self.refresh_ports()

        ttk.Checkbutton(
            switch_frame,
            text="串口开关   ",
            variable=self.switch_vars[
                "串口"
            ],
            command=self.toggle_serial
        ).grid(
            row=1,
            column=0,
            columnspan=2,
            sticky=tk.W,
            padx=5
        )

        self.target_combo = ttk.Combobox(
            switch_frame,
            textvariable=self.target_var,
            values=[
                "编程寄存器"
            ],
            width=17
        )

        self.target_combo.grid(
            row=2,
            column=0,
            columnspan=2,
            pady=3,
            padx=5,
            sticky=tk.W
        )

        cb_frame = tk.Frame(
            switch_frame,
            bg=GLOBAL_BG
        )

        cb_frame.grid(
            row=3,
            column=0,
            columnspan=2,
            sticky=tk.W,
            padx=2,
            pady=2
        )

        ttk.Checkbutton(
            cb_frame,
            text="灵敏度补偿 ",
            variable=self.switch_vars[
                "灵敏度补偿"
            ]
        ).grid(
            row=0,
            column=0,
            sticky=tk.W,
            padx=(5, 0),
            pady=1
        )

        ttk.Checkbutton(
            cb_frame,
            text="滤波器编程 ",
            variable=self.switch_vars[
                "滤波器编程"
            ]
        ).grid(
            row=0,
            column=1,
            sticky=tk.W,
            padx=(5, 0),
            pady=1
        )

        ttk.Checkbutton(
            cb_frame,
            text="归一化     ",
            variable=self.switch_vars[
                "归一化"
            ]
        ).grid(
            row=1,
            column=0,
            sticky=tk.W,
            padx=(5, 0),
            pady=1
        )

        ttk.Checkbutton(
            cb_frame,
            text="线性插值   ",
            variable=self.switch_vars[
                "线性插值"
            ]
        ).grid(
            row=1,
            column=1,
            sticky=tk.W,
            padx=(5, 0),
            pady=1
        )

        ttk.Checkbutton(
            cb_frame,
            text="工作点补偿 ",
            variable=self.switch_vars[
                "静态工作点补偿"
            ]
        ).grid(
            row=2,
            column=0,
            columnspan=2,
            sticky=tk.W,
            padx=(5, 0),
            pady=1
        )

        tk.Label(
            switch_frame,
            text="校准模式:",
            bg=GLOBAL_BG
        ).grid(
            row=4,
            column=0,
            padx=2,
            pady=3,
            sticky=tk.E
        )

        self.calib_combo = ttk.Combobox(
            switch_frame,
            values=[
                "不校准",
                "粗校准",
                "细校准"
            ],
            width=12
        )

        self.calib_combo.current(0)

        self.calib_combo.grid(
            row=4,
            column=1,
            padx=2,
            pady=3,
            sticky=tk.W
        )

        prog_lock_frame = tk.Frame(
            switch_frame,
            bg=GLOBAL_BG
        )

        prog_lock_frame.grid(
            row=5,
            column=0,
            columnspan=2,
            pady=(3, 1)
        )

        self.create_btn(
            prog_lock_frame,
            "PS寄存器",
            self.open_ps_panel,
            width=8,
            bg="#D4EDDA"
        ).pack(
            side=tk.LEFT,
            padx=2
        )

        self.create_btn(
            prog_lock_frame,
            "连接检测",
            self.ping_ps,
            width=8,
            bg="#F8D7DA"
        ).pack(
            side=tk.LEFT,
            padx=2
        )

        btn_action_frame = tk.Frame(
            switch_frame,
            bg=GLOBAL_BG
        )

        btn_action_frame.grid(
            row=6,
            column=0,
            columnspan=2,
            pady=(1, 4)
        )

        self.create_btn(
            btn_action_frame,
            "读取状态",
            self.read_sys_status,
            width=8
        ).pack(
            side=tk.LEFT,
            padx=2
        )

        self.create_btn(
            btn_action_frame,
            "确认同步",
            self.sync_all_switches,
            width=8
        ).pack(
            side=tk.LEFT,
            padx=2
        )

        # ========================================================
        # 线性插值区域
        # ========================================================

        coeff_frame = tk.LabelFrame(
            left_top_frame,
            text="线性插值系数",
            padx=5,
            pady=5,
            bg=GLOBAL_BG
        )

        coeff_frame.pack(
            side=tk.LEFT,
            fill=tk.Y
        )

        self.coeff_entries = []

        for i in range(33):

            row = i % 11
            col = i // 11

            angle = (
                i *
                (
                    360.0 /
                    32
                )
            )

            tk.Label(
                coeff_frame,
                text=f"{angle:.2f}°",
                bg=GLOBAL_BG,
                anchor=tk.E
            ).grid(
                row=row,
                column=col * 2,
                padx=2,
                pady=2,
                sticky=tk.E
            )

            entry = tk.Entry(
                coeff_frame,
                width=7,
                bg="white"
            )

            entry.grid(
                row=row,
                column=col * 2 + 1,
                padx=2,
                pady=2
            )

            self.coeff_entries.append(
                entry
            )

        coeff_btn_frame = tk.Frame(
            coeff_frame,
            bg=GLOBAL_BG
        )

        coeff_btn_frame.grid(
            row=11,
            column=0,
            columnspan=6,
            pady=(5, 0)
        )

        self.create_btn(
            coeff_btn_frame,
            "读取",
            self.read_coeff,
            width=6
        ).pack(
            side=tk.LEFT,
            padx=10
        )

        self.create_btn(
            coeff_btn_frame,
            "写入",
            self.write_coeff,
            width=6
        ).pack(
            side=tk.LEFT,
            padx=10
        )

        # ========================================================
        # 中间区域
        # ========================================================

        quad_container = tk.Frame(
            left_panel,
            bg=GLOBAL_BG
        )

        quad_container.pack(
            side=tk.TOP,
            fill=tk.X,
            pady=(5, 0)
        )

        quad_container.columnconfigure(
            0,
            weight=1,
            uniform="quad"
        )

        quad_container.columnconfigure(
            1,
            weight=1,
            uniform="quad"
        )

        # ========================================================
        # 角度调零
        # ========================================================

        zero_frame = tk.LabelFrame(
            quad_container,
            text="角度调零",
            padx=5,
            pady=5,
            bg=GLOBAL_BG
        )

        zero_frame.grid(
            row=0,
            column=0,
            sticky="nsew",
            padx=(0, 2),
            pady=(0, 2)
        )

        zero_inner = tk.Frame(
            zero_frame,
            bg=GLOBAL_BG
        )

        zero_inner.pack(
            expand=True,
            pady=2
        )

        tk.Label(
            zero_inner,
            text="基准点:",
            bg=GLOBAL_BG
        ).pack(
            side=tk.LEFT,
            padx=(0, 5)
        )

        self.zero_entry = tk.Entry(
            zero_inner,
            width=10,
            bg="white",
            justify="center"
        )

        self.zero_entry.pack(
            side=tk.LEFT,
            padx=(0, 10)
        )

        self.zero_entry.insert(
            0,
            "0"
        )

        self.create_btn(
            zero_inner,
            "确认",
            self.write_zero,
            width=6
        ).pack(
            side=tk.LEFT
        )

        # ========================================================
        # 工作点
        # ========================================================

        op_frame = tk.LabelFrame(
            quad_container,
            text="工作点",
            padx=5,
            pady=5,
            bg=GLOBAL_BG
        )

        op_frame.grid(
            row=0,
            column=1,
            sticky="nsew",
            padx=(2, 0),
            pady=(0, 2)
        )

        op_inner = tk.Frame(
            op_frame,
            bg=GLOBAL_BG
        )

        op_inner.pack(
            expand=True
        )

        tk.Label(
            op_inner,
            text="CH1:",
            bg=GLOBAL_BG
        ).grid(
            row=0,
            column=0,
            padx=(0, 2),
            pady=5,
            sticky=tk.E
        )

        self.op_ch1_entry = tk.Entry(
            op_inner,
            width=8,
            bg="#F0F0F0",
            state="readonly",
            justify="center"
        )

        self.op_ch1_entry.grid(
            row=0,
            column=1,
            padx=(0, 10),
            pady=5
        )

        tk.Label(
            op_inner,
            text="CH2:",
            bg=GLOBAL_BG
        ).grid(
            row=0,
            column=2,
            padx=(0, 2),
            pady=5,
            sticky=tk.E
        )

        self.op_ch2_entry = tk.Entry(
            op_inner,
            width=8,
            bg="#F0F0F0",
            state="readonly",
            justify="center"
        )

        self.op_ch2_entry.grid(
            row=0,
            column=3,
            pady=5
        )

        # ========================================================
        # 相位校准
        # ========================================================

        phase_frame = tk.LabelFrame(
            quad_container,
            text="相位校准",
            padx=5,
            pady=5,
            bg=GLOBAL_BG
        )

        phase_frame.grid(
            row=1,
            column=0,
            sticky="nsew",
            padx=(0, 2),
            pady=(2, 2)
        )

        phase_inner = tk.Frame(
            phase_frame,
            bg=GLOBAL_BG
        )

        phase_inner.pack(
            expand=True,
            pady=2
        )

        p_btn_frame = tk.Frame(
            phase_inner,
            bg=GLOBAL_BG
        )

        p_btn_frame.grid(
            row=0,
            column=0,
            rowspan=2,
            padx=(0, 10)
        )

        self.create_btn(
            p_btn_frame,
            "读取",
            self.read_phase,
            width=4
        ).pack(
            pady=2
        )

        self.create_btn(
            p_btn_frame,
            "写入",
            self.write_phase,
            width=4
        ).pack(
            pady=2
        )

        tk.Label(
            phase_inner,
            text="粗调:",
            bg=GLOBAL_BG
        ).grid(
            row=0,
            column=1,
            sticky=tk.E
        )

        self.phase_c1 = tk.Entry(
            phase_inner,
            width=7,
            bg="white",
            justify="center"
        )

        self.phase_c1.grid(
            row=0,
            column=2,
            padx=2,
            pady=2
        )

        self.phase_c2 = tk.Entry(
            phase_inner,
            width=7,
            bg="white",
            justify="center"
        )

        self.phase_c2.grid(
            row=0,
            column=3,
            padx=2,
            pady=2
        )

        tk.Label(
            phase_inner,
            text="细调:",
            bg=GLOBAL_BG
        ).grid(
            row=1,
            column=1,
            sticky=tk.E
        )

        self.phase_f1 = tk.Entry(
            phase_inner,
            width=7,
            bg="white",
            justify="center"
        )

        self.phase_f1.grid(
            row=1,
            column=2,
            padx=2,
            pady=2
        )

        self.phase_f2 = tk.Entry(
            phase_inner,
            width=7,
            bg="white",
            justify="center"
        )

        self.phase_f2.grid(
            row=1,
            column=3,
            padx=2,
            pady=2
        )

        # ========================================================
        # 归一化
        # ========================================================

        norm_frame = tk.LabelFrame(
            quad_container,
            text="归一化极值",
            padx=5,
            pady=5,
            bg=GLOBAL_BG
        )

        norm_frame.grid(
            row=1,
            column=1,
            sticky="nsew",
            padx=(2, 0),
            pady=(2, 2)
        )

        norm_inner = tk.Frame(
            norm_frame,
            bg=GLOBAL_BG
        )

        norm_inner.pack(
            expand=True,
            pady=2
        )

        n_btn_frame = tk.Frame(
            norm_inner,
            bg=GLOBAL_BG
        )

        n_btn_frame.grid(
            row=0,
            column=0,
            rowspan=2,
            padx=(0, 10)
        )

        self.create_btn(
            n_btn_frame,
            "读取",
            self.read_norm,
            width=4
        ).pack(
            pady=2
        )

        self.create_btn(
            n_btn_frame,
            "写入",
            self.write_norm,
            width=4
        ).pack(
            pady=2
        )

        tk.Label(
            norm_inner,
            text="最大:",
            bg=GLOBAL_BG
        ).grid(
            row=0,
            column=1,
            sticky=tk.E
        )

        self.norm_ch1_max = tk.Entry(
            norm_inner,
            width=7,
            bg="white",
            justify="center"
        )

        self.norm_ch1_max.grid(
            row=0,
            column=2,
            padx=2,
            pady=2
        )

        self.norm_ch2_max = tk.Entry(
            norm_inner,
            width=7,
            bg="white",
            justify="center"
        )

        self.norm_ch2_max.grid(
            row=0,
            column=3,
            padx=2,
            pady=2
        )

        tk.Label(
            norm_inner,
            text="最小:",
            bg=GLOBAL_BG
        ).grid(
            row=1,
            column=1,
            sticky=tk.E
        )

        self.norm_ch1_min = tk.Entry(
            norm_inner,
            width=7,
            bg="white",
            justify="center"
        )

        self.norm_ch1_min.grid(
            row=1,
            column=2,
            padx=2,
            pady=2
        )

        self.norm_ch2_min = tk.Entry(
            norm_inner,
            width=7,
            bg="white",
            justify="center"
        )

        self.norm_ch2_min.grid(
            row=1,
            column=3,
            padx=2,
            pady=2
        )

        # ========================================================
        # FIR + DNC
        # ========================================================

        freq_frame = tk.LabelFrame(
            quad_container,
            text="滤波器与DNC降噪",
            padx=5,
            pady=5,
            bg=GLOBAL_BG
        )

        freq_frame.grid(
            row=2,
            column=0,
            columnspan=2,
            sticky="nsew",
            pady=(2, 0)
        )

        freq_inner = tk.Frame(
            freq_frame,
            bg=GLOBAL_BG
        )

        freq_inner.pack(
            expand=True,
            fill=tk.X,
            pady=5
        )

        for i in range(9):

            freq_inner.columnconfigure(
                i,
                weight=1
            )

        tk.Label(
            freq_inner,
            text="FIR档位:",
            bg=GLOBAL_BG
        ).grid(
            row=0,
            column=0,
            sticky=tk.E,
            padx=2
        )

        self.freq_combo = ttk.Combobox(
            freq_inner,
            values=[
                "10 Hz",
                "50 Hz",
                "100 Hz",
                "150 Hz",
                "200 Hz",
                "250 Hz",
                "300 Hz",
                "400 Hz"
            ],
            width=9
        )

        self.freq_combo.current(0)

        self.freq_combo.grid(
            row=0,
            column=1,
            padx=2,
            sticky=tk.W
        )

        self.create_btn(
            freq_inner,
            "确认",
            self.write_sys_reg45,
            width=6
        ).grid(
            row=0,
            column=2,
            sticky=tk.W,
            padx=10
        )

        tk.Label(
            freq_inner,
            text="  |  ",
            bg=GLOBAL_BG,
            fg="gray"
        ).grid(
            row=0,
            column=3
        )

        tk.Label(
            freq_inner,
            text="DNC门限:",
            bg=GLOBAL_BG
        ).grid(
            row=0,
            column=4,
            sticky=tk.E,
            padx=2
        )

        self.dnc_threshold_entry = tk.Entry(
            freq_inner,
            width=8,
            bg="white",
            justify="center"
        )

        self.dnc_threshold_entry.grid(
            row=0,
            column=5,
            padx=2,
            sticky=tk.W
        )

        tk.Label(
            freq_inner,
            text="DNC强度:",
            bg=GLOBAL_BG
        ).grid(
            row=0,
            column=6,
            sticky=tk.E,
            padx=2
        )

        self.dnc_alpha_entry = tk.Entry(
            freq_inner,
            width=8,
            bg="white",
            justify="center"
        )

        self.dnc_alpha_entry.grid(
            row=0,
            column=7,
            padx=2,
            sticky=tk.W
        )

        dnc_btn_frame = tk.Frame(
            freq_inner,
            bg=GLOBAL_BG
        )

        dnc_btn_frame.grid(
            row=0,
            column=8,
            padx=10,
            sticky=tk.W
        )

        self.create_btn(
            dnc_btn_frame,
            "读",
            self.read_dnc,
            width=4
        ).pack(
            side=tk.LEFT,
            padx=2
        )

        self.create_btn(
            dnc_btn_frame,
            "写",
            self.write_dnc,
            width=4
        ).pack(
            side=tk.LEFT,
            padx=2
        )

        # ========================================================
        # 右侧绘图
        # ========================================================

        right_panel = tk.Frame(
            top_section,
            bg=GLOBAL_BG
        )

        right_panel.pack(
            side=tk.LEFT,
            fill=tk.BOTH,
            expand=True
        )

        top_right_panel = tk.Frame(
            right_panel,
            bg=GLOBAL_BG
        )

        top_right_panel.pack(
            side=tk.TOP,
            fill=tk.X,
            pady=(0, 5)
        )

        mode_frame = tk.Frame(
            top_right_panel,
            bg=GLOBAL_BG
        )

        mode_frame.pack(
            side=tk.LEFT,
            fill=tk.Y,
            pady=5
        )

        ttk.Radiobutton(
            mode_frame,
            text="双路波形模式   ",
            variable=self.mode_var,
            value=1
        ).pack(
            side=tk.LEFT,
            padx=2
        )

        ttk.Radiobutton(
            mode_frame,
            text="角度输出模式   ",
            variable=self.mode_var,
            value=2
        ).pack(
            side=tk.LEFT,
            padx=2
        )

        self.btn_start = self.create_btn(
            mode_frame,
            "▶ 开始连续采集",
            self.start_collection,
            width=14,
            bg="#D4EDDA"
        )

        self.btn_start.config(
            state=tk.DISABLED
        )

        self.btn_start.pack(
            side=tk.LEFT,
            padx=5
        )

        self.btn_stop = self.create_btn(
            mode_frame,
            "⏹ 结束采样",
            self.stop_collection,
            width=16,
            bg="#F8D7DA"
        )

        self.btn_stop.config(
            state=tk.DISABLED
        )

        self.btn_stop.pack(
            side=tk.LEFT,
            padx=5
        )

        source_bar = tk.Frame(right_panel, bg=GLOBAL_BG)
        source_bar.pack(side=tk.TOP, fill=tk.X, pady=(0, 4))
        tk.Label(source_bar, text='双路采集点:').pack(side=tk.LEFT)
        self.source_combo = ttk.Combobox(source_bar, values=list(SOURCES), state='readonly', width=18)
        self.source_combo.current(0)
        self.source_combo.pack(side=tk.LEFT, padx=3)
        self.create_btn(source_bar, '检查数据链', self.diagnose_chain, width=12).pack(side=tk.LEFT,padx=3)

        target_bar=tk.Frame(right_panel,bg=GLOBAL_BG)
        target_bar.pack(side=tk.TOP,fill=tk.X,pady=2)
        self.phase_status=tk.StringVar(value='相位: —')
        tk.Label(target_bar,textvariable=self.phase_status,anchor='w').pack(side=tk.LEFT,padx=5)
        self.ps_summary=tk.StringVar(value='PS统计: —')
        tk.Label(right_panel,textvariable=self.ps_summary,anchor='w').pack(side=tk.TOP,fill=tk.X,pady=2)

        self.linearity_status=tk.StringVar(value='线性度: —')
        tk.Label(right_panel,textvariable=self.linearity_status,anchor='w').pack(side=tk.TOP,fill=tk.X,pady=2)

        logo_frame = tk.Frame(
            top_right_panel,
            bg=GLOBAL_BG
        )

        logo_frame.pack(
            side=tk.RIGHT,
            fill=tk.Y
        )

        try:

            img = Image.open(
                resource_path(
                    "logo.png"
                )
            )

            img = img.resize(
                (309, 82),
                Image.Resampling.LANCZOS
            )

            self.logo_photo = (
                ImageTk.PhotoImage(
                    img
                )
            )

            tk.Label(
                logo_frame,
                image=self.logo_photo,
                bg=GLOBAL_BG
            ).pack(
                padx=5,
                pady=0
            )

        except Exception:

            tk.Label(
                logo_frame,
                text="             ",
                font=(
                    "Arial",
                    18,
                    "bold"
                ),
                fg="#003366",
                bg=GLOBAL_BG
            ).pack(
                padx=25,
                pady=12
            )

        graph_frame = tk.LabelFrame(
            right_panel,
            text="波形窗口",
            bg=GLOBAL_BG
        )

        graph_frame.pack(
            side=tk.BOTTOM,
            fill=tk.BOTH,
            expand=True
        )

        self.fig = Figure(
            figsize=(6, 2.6),
            dpi=100
        )

        self.fig.patch.set_facecolor(
            "white"
        )

        self.ax = self.fig.add_subplot(
            111
        )

        self.canvas = FigureCanvasTkAgg(
            self.fig,
            master=graph_frame
        )

        self.canvas.get_tk_widget().pack(
            fill=tk.BOTH,
            expand=True,
            padx=5,
            pady=5
        )

        # ========================================================
        # 温度补偿
        # ========================================================

        bot_frame = tk.LabelFrame(
            bottom_container,
            text="温度与静态工作点补偿",
            padx=5,
            pady=5,
            bg=GLOBAL_BG
        )

        bot_frame.pack(
            side=tk.LEFT,
            fill=tk.Y
        )

        btn_frame3 = tk.Frame(
            bot_frame,
            bg=GLOBAL_BG
        )

        btn_frame3.pack(
            side=tk.LEFT,
            padx=10
        )

        self.create_btn(
            btn_frame3,
            "读取",
            self.read_temp_comp,
            width=8
        ).pack(
            pady=5
        )

        self.create_btn(
            btn_frame3,
            "写入",
            self.write_temp_comp,
            width=8
        ).pack(
            pady=5
        )

        temp_entry_frame = tk.Frame(
            bot_frame,
            bg=GLOBAL_BG
        )

        temp_entry_frame.pack(
            side=tk.LEFT,
            fill=tk.X,
            padx=5
        )

        tk.Label(
            temp_entry_frame,
            text="温度点",
            bg=GLOBAL_BG
        ).grid(
            row=0,
            column=0,
            padx=2,
            sticky=tk.E
        )

        tk.Label(
            temp_entry_frame,
            text="CH1灵敏度",
            bg=GLOBAL_BG
        ).grid(
            row=1,
            column=0,
            padx=2,
            sticky=tk.E
        )

        tk.Label(
            temp_entry_frame,
            text="CH2灵敏度",
            bg=GLOBAL_BG
        ).grid(
            row=2,
            column=0,
            padx=2,
            sticky=tk.E
        )

        tk.Label(
            temp_entry_frame,
            text="CH1偏移",
            bg=GLOBAL_BG
        ).grid(
            row=3,
            column=0,
            padx=2,
            sticky=tk.E
        )

        tk.Label(
            temp_entry_frame,
            text="CH2偏移",
            bg=GLOBAL_BG
        ).grid(
            row=4,
            column=0,
            padx=2,
            sticky=tk.E
        )

        self.temp_entries_top = []
        self.temp_entries_bot = []
        self.temp_entries_ch2_sens = []

        self.offset1_entries = []
        self.offset2_entries = []

        for col in range(9):

            e_top = tk.Entry(
                temp_entry_frame,
                width=7,
                bg="white"
            )

            e_top.grid(
                row=0,
                column=col + 1,
                padx=2,
                pady=2
            )

            self.temp_entries_top.append(
                e_top
            )

            e_bot = tk.Entry(
                temp_entry_frame,
                width=7,
                bg="white"
            )

            e_bot.grid(
                row=1,
                column=col + 1,
                padx=2,
                pady=2
            )

            self.temp_entries_bot.append(
                e_bot
            )

            e_ch2_sens = tk.Entry(
                temp_entry_frame,
                width=7,
                bg="white"
            )

            e_ch2_sens.grid(
                row=2,
                column=col + 1,
                padx=2,
                pady=2
            )

            self.temp_entries_ch2_sens.append(
                e_ch2_sens
            )

            e_of1 = tk.Entry(
                temp_entry_frame,
                width=7,
                bg="white"
            )

            e_of1.grid(
                row=3,
                column=col + 1,
                padx=2,
                pady=2
            )

            self.offset1_entries.append(
                e_of1
            )

            e_of2 = tk.Entry(
                temp_entry_frame,
                width=7,
                bg="white"
            )

            e_of2.grid(
                row=4,
                column=col + 1,
                padx=2,
                pady=2
            )

            self.offset2_entries.append(
                e_of2
            )

        # ========================================================
        # 输出接口
        # ========================================================

        out_frame = tk.LabelFrame(
            bottom_container,
            text="Hall 输出接口",
            padx=5,
            pady=5,
            bg=GLOBAL_BG
        )

        out_frame.pack(
            side=tk.LEFT,
            fill=tk.BOTH,
            expand=True,
            padx=(10, 5)
        )

        out_inner = tk.Frame(
            out_frame,
            bg=GLOBAL_BG
        )

        out_inner.pack(
            expand=True,
            pady=2
        )

        tk.Label(
            out_inner,
            text="输出模式:",
            bg=GLOBAL_BG
        ).grid(
            row=0,
            column=0,
            padx=5,
            pady=3,
            sticky=tk.E
        )

        self.out_mode_combo = (
            ttk.Combobox(
                out_inner,
                values=HALL_MODES,
                width=12
            )
        )

        self.out_mode_combo.current(0)
        self.out_mode_combo.bind('<<ComboboxSelected>>', self.update_hall_controls)

        self.out_mode_combo.grid(
            row=0,
            column=1,
            padx=5,
            pady=3,
            sticky=tk.W
        )

        tk.Label(
            out_inner,
            text="PWM频率:",
            bg=GLOBAL_BG
        ).grid(
            row=1,
            column=0,
            padx=5,
            pady=3,
            sticky=tk.E
        )

        self.out_pwm_combo = (
            ttk.Combobox(
                out_inner,
                values=[
                    "50Hz",
                    "500Hz",
                    "2000Hz",
                    "4000Hz"
                ],
                width=12
            )
        )

        self.out_pwm_combo.current(0)

        self.out_pwm_combo.grid(
            row=1,
            column=1,
            padx=5,
            pady=3,
            sticky=tk.W
        )

        self.create_btn(
            out_inner,
            "写入输出设置",
            self.write_hall_config,
            width=10
        ).grid(
            row=2,
            column=0,
            columnspan=2,
            pady=(5, 2)
        )

        self.create_btn(out_inner, "读取输出设置", self.read_hall_config,
                        width=12).grid(row=3, column=0, columnspan=2, pady=3)

        self.hall_pin_status = tk.StringVar(value=HALL_PIN_TEXT[0])
        tk.Label(out_inner, textvariable=self.hall_pin_status,
                 font=('Microsoft YaHei', 9)).grid(
                     row=4, column=0, columnspan=2, padx=3, pady=(2, 0))

        realtime_temp_frame = (
            tk.LabelFrame(
                bottom_container,
                text="TEMPIN 输入温度码",
                padx=5,
                pady=5,
                bg=GLOBAL_BG
            )
        )

        realtime_temp_frame.pack(
            side=tk.LEFT,
            fill=tk.BOTH,
            expand=True,
            padx=(5, 5)
        )

        temp_inner = tk.Frame(
            realtime_temp_frame,
            bg=GLOBAL_BG
        )

        temp_inner.pack(
            expand=True,
            pady=2
        )

        tk.Label(
            temp_inner,
            text="当前值:",
            bg=GLOBAL_BG
        ).grid(
            row=0,
            column=0,
            padx=5,
            pady=3,
            sticky=tk.E
        )

        self.temp_val_entry = tk.Entry(
            temp_inner,
            width=10,
            bg="white",
            font=GLOBAL_FONT,
            justify="center"
        )

        self.temp_val_entry.grid(
            row=0,
            column=1,
            padx=5,
            pady=3,
            sticky=tk.W
        )

        self.create_btn(
            temp_inner,
            "读取",
            self.read_realtime_temp,
            width=10
        ).grid(
            row=1,
            column=0,
            columnspan=2,
            pady=(5, 2)
        )

        # ========================================================
        # 日志
        # ========================================================

        result_frame = tk.LabelFrame(
            bottom_container,
            text="系统日志",
            padx=5,
            pady=5,
            bg=GLOBAL_BG
        )

        result_frame.pack(
            side=tk.LEFT,
            fill=tk.BOTH,
            expand=True
        )

        scrollbar = tk.Scrollbar(
            result_frame
        )

        scrollbar.pack(
            side=tk.RIGHT,
            fill=tk.Y
        )

        self.result_text = tk.Text(
            result_frame,
            height=5,
            width=40,
            bg="white",
            font=GLOBAL_FONT,
            yscrollcommand=scrollbar.set
        )

        self.result_text.pack(
            side=tk.LEFT,
            fill=tk.BOTH,
            expand=True
        )

        scrollbar.config(
            command=self.result_text.yview
        )

        self.log("就绪。请选择串口连接。")


    # ============================================================
    # 实时温度
    # ============================================================

    def read_realtime_temp(self):
        value = self.link.read(0x00C)
        self.set_entry(self.temp_val_entry, value & 0x3FF)
        self.log(f'TEMPIN={value & 0x3FF}')



    # ============================================================
    # 编程锁
    # ============================================================







    # ============================================================
    # PS寄存器访问
    # ============================================================







    # ============================================================
    # 日志
    # ============================================================

    def log(self, msg):

        self.result_text.insert(
            tk.END,
            msg + "\n"
        )

        self.result_text.see(
            tk.END
        )


    # ============================================================
    # Register基本读写
    # ============================================================

    def write_byte(self, addr, data):
        self.check_target()
        if not 0 <= data <= 255:
            raise ValueError('字节值必须在0..255')
        offset, shift = BYTE_MAP[addr]
        self.link.modify(offset, 255 << shift, data << shift)
        return True



    def read_byte(self, addr):
        self.check_target()
        offset, shift = BYTE_MAP[addr]
        return (self.link.read(offset) >> shift) & 255



    # ============================================================
    # 普通16bit写入
    # ============================================================

    def write_16bit(self, addr, val_str, name=''):
        self.check_target()
        value = int(str(val_str).strip() or '0')
        offset=WORD_MAP[addr]
        if offset in (0x024,0x02C):
            lo,hi,mask=-32768,32767,0xFFFF
        elif offset in (0x014,0x018,0x01C,0x020):
            lo,hi,mask=0,16383,0x3FFF
        elif 0x040 <= offset <= 0x0E0:
            lo,hi,mask=0,1023,0x3FF
        else:
            lo,hi,mask=0,65535,0xFFFF
        if not lo <= value <= hi:
            raise ValueError(f'{name}: RTL有效范围 {lo}..{hi}，输入={value}')
        self.link.modify(offset,mask,value & mask)
        self.log(f'-> {name}: {value}，写入并读回通过')
        return True



    # ============================================================
    # signed 14-bit 工作点偏移写入
    #
    # 范围：
    # -8192 ~ +8191
    #
    # 示例：
    #
    # -8  -> 0x3FF8
    # -73 -> 0x3FB7
    # ============================================================

    def write_signed14(self, addr, val_str, name=''):
        self.check_target()
        value = int(str(val_str).strip() or '0')
        if not -8192 <= value <= 8191:
            raise ValueError(f'{name}: 允许范围 -8192..8191')
        self.link.modify(WORD_MAP[addr], 0x3FFF, value & 0x3FFF)
        self.log(f'-> {name}: {value}，写入并读回验证通过')
        return True



    # ============================================================
    # signed 14-bit 工作点偏移读取
    # ============================================================

    def read_signed14(self, addr, entry_widget, name=''):
        self.check_target()
        value = self.link.read(WORD_MAP[addr]) & 0x3FFF
        if value & 0x2000:
            value -= 16384
        self.set_entry(entry_widget, value)
        self.log(f'<- {name}: {value}')
        return value



    # ============================================================
    # 普通16bit读取
    # ============================================================

    def read_16bit(self, addr, entry_widget, name='', is_signed=False):
        self.check_target()
        value = self.link.read(WORD_MAP[addr]) & 0xFFFF
        if is_signed and value & 0x8000:
            value -= 65536
        self.set_entry(entry_widget, value)
        self.log(f'<- {name}: {value}')
        return value



    # ============================================================
    # 灵敏度
    # ============================================================

    def sensitivity_to_code(
        self,
        val_str,
        name=""
    ):

        gain = (
            float(val_str)
            if (
                val_str and
                val_str.strip()
            )
            else 0.0
        )

        code = int(
            gain * 256 +
            0.5
        )

        if (
            gain < 0 or
            code > 0x03FF
        ):

            raise ValueError(
                f"{name} "
                f"输入超出范围："
                f"{gain:g}\n"
                "允许范围为 "
                "0～3.99609375"
                "（10bit 无符号 Q8）"
            )

        return code


    def read_sensitivity(self, addr, entry_widget, name=''):
        self.check_target()
        value = self.link.read(WORD_MAP[addr]) & 0x3FF
        self.set_entry(entry_widget, f'{value / 256.0:.6f}')
        self.log(f'<- {name}: Q8={value}')
        return value / 256.0



    # ============================================================
    # ZERO
    # ============================================================

    def write_zero(self):

        self.log(
            "--- 开始下发调零基准 ---"
        )

        self.write_16bit(
            121,
            self.zero_entry.get(),
            "调零基准"
        )


    # ============================================================
    # DNC
    # ============================================================

    def write_dnc(self):
        self.check_target()
        th = int(self.dnc_threshold_entry.get())
        al = int(self.dnc_alpha_entry.get())
        if not (0 <= th <= 255 and 0 <= al <= 255):
            raise ValueError('DNC threshold/alpha必须在0..255')
        self.link.modify(0x010, 0xFFFF, th | (al << 8))
        self.log('DNC写入并读回验证通过')



    def read_dnc(self):
        value = self.link.read(0x010)
        self.set_entry(self.dnc_threshold_entry, value & 255)
        self.set_entry(self.dnc_alpha_entry, (value >> 8) & 255)



    # ============================================================
    # CLK_CTRL
    # ============================================================







    # ============================================================
    # 系统寄存器
    # ============================================================

    def read_sys_status(self):
        value = self.link.read(0)
        self.freq_combo.current((value >> 9) & 7)
        for name, bit in [('滤波器编程',8), ('灵敏度补偿',2), ('归一化',3),
                          ('静态工作点补偿',1), ('线性插值',6)]:
            self.switch_vars[name].set(bool(value & (1 << bit)))
        self.calib_combo.current({0:0,1:1,3:2}.get((value >> 4) & 3,0))
        if value & 0x30 == 0x20:self.log('硬件处于不支持的仅细调模式，请重新选择并确认同步')
        self.log(f'CONTROL=0x{value:08X}, DNC使能={(value >> 7) & 1}')



    def sync_all_switches(self):
        self.write_sys_reg45()
        self.write_output_reg120()
        self.log('已同步已映射的系统开关；DNC及保留位保持原值')



    def write_sys_reg45(self):
        self.check_target()
        freq = self.freq_combo.current()
        mode = self.calib_combo.current()
        if not 0 <= freq <= 7 or not 0 <= mode <= 2:
            raise ValueError('请选择有效频率/校准模式')
        value = (freq << 9) | (int(self.switch_vars['滤波器编程'].get()) << 8)
        value |= int(self.switch_vars['灵敏度补偿'].get()) << 2
        value |= int(self.switch_vars['归一化'].get()) << 3
        value |= (0, 0x10, 0x30)[mode]
        self.link.modify(0, 0xF3C, value)
        self.log('CONTROL配置已写入并读回')



    def write_output_reg120(self):
        self.check_target()
        value = (int(self.switch_vars['线性插值'].get()) << 6)
        value |= int(self.switch_vars['静态工作点补偿'].get()) << 1
        self.link.modify(0, 0x42, value)
        self.log('线性化与工作点补偿设置已写入')



    # ============================================================
    # 线性插值
    # ============================================================

    def write_coeff(self):

        self.log(
            "--- 开始下发插值系数 ---"
        )

        for i, entry in enumerate(
            self.coeff_entries
        ):

            self.write_16bit(
                54 + i * 2,
                entry.get(),
                f"P{i + 1}"
            )


    def read_coeff(self):

        self.log(
            "--- 开始读取插值系数 ---"
        )

        for i, entry in enumerate(
            self.coeff_entries
        ):

            self.read_16bit(
                54 + i * 2,
                entry,
                f"P{i + 1}"
            )


    # ============================================================
    # 相位
    # ============================================================

    def write_phase(self):

        self.log(
            "--- 开始下发相位校准参数 ---"
        )

        self.write_16bit(
            37,
            self.phase_c1.get(),
            "粗调1"
        )

        self.write_16bit(
            39,
            self.phase_f1.get(),
            "细调1"
        )

        self.write_16bit(
            41,
            self.phase_c2.get(),
            "粗调2"
        )

        self.write_16bit(
            43,
            self.phase_f2.get(),
            "细调2"
        )


    def read_phase(self):
        for addr,entry,name,signed in [(37,self.phase_c1,'粗调K',True),
            (41,self.phase_c2,'粗调Gain',False),(39,self.phase_f1,'细调K',True),
            (43,self.phase_f2,'细调Gain',False)]:
            self.read_16bit(addr,entry,name,is_signed=signed)


    # ============================================================
    # 归一化
    # ============================================================

    def write_norm(self):

        self.log(
            "--- 开始下发归一化极值 ---"
        )

        self.write_16bit(
            46,
            self.norm_ch1_max.get(),
            "Ch1最大值"
        )

        self.write_16bit(
            48,
            self.norm_ch1_min.get(),
            "Ch1最小值"
        )

        self.write_16bit(
            50,
            self.norm_ch2_max.get(),
            "Ch2最大值"
        )

        self.write_16bit(
            52,
            self.norm_ch2_min.get(),
            "Ch2最小值"
        )

        self.refresh_norm_result()


    def read_norm(self):

        self.log(
            "--- 开始读取归一化极值 ---"
        )

        self.read_16bit(
            46,
            self.norm_ch1_max,
            "Ch1最大值"
        )

        self.read_16bit(
            48,
            self.norm_ch1_min,
            "Ch1最小值"
        )

        self.read_16bit(
            50,
            self.norm_ch2_max,
            "Ch2最大值"
        )

        self.read_16bit(
            52,
            self.norm_ch2_min,
            "Ch2最小值"
        )

        self.refresh_norm_result()


    # ============================================================
    # 温度与工作点补偿写入
    #
    # 重点：
    #
    # GUI CH1偏移
    #     -> 硬件 offset2
    #     -> 地址146~163
    #
    # GUI CH2偏移
    #     -> 硬件 offset1
    #     -> 地址128~145
    #
    # offset使用signed 14bit
    # ============================================================

    def write_temp_comp(self):

        self.log(
            "--- 开始下发温度与静态工作点补偿参数 ---"
        )

        try:

            ch1_sens_codes = [

                self.sensitivity_to_code(
                    self.temp_entries_bot[i].get(),
                    f"CH1灵敏度{i}"
                )

                for i in range(9)
            ]

            ch2_sens_codes = [

                self.sensitivity_to_code(
                    self.temp_entries_ch2_sens[i].get(),
                    f"CH2灵敏度{i}"
                )

                for i in range(9)
            ]

        except (
            ValueError,
            OverflowError
        ) as e:

            self.log(
                f"[错误] 灵敏度输入无效: {e}"
            )

            messagebox.showerror(
                "灵敏度输入错误",
                str(e)
            )

            return

        for i in range(9):

            # 温度节点
            if not self.write_16bit(
                19 + i * 2,
                self.temp_entries_top[i].get(),
                f"temp{i}"
            ):
                return

            # CH1灵敏度
            if not self.write_16bit(
                1 + i * 2,
                str(ch1_sens_codes[i]),
                f"CH1灵敏度{i}"
            ):
                return

            # ====================================================
            # CH1工作点
            #
            # GUI CH1 -> RTL CH1 offset1
            # 地址146开始
            # ====================================================

            if not self.write_signed14(
                146 + i * 2,
                self.offset1_entries[i].get(),
                f"CH1偏移{i}"
            ):
                return

            # ====================================================
            # CH2工作点
            #
            # GUI CH2 -> RTL CH2 offset2
            # 地址128开始
            # ====================================================

            if not self.write_signed14(
                128 + i * 2,
                self.offset2_entries[i].get(),
                f"CH2偏移{i}"
            ):
                return

            # CH2灵敏度
            if not self.write_16bit(
                164 + i * 2,
                str(ch2_sens_codes[i]),
                f"CH2灵敏度{i}"
            ):
                return

        self.log('温度与工作点补偿参数写入完成')


    # ============================================================
    # 温度与工作点补偿读取
    #
    # 必须和write_temp_comp保持相同映射
    # ============================================================

    def read_temp_comp(self):

        self.log(
            "--- 开始读取温度与静态工作点补偿参数 ---"
        )

        for i in range(9):

            # 温度点
            self.read_16bit(
                19 + i * 2,
                self.temp_entries_top[i],
                f"temp{i}"
            )

            # CH1灵敏度
            self.read_sensitivity(
                1 + i * 2,
                self.temp_entries_bot[i],
                f"CH1灵敏度{i}"
            )

            # ====================================================
            # GUI CH1 <- RTL CH1 offset1
            # ====================================================

            self.read_signed14(
                146 + i * 2,
                self.offset1_entries[i],
                f"CH1偏移{i}"
            )

            # ====================================================
            # GUI CH2 <- RTL CH2 offset2
            # ====================================================

            self.read_signed14(
                128 + i * 2,
                self.offset2_entries[i],
                f"CH2偏移{i}"
            )

            # CH2灵敏度
            self.read_sensitivity(
                164 + i * 2,
                self.temp_entries_ch2_sens[i],
                f"CH2灵敏度{i}"
            )

        self.log(
            "[完成] "
            "温度与工作点补偿参数读取完成。"
        )


    # ============================================================
    # 串口
    # ============================================================

    def refresh_ports(self):

        try:

            current_selected = (
                self.port_combo.get()
            )

            ports = [

                port.device

                for port in
                serial.tools.list_ports.comports()
            ]

            self.port_combo[
                "values"
            ] = ports

            if ports:

                if current_selected in ports:

                    self.port_combo.set(
                        current_selected
                    )

                else:

                    self.port_combo.current(
                        0
                    )

            else:

                self.port_combo.set(
                    ""
                )

        except Exception:
            pass


    def toggle_serial(self):
        if self.is_collecting or self.collection_pending:
            self.switch_vars['串口'].set(True)
            raise RuntimeError('请先停止采集，等待处理结束后再断开串口')
        if self.switch_vars['串口'].get():
            try:
                self.serial_port = serial.Serial(self.port_combo.get(), UART_BAUD,
                    timeout=0.1, write_timeout=1, bytesize=8, parity='N', stopbits=1)
                self.link = AsciiLink(self.serial_port)
                self.link.hello()
                self.read_hall_config()
                self.btn_start.config(state=tk.NORMAL)
                self.log(f'{self.port_combo.get()} 已连接，{UART_BAUD} baud，8N1')
            except Exception:
                if self.serial_port:
                    self.serial_port.close()
                self.switch_vars['串口'].set(False)
                raise
        else:
            if self.serial_port:
                self.serial_port.close()
            self.btn_start.config(state=tk.DISABLED)
            self.btn_stop.config(state=tk.DISABLED)
            self.log('串口已关闭')



    # ============================================================
    # 数据采集
    # ============================================================

    def start_collection(self):
        if self.is_collecting or self.collection_pending:
            return
        if not self.serial_port or not self.serial_port.is_open:
            raise RuntimeError('请先连接PS串口')
        self.linearity_status.set("线性度: —")
        self.last_ps_stats=None
        self.ps_summary.set('PS统计: 采集中')
        self.collect_mode = self.mode_var.get()
        self.collect_name = self.source_combo.get() if self.collect_mode == 1 else '最终角度 0x32C'
        self.collect_offset = SOURCES[self.collect_name] if self.collect_mode == 1 else 0x32C
        if self.collect_mode == 2:
            self.phase_status.set('相位: —')
            self.linearity_status.set('线性度: 采集中')
        else:
            self.phase_status.set('相位: 采集中')
        control = self.link.read(0)
        self.log(f'开始采集 {self.collect_name}；CONTROL=0x{control:08X}')
        self.link.begin_capture(self.collect_offset)
        self.is_collecting = True
        self.collection_pending = True
        self.btn_start.config(state=tk.DISABLED)
        self.btn_stop.config(state=tk.NORMAL)
        self.ch1_dec, self.ch2_dec, self.angle_data = [], [], []
        self.ax.clear()
        self.canvas.draw_idle()
        self.log('采样结束后更新统计结果。')
        self.worker = threading.Thread(target=self.collection_task, daemon=True)
        self.worker.start()



    def stop_collection(self):

        if self.is_collecting:

            self.is_collecting = False
            if self.collect_mode == 2:
                self.linearity_status.set('线性度: 计算中')

            self.btn_stop.config(
                state=tk.DISABLED
            )

            self.log('正在停止采集...')


    def collection_task(self):
        mode=self.collect_mode
        last_plot=last_stats=time.monotonic()
        success=False
        try:
            while self.is_collecting and self.link.sample_count<self.link.max_samples:
                value=self.link.capture_sample()
                if mode==1:
                    x,y=decode_pair(self.collect_offset,value)
                    self.events.put(('sample',mode,(x,y)))
                else:
                    self.events.put(('sample',mode,value & 65535))
                now=time.monotonic()
                if now-last_plot>=0.1:
                    self.events.put(('plot',mode));last_plot=now
                if mode==1 and now-last_stats>=1.0:
                    self.events.put(('stats',self.link.capture_stats(),False));last_stats=now
                time.sleep(0.01)
            self.events.put(('stats',self.link.capture_stats(final=True),True))
            success=True
            if self.link.sample_count>=self.link.max_samples:
                self.events.put(('notice','已达到PS本次样本上限，自动停止并回填统计结果'))
        except Exception as exc:
            self.events.put(('error',str(exc)))
        finally:
            # Interrupted sessions are discarded at the next connection handshake.
            self.is_collecting=False
            self.events.put(('done',mode))
            if not success:self.events.put(('notice','本次采集未完整结束，未自动回填参数；请检查连接后重新采集'))



    # ============================================================
    # 实时绘图
    # ============================================================

    def realtime_plot(
        self,
        mode
    ):

        if not self.is_collecting:
            return

        self.ax.clear()
        if mode == 1:

            if len(self.ch1_dec) > 0:

                self.ax.plot(
                    self.ch1_dec,
                    "b-",
                    label=pair_labels(self.collect_offset)[0],
                    linewidth=0.5
                )

                self.ax.plot(
                    self.ch2_dec,
                    "m-",
                    label=pair_labels(self.collect_offset)[1],
                    linewidth=0.5
                )

                self.ax.set_title(
                    f"{self.collect_name} "
                    f"(实时采集中... "
                    f"{len(self.ch1_dec)} 点)"
                )

                self.ax.legend()

        else:

            if len(self.angle_data) > 0:

                scaled_angle = [

                    val /
                    100.0

                    for val in
                    self.angle_data
                ]

                self.ax.plot(
                    scaled_angle,
                    "b-",
                    label="角度输出",
                    linewidth=0.5
                )

                self.ax.set_title(
                    f"角度输出波形 "
                    f"(实时采集中... "
                    f"{len(self.angle_data)} 点)"
                )

                self.ax.set_ylim(
                    -10,
                    370
                )

                self.ax.set_yticks(
                    np.arange(
                        0,
                        361,
                        45
                    )
                )

                self.ax.set_yticklabels(
                    [
                        f"{int(y)}°"

                        for y in
                        np.arange(
                            0,
                            361,
                            45
                        )
                    ]
                )

                self.ax.legend()

        self.ax.grid(
            True
        )

        self.canvas.draw_idle()


    # ============================================================
    # UI恢复
    # ============================================================

    def reset_ui(self):
        connected = self.serial_port and self.serial_port.is_open
        self.btn_start.config(state=tk.NORMAL if connected else tk.DISABLED)
        self.btn_stop.config(state=tk.DISABLED)



    def read_hall_config(self):
        self.check_target()
        self.apply_hall_config(self.link.hall_config())

    def write_hall_config(self):
        self.check_target()
        mode, freq = self.out_mode_combo.current(), self.out_pwm_combo.current()
        encode_hall_control(mode, freq)
        self.apply_hall_config(self.link.hall_config(mode, freq))

    def apply_hall_config(self, value):
        mode, freq = decode_hall_control(value)
        self.out_mode_combo.current(mode)
        self.out_pwm_combo.current(freq)
        self.update_hall_controls()
        frequency = f'，{HALL_PWM_FREQUENCIES[freq]} Hz' if mode == 0 else ''
        self.log(f'Hall 输出：{HALL_MODES[mode]}{frequency}，HALL_CTRL=0x{value:08X}')

    def update_hall_controls(self, event=None):
        mode = self.out_mode_combo.current()
        self.out_pwm_combo.configure(state='readonly' if mode == 0 else 'disabled')
        self.hall_pin_status.set(HALL_PIN_TEXT[mode] if mode in range(4) else '')



    def check_target(self):
        if self.target_var.get() != '编程寄存器':
            raise RuntimeError('请选择编程寄存器')
        if self.link is None:
            raise RuntimeError('请先连接PS串口')

    @staticmethod
    def set_entry(widget, value):
        widget.delete(0, tk.END)
        widget.insert(0, str(value))

    def configure_ps_ui(self):
        self.master.title('霍尔角度传感器监控与配置')
        self.target_combo.configure(values=['编程寄存器'], state='readonly')
        self.target_var.set('编程寄存器')
        self.out_mode_combo.configure(state='readonly')
        self.update_hall_controls()
        self.calib_combo.configure(values=['不校准','粗校准','粗加细校准'],state='readonly')
        self.freq_combo.configure(state='readonly')
        # PS-specific controls without moving existing widgets.
        menu = tk.Menu(self.master)
        ps = tk.Menu(menu, tearoff=False)
        ps.add_command(label='PS寄存器 / TEMPIN / 状态', command=self.open_ps_panel)
        ps.add_command(label='查看最近PS统计结果', command=self.show_ps_stats)
        menu.add_cascade(label='Zynq PS', menu=ps)
        self.master.config(menu=menu)

    def report_error(self, exc_type, exc, tb):
        self.log(f'[错误] {exc}')
        if self.serial_port and not self.serial_port.is_open:
            self.switch_vars['串口'].set(False)
            self.reset_ui()
        messagebox.showerror('操作未完成', str(exc), parent=self.master)

    def ping_ps(self):
        if self.link is None:
            raise RuntimeError('请先连接串口')
        f=self.link.request('hello')
        self.link.validate(len(f)==5 and f[:4]==['OK','HELLO','6','0x43C00000'])
        self.log('PS通信正常')

    def drain_events(self):
        if self.closing:
            return
        for _ in range(500):
            try:
                event = self.events.get_nowait()
            except queue.Empty:
                break
            kind = event[0]
            if kind == 'sample':
                if event[1] == 1:
                    x,y = event[2]
                    self.ch1_dec.append(x)
                    self.ch2_dec.append(y)
                else:
                    self.angle_data.append(event[2])
            elif kind == 'plot':
                self.realtime_plot(event[1])
            elif kind == 'stats':
                self.apply_ps_stats(event[1],event[2])
            elif kind == 'notice':
                self.log(event[1])
            elif kind == 'error':
                self.log('[采集错误] '+event[1])
                self.phase_status.set('相位: 采集失败')
                self.linearity_status.set('线性度: 采集失败')
            elif kind == 'done':
                self.collection_pending = False
                self.ax.clear()
                if event[1] == 1:
                    self.ax.plot(self.ch1_dec, label=pair_labels(self.collect_offset)[0])
                    self.ax.plot(self.ch2_dec, label=pair_labels(self.collect_offset)[1])
                    self.ax.legend()
                    self.ax.set_title(self.collect_name + '（PC轮询）')
                    if self.ch1_dec and max(self.ch1_dec)==min(self.ch1_dec) and max(self.ch2_dec)==min(self.ch2_dec):
                        self.log('两路均为常数：检查CIC输入、data_vaild、时钟、复位以及监视点连线。')
                elif self.angle_data:
                    self.ax.plot([v/100.0 for v in self.angle_data],label='最终角度 °')
                    self.ax.legend()
                self.canvas.draw_idle()
                if self.serial_port and not self.serial_port.is_open:
                    self.switch_vars['串口'].set(False)
                self.reset_ui()
                self.log('采集结束。')
        self.master.after(30, self.drain_events)

    def show_ps_stats(self):
        if self.last_ps_stats is None:
            raise RuntimeError('请先采集波形并正常停止，PS会自动返回计算结果')
        self.log('最近一次PS统计：'+str(self.last_ps_stats))

    def open_ps_panel(self):
        win = tk.Toplevel(self.master)
        win.title('PS寄存器 — 地址是AXI偏移，参数为原始码')
        win.geometry('770x560')
        tk.Label(win,text='数值支持十进制或0x十六进制；写入后自动读回。状态0x300..0x33C只读。').pack(pady=6)
        bar = tk.Frame(win)
        bar.pack(fill='x')
        tk.Label(bar,text='偏移').pack(side='left')
        address = ttk.Combobox(bar,values=[f'0x{x:03X}' for x in sorted(RW_OFFSETS | RO_OFFSETS)],width=10)
        address.set('0x00C')
        address.pack(side='left')
        tk.Label(bar,text='值').pack(side='left')
        value = tk.Entry(bar,width=16)
        value.insert(0,'40')
        value.pack(side='left')
        result = tk.StringVar(value='')
        def read():
            v = self.link.read(int(address.get(),0))
            self.set_entry(value,v)
            result.set(f'读回：{v} / 0x{v:08X}')
        def write():
            self.check_target()
            v = self.link.write(int(address.get(),0),int(value.get(),0))
            result.set(f'写入并读回通过：{v} / 0x{v:08X}')
        ttk.Button(bar,text='读取',command=read).pack(side='left',padx=4)
        ttk.Button(bar,text='写入并验证',command=write).pack(side='left')
        tk.Label(win,textvariable=result).pack()
        opts = tk.Frame(win)
        opts.pack(pady=5)
        def enable(bit,on):
            self.check_target()
            self.link.modify(0,1 << bit,(1 << bit) if on else 0)
            result.set('CONTROL对应位已更新并验证')
        for label,bit,on in [('DNC开',7,True),('DNC关',7,False)]:
            ttk.Button(opts,text=label,command=lambda b=bit,o=on:enable(b,o)).pack(side='left',padx=3)
        tk.Label(win,text='0x004/0x008为旧版保留地址；TEMPIN=0x00C，Hall控制=0x038。').pack()
        tk.Label(win,text='状态已按RTL解码；连续读取不构成同一时刻快照，valid可能为短脉冲。').pack()
        output = tk.Text(win,height=18,width=90)
        output.pack(fill='both',expand=True,padx=8,pady=6)
        names=['CIC','RAW','OFFSET','CURRENT_OFFSET','TEMP_COMP','FILTER','NORM','COARSE',
               'PHASE','ANGLE_RAW','ANGLE_LINEAR','ANGLE_FINAL','FILTER_SEQ','NORM_SEQ','PHASE_SEQ','ANGLE_SEQ']
        def status():
            output.delete('1.0','end')
            for off,name in zip(sorted(RO_OFFSETS),names):
                v = self.link.read(off)
                output.insert('end', f'0x{off:03X} {name:16s} 0x{v:08X} {decode_status(off,v)}\n')
        ttk.Button(win,text='读取全部状态（顺序读取）',command=status).pack(pady=4)




    def diagnose_chain(self):
        self.check_target()
        if self.is_collecting or self.collection_pending:
            raise RuntimeError('请先停止采集再检查')
        control=self.link.read(0)
        self.log(f'诊断 CONTROL=0x{control:08X}；输入来自外部CIC')
        first={o:self.link.read(o) for o in range(0x330,0x340,4)}
        for name,off in SOURCES.items():
            v=self.link.read(off)
            self.log(f'{name}: 0x{v:08X} {decode_status(off,v)}')
        second={o:self.link.read(o) for o in first}
        for o in first:
            self.log(f'SEQ 0x{o:03X}: {first[o]} -> {second[o]}，增量={(second[o]-first[o]) & 0xFFFFFFFF}')
        self.log('SEQ不变可能是采样间隔内未更新；持续不变再检查PL时钟、复位、模块使能和顶层接线。')



    def apply_ps_stats(self,d,final):
        if d['offset'] in (0x324,0x328,0x32C):
            if not final:
                self.linearity_status.set(f"线性度: 采集中（{d['count']} 点）")
                return
            reasons={1:'样本不足',2:'未找到跨越两次0°边界的完整周期，请继续采集',4:'周期采样太稀',8:'周期内反转/跳变',
                     16:'角度码超出0..36000',32:'PS时间戳无效',64:'采样与外部转速不匹配',128:'非角度采集',
                     256:'等待结束采样'}
            if d['lin_status']:
                self.linearity_status.set('线性度: '+reasons.get(d['lin_status'],'无效统计'))
            else:
                value=d['lin_percent_u6']/1000000
                err=d['lin_error_mdeg']/1000
                self.linearity_status.set(f"线性度: {value:.6f}%FS  最大偏差 {err:.3f}°  拟合点 {d['lin_points']}")
            self.phase_status.set('相位: —')
            self.ps_summary.set(f"PS统计: {d['count']} 点，角度 {d['xmin']/100:.2f}°..{d['xmax']/100:.2f}°")
            if final:
                self.last_ps_stats=d
                self.log(self.linearity_status.get())
            return
        flags,stage=d['flags'],d['stage']
        reasons=[t for b,t in [(1,'无样本'),(2,'幅度不足'),(4,'不足2周期'),(8,'采样太稀'),
            (16,'波形退化'),(32,'系数超范围'),(64,'非双路波形'),(128,'达到量程边界'),
            (256,'计时无效'),(512,'采集点与校准阶段不匹配'),(1024,'不支持仅细校准')] if flags&b]
        self.ps_summary.set(f"PS统计: {d['count']} 点，CH1 {d['xmin']}..{d['xmax']}，CH2 {d['ymin']}..{d['ymax']}")
        if stage==1:
            self.phase_status.set('相位: 未计算（归一化关闭）')
        elif flags & ~32:
            self.phase_status.set('PS: '+'、'.join(reasons))
        else:
            phase=d['phase_mdeg']/1000
            self.phase_status.set(f'相位: {phase:.3f}°，正交误差 {phase-90:+.3f}°')
        if not final:return
        self.last_ps_stats=d
        if stage==1 and d['count']:
            for e,k in [(self.norm_ch1_min,'xmin'),(self.norm_ch1_max,'xmax'),
                        (self.norm_ch2_min,'ymin'),(self.norm_ch2_max,'ymax')]:self.set_entry(e,d[k])
            for e,k in [(self.op_ch1_entry,'work_x2'),(self.op_ch2_entry,'work_y2')]:
                e.config(state=tk.NORMAL);self.set_entry(e,f'{d[k]/2:.1f}');e.config(state='readonly')
            self.log('PS极值和工作点已回填；工作点=(max+min)/2，不是offset补偿表值。点击归一化写入后再开启归一化。')
            return
        if stage in (2,3) and not flags:
            entries=(self.phase_c1,self.phase_c2) if stage==2 else (self.phase_f1,self.phase_f2)
            self.set_entry(entries[0],d['k']);self.set_entry(entries[1],d['gain'])
            self.log(f"PS{'粗' if stage==2 else '细'}校准系数已回填 K={d['k']}, Gain={d['gain']}；未自动写PL")
        elif stage==0 and (d['control'] & 0x30)==0x30:
            self.log('粗加细校准：只显示采集/相位结果，不生成或覆盖系数，也不覆盖归一化参数')
        else:self.log('未回填系数：'+'、'.join(reasons))

    def refresh_norm_result(self):
        if self.link.read(0) & 8:return
        if not hasattr(self.link,'capture_offset') or not self.link.sample_count:
            self.log('归一化关闭：尚无本次连接的采样，请先采集波形；寄存器读写本身不产生波形统计')
            return
        d=self.link.capture_stats()
        if d['stage']==1:self.apply_ps_stats(d,True)
        else:self.log('最近采样不是归一化关闭阶段，请在关闭归一化并确认同步后重新采集')

if __name__ == "__main__":

    root = tk.Tk()

    app = AdvancedUI(
        root
    )

    root.mainloop()
