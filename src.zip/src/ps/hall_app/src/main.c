/*
 * Zynq standalone UART -> AXI-Lite
 * ASCII protocol v6 (external CIC input, physical Hall output)
 * Hall command: hall [mode pwm_frequency_index]
 * mode: 0=PWM, 1=SENT, 2=UVW, 3=ABZ
 * PWM frequency index: 0=50Hz, 1=500Hz, 2=2000Hz, 3=4000Hz
 *
 * PS UART:
 *   115200, 8N1
 *
 * AXI BASE:
 *   0x43C00000
 *
 * This version DOES NOT use xtime_l.h.
 * Cortex-A9 Global Timer is accessed directly.
 *
 * sqrt() / acos() require libm (-lm).
 */

#include "xparameters.h"
#include "xil_io.h"

#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <math.h>


/* ============================================================
 * BSP UART
 * ============================================================ */

extern char inbyte(void);
extern void outbyte(char c);


/* ============================================================
 * AXI
 * ============================================================ */

#define ANGLE_BASE 0x43C00000U

/* RTL: mode={HALL_CTRL[3],HALL_CTRL[0]}, PWM frequency=HALL_CTRL[2:1]. */
#define HALL_CTRL_OFFSET  0x038U
#define HALL_CTRL_MASK    0x0000000FU
#define HALL_MODE_COUNT   4U
#define HALL_PWM_COUNT    4U


/* ============================================================
 * Cortex-A9 Global Timer
 *
 * Zynq-7000 Global Timer base = 0xF8F00200
 *
 * Global Timer clock = CPU clock / 2
 * ============================================================ */

/*
 * 优先使用 BSP 里面已有的宏。
 * 如果 BSP 没有这些宏，则使用 Zynq-7000 固定地址。
 */

#if defined(XPAR_PS7_GLOBALTIMER_0_BASEADDR)

#define GT_BASE_ADDR \
    XPAR_PS7_GLOBALTIMER_0_BASEADDR

#elif defined(XPAR_GLOBAL_TMR_BASEADDR)

#define GT_BASE_ADDR \
    XPAR_GLOBAL_TMR_BASEADDR

#else

#define GT_BASE_ADDR \
    0xF8F00200U

#endif


/*
 * CPU clock
 *
 * 不同 BSP 版本宏名字可能不同。
 */

/* Vitis 2024.2 SDT uses XPAR_CPU_CORE_CLOCK_FREQ_HZ.
 * Do not test the legacy CORE alias alone: it may be defined while its
 * replacement XPAR_CPU_CORTEXA9_0_CPU_CLK_FREQ_HZ does not exist.
 */
#if defined(XPAR_CPU_CORE_CLOCK_FREQ_HZ)
#define CPU_CLOCK_HZ XPAR_CPU_CORE_CLOCK_FREQ_HZ
#elif defined(XPAR_CPU_CORTEXA9_0_CPU_CLK_FREQ_HZ)
#define CPU_CLOCK_HZ XPAR_CPU_CORTEXA9_0_CPU_CLK_FREQ_HZ
#elif defined(XPAR_PS7_CORTEXA9_0_CPU_CLK_FREQ_HZ)
#define CPU_CLOCK_HZ XPAR_PS7_CORTEXA9_0_CPU_CLK_FREQ_HZ
#else
#error "CPU frequency missing: use the generated xparameters.h CPU clock value"
#endif

#define TIMER_COUNTS_PER_SECOND \
    (CPU_CLOCK_HZ / 2U)


#define GT_COUNTER_LOW_OFFSET    0x00U
#define GT_COUNTER_HIGH_OFFSET   0x04U
#define GT_CONTROL_OFFSET        0x08U


/* ============================================================
 * Global Timer start
 * ============================================================ */

static void timer_start(void)
{
    uint32_t ctrl;

    ctrl = Xil_In32(
        GT_BASE_ADDR +
        GT_CONTROL_OFFSET
    );

    ctrl |= 0x00000001U;

    Xil_Out32(
        GT_BASE_ADDR +
        GT_CONTROL_OFFSET,
        ctrl
    );
}


/* ============================================================
 * Global Timer read 64 bit
 *
 * HIGH -> LOW -> HIGH
 *
 * 防止 LOW 溢出时读到不一致的64bit数值
 * ============================================================ */

static uint64_t timer_get(void)
{
    uint32_t high1;
    uint32_t high2;
    uint32_t low;

    do
    {
        high1 = Xil_In32(
            GT_BASE_ADDR +
            GT_COUNTER_HIGH_OFFSET
        );

        low = Xil_In32(
            GT_BASE_ADDR +
            GT_COUNTER_LOW_OFFSET
        );

        high2 = Xil_In32(
            GT_BASE_ADDR +
            GT_COUNTER_HIGH_OFFSET
        );

    } while (high1 != high2);

    return
        (((uint64_t)high1) << 32) |
        ((uint64_t)low);
}


/* ============================================================
 * UART send
 * ============================================================ */

static void send_text(const char *s)
{
    while (*s)
    {
        outbyte(*s++);
    }
}


static void send_hex(
    uint32_t v,
    unsigned digits
)
{
    static const char hex[] =
        "0123456789ABCDEF";

    send_text("0x");

    while (digits)
    {
        --digits;

        outbyte(
            hex[
                (v >> (digits * 4U)) &
                15U
            ]
        );
    }
}


static void error(
    const char *reason
)
{
    send_text("ERR ");
    send_text(reason);
    send_text("\r\n");
}


/* ============================================================
 * AXI writable address
 * ============================================================ */

static int writable(
    uint32_t a
)
{
    if (a & 3U)
    {
        return 0;
    }

    return

        a == 0x000U ||
        (a >= 0x00CU && a <= 0x038U) ||

        (
            a >= 0x040U &&
            a <= 0x060U
        ) ||

        (
            a >= 0x080U &&
            a <= 0x0A0U
        ) ||

        (
            a >= 0x0C0U &&
            a <= 0x0E0U
        ) ||

        (
            a >= 0x100U &&
            a <= 0x120U
        ) ||

        (
            a >= 0x140U &&
            a <= 0x160U
        ) ||

        (
            a >= 0x200U &&
            a <= 0x280U
        );
}


/* ============================================================
 * AXI readable address
 * ============================================================ */

static int readable(
    uint32_t a
)
{
    return

        writable(a) ||

        (
            !(a & 3U) &&
            a >= 0x300U &&
            a <= 0x33CU
        );
}


/* ============================================================
 * String -> uint32
 *
 * Supports:
 *
 * 123
 * 0x123
 *
 * Does not accept sign.
 * ============================================================ */

static int number(
    const char *s,
    uint32_t *out
)
{
    uint32_t v = 0U;
    uint32_t base = 10U;
    uint32_t digit;

    if (!s || !*s)
    {
        return 0;
    }


    if (
        s[0] == '0' &&
        (
            s[1] == 'x' ||
            s[1] == 'X'
        )
    )
    {
        base = 16U;

        s += 2;
    }


    if (!*s)
    {
        return 0;
    }


    while (*s)
    {
        if (
            *s >= '0' &&
            *s <= '9'
        )
        {
            digit =
                (uint32_t)(*s - '0');
        }

        else if (
            *s >= 'a' &&
            *s <= 'f'
        )
        {
            digit =
                (uint32_t)(*s - 'a') +
                10U;
        }

        else if (
            *s >= 'A' &&
            *s <= 'F'
        )
        {
            digit =
                (uint32_t)(*s - 'A') +
                10U;
        }

        else
        {
            return 0;
        }


        if (
            digit >= base ||
            v >
            (UINT32_MAX - digit) /
            base
        )
        {
            return 0;
        }


        v =
            v * base +
            digit;

        ++s;
    }


    *out = v;

    return 1;
}


/* ============================================================
 * Capture
 *
 * 32768 samples
 *
 * cap_x = 32768 * 4 = 128 KiB
 * cap_y = 32768 * 4 = 128 KiB
 *
 * total = 256 KiB
 * ============================================================ */

#define CAP_MAX 32768U


/* ============================================================
 * Capture error flags
 * ============================================================ */

#define F_EMPTY       1U
#define F_FLAT        2U
#define F_CYCLES      4U
#define F_SPARSE      8U
#define F_DEGENERATE 16U
#define F_RANGE      32U
#define F_NOT_PAIR   64U
#define F_CLIP      128U
#define F_CLOCK     256U


/* ============================================================
 * Capture buffer
 * ============================================================ */

static int32_t cap_x[CAP_MAX];
static int32_t cap_y[CAP_MAX];

static uint32_t cap_n;
static uint32_t cap_offset;
static uint32_t cap_control;

static int cap_active;


/*
 * 已经不使用 XTime
 */
static uint64_t cap_first;
static uint64_t cap_last;


/* ============================================================
 * Capture allowed monitor addresses
 * ============================================================ */

static int cap_address(
    uint32_t a
)
{
    return

        !(a & 3U) &&

        a >= 0x300U &&
        a <= 0x32CU;
}


/* ============================================================
 * Send one hex field
 * ============================================================ */

static void field(
    uint32_t v
)
{
    outbyte(' ');

    send_hex(
        v,
        8U
    );
}


/* ============================================================
 * Decode monitor register into X / Y
 * ============================================================ */

static void sample_pair(
    uint32_t a,
    uint32_t v,
    int32_t *x,
    int32_t *y
)
{
    int32_t lo;
    int32_t hi;


    lo =
        (int32_t)(
            v &
            0x3FFFU
        );


    hi =
        (int32_t)(
            (v >> 14) &
            0x3FFFU
        );


    /*
     * Angle registers
     */
    if (a >= 0x324U)
    {
        *x =
            (int32_t)(
                v &
                0xFFFFU
            );

        *y = 0;

        return;
    }


    /*
     * signed current offset
     */
    if (a == 0x30CU)
    {
        *x =
            (lo & 8192)
            ?
            lo - 16384
            :
            lo;


        *y =
            (hi & 8192)
            ?
            hi - 16384
            :
            hi;

        return;
    }


    /*
     * CIC / RAW / OFFSET / TEMP_COMP: low=CH1, high=CH2
     */
    if (
        a == 0x300U ||
        a == 0x304U ||
        a == 0x308U ||
        a == 0x310U
    )
    {
        *x = lo;
        *y = hi;

        return;
    }


    /*
     * FILTER / NORM / COARSE / PHASE
     *
     * X = high
     * Y = low
     */
    *x = hi;
    *y = lo;
}


/* ============================================================
 * Capture report
 * ============================================================ */

/* One complete wrap-to-wrap revolution, best-fit straight-line nonlinearity.
 * Uses PS timestamps (not sample indices); requires approximately constant speed.
 * Percent FS = max(abs(angle - best_fit(time))) / 36000 * 100.
 */
static uint64_t cap_time[CAP_MAX];
static void angle_linearity(uint32_t *status, uint32_t *percent_u6,
                            uint32_t *error_mdeg, uint32_t *points, int32_t *direction) {
    uint32_t i,start=0U,end=0U,last=0U,have=0U;
    int dir=0,last_dir=0;
    double sx=0.0,sy=0.0,sxx=0.0,sxy=0.0,n,den,slope,intercept,maxerr=0.0;
    double t0,t1,period,base,y0,y1,delta,frac,t,y,err;
    *status=0U; *percent_u6=0U; *error_mdeg=0U; *points=0U; *direction=0;
    if(cap_n<2U) { *status=1U; return; }
    for(i=0U;i<cap_n;++i) {
        if(cap_x[i]<0 || cap_x[i]>36000) { *status=16U; return; }
        if(i && cap_time[i]<=cap_time[i-1U]) { *status=32U; return; }
        if(!i)continue;
        y0=cap_x[i-1U]==36000 ? 0.0 : (double)cap_x[i-1U];
        y1=cap_x[i]==36000 ? 0.0 : (double)cap_x[i];
        delta=y1-y0;
        dir=delta< -18000.0 ? 1 : delta>18000.0 ? -1 : 0;
        if(dir) {
            if(have && dir==last_dir) { start=last; end=i; *direction=dir; }
            else { start=end=0U; }
            have=1U; last=i; last_dir=dir;
        }
    }
    if(!end) { *status=2U; return; }
    *points=end-start+2U; /* interior samples plus interpolated 0/360 endpoints */
    if(end-start<32U) { *status=4U; return; }
    dir=*direction;
    base=(double)(cap_time[start]-cap_time[start-1U]);
    y0=cap_x[start-1U]==36000 ? 0.0 : (double)cap_x[start-1U];
    y1=cap_x[start]==36000 ? 0.0 : (double)cap_x[start];
    delta=y1-y0+(double)dir*36000.0;
    frac=(dir>0 ? 36000.0-y0 : -y0)/delta;
    t0=base*frac;
    y0=cap_x[end-1U]==36000 ? 0.0 : (double)cap_x[end-1U];
    y1=cap_x[end]==36000 ? 0.0 : (double)cap_x[end];
    delta=y1-y0+(double)dir*36000.0;
    frac=(dir>0 ? 36000.0-y0 : -y0)/delta;
    t1=(double)(cap_time[end-1U]-cap_time[start-1U])+
        (double)(cap_time[end]-cap_time[end-1U])*frac;
    period=t1-t0;
    if(period<=0.0) { *status=32U; return; }
    for(i=start;i<=end;++i) {
        y0=cap_x[i-1U]==36000 ? 0.0 : (double)cap_x[i-1U];
        y1=cap_x[i]==36000 ? 0.0 : (double)cap_x[i];
        delta=y1-y0;
        if(delta< -18000.0)delta+=36000.0;
        if(delta>18000.0)delta-=36000.0;
        if(delta*dir< -20.0) { *status=8U; return; }
        if(fabs(delta)>4500.0 || (double)(cap_time[i]-cap_time[i-1U])>period/8.0) {
            *status=4U; return;
        }
    }
    /* Two boundary points: (0,0), (1,dir*36000). */
    sx=1.0; sy=(double)dir*36000.0; sxx=1.0; sxy=sy;
    for(i=start;i<end;++i) {
        t=((double)(cap_time[i]-cap_time[start-1U])-t0)/period;
        y=cap_x[i]==36000 ? 0.0 : (double)cap_x[i];
        if(dir<0)y-=36000.0;
        sx+=t; sy+=y; sxx+=t*t; sxy+=t*y;
    }
    n=(double)*points; den=n*sxx-sx*sx;
    if(den<=0.0) { *status=32U; return; }
    slope=(n*sxy-sx*sy)/den; intercept=(sy-slope*sx)/n;
    if(slope*dir<=0.0) { *status=8U; return; }
    maxerr=fabs(intercept);
    err=fabs((double)dir*36000.0-slope-intercept); if(err>maxerr)maxerr=err;
    for(i=start;i<end;++i) {
        t=((double)(cap_time[i]-cap_time[start-1U])-t0)/period;
        y=cap_x[i]==36000 ? 0.0 : (double)cap_x[i]; if(dir<0)y-=36000.0;
        err=fabs(y-slope*t-intercept); if(err>maxerr)maxerr=err;
    }
    *percent_u6=(uint32_t)(maxerr/36000.0*100000000.0+0.5);
    *error_mdeg=(uint32_t)(maxerr*10.0+0.5);
}

static void cap_report(char op) {
    uint32_t lin_status=128U,lin_percent=0U,lin_error=0U,lin_points=0U;
    int32_t lin_direction=0;
    uint32_t i, flags=0U, cycles=0U, cuts[3]={0U,0U,0U}, found=0U;
    uint32_t begin=0U, end=0U, used=0U, rate_milli=0U;
    int32_t xmin=0,xmax=0,ymin=0,ymax=0,kq=0,phase_mdeg=0;
    uint32_t gainq=0U;
    uint32_t mode=cap_control & 0x30U, stage=0U;
    int pair=(cap_offset<=0x320U && cap_offset!=0x30CU);
    if(mode==0x20U) flags |= 1024U; /* fine-only mode is unsupported */
    else if(pair && !(cap_control & 8U)) stage=1U; /* extrema + operating point */
    else if(pair && mode==0U && cap_offset==0x318U) stage=2U;
    else if(pair && mode==0x10U && cap_offset==0x31CU) stage=3U;
    else if(pair && mode!=0x30U) flags |= 512U; /* wrong source for current stage */
    int armed=0;
    double mid, hysteresis, sx=0.0,sy=0.0,sxx=0.0,syy=0.0,sxy=0.0;
    double xx,yy,xy,rho,k,qr,residual,gain,rate=0.0;
    if (!cap_n) flags |= F_EMPTY;
    else {
        xmin=xmax=cap_x[0]; ymin=ymax=cap_y[0];
        for (i=1U;i<cap_n;++i) {
            if(cap_x[i]<xmin)xmin=cap_x[i];
            if(cap_x[i]>xmax)xmax=cap_x[i];
            if(cap_y[i]<ymin)ymin=cap_y[i];
            if(cap_y[i]>ymax)ymax=cap_y[i];
        }
    }
    if(cap_n>1U && cap_last>cap_first) {
        rate=(double)(cap_n-1U)*(double)TIMER_COUNTS_PER_SECOND/(double)(cap_last-cap_first);
        if(rate<4294967.0)rate_milli=(uint32_t)(rate*1000.0+0.5);
        else flags |= F_CLOCK;
    } else flags |= F_CLOCK;
    if(cap_offset == 0x30CU || cap_offset >= 0x324U)flags |= F_NOT_PAIR;
    if(xmax-xmin<32 || ymax-ymin<32)flags |= F_FLAT;
    if(stage!=1U && !(flags & (F_EMPTY|F_NOT_PAIR))) {
        if(xmin<=0 || ymin<=0 || xmax>=16383 || ymax>=16383)flags |= F_CLIP;
        mid=((double)xmin+xmax)*0.5;
        hysteresis=((double)xmax-xmin)*0.02;
        for(i=0U;i<cap_n;++i) {
            if((double)cap_x[i]<mid-hysteresis)armed=1;
            else if(armed && (double)cap_x[i]>=mid) {
                cuts[0]=cuts[1]; cuts[1]=cuts[2]; cuts[2]=i;
                ++found; armed=0;
            }
        }
        cycles=found ? found-1U : 0U;
        if(found<3U) flags |= F_CYCLES;
        else {
            begin=cuts[0]; end=cuts[2]; used=end-begin;
            for(i=1U;i<3U;++i)if(cuts[i]-cuts[i-1U]<24U)flags |= F_SPARSE;
        }
    }
    if(stage!=1U && !flags && used) {
        /* Covariance after mean removal, using the LAST two complete periods. */
        for(i=begin;i<end;++i) {
            double x=(double)cap_x[i], y=(double)cap_y[i];
            sx+=x; sy+=y; sxx+=x*x; syy+=y*y; sxy+=x*y;
        }
        xx=sxx-sx*sx/used; yy=syy-sy*sy/used; xy=sxy-sx*sy/used;
        if(xx<=1.0 || yy<=1.0)flags |= F_DEGENERATE;
        else {
            rho=xy/sqrt(xx*yy);
            if(rho>1.0)rho=1.0;
            if(rho< -1.0)rho= -1.0;
            phase_mdeg=(int32_t)(acos(rho)*57295.77951308232+0.5);
            if(stage==2U || stage==3U) {
            k=xy/xx;
            if(k*16384.0>32767.0 || k*16384.0< -32768.0)flags |= F_RANGE;
            else {
                kq=(int32_t)(k*16384.0); /* Truncate like the original PC algorithm. */
                qr=(double)kq/16384.0;
                residual=yy-2.0*qr*xy+qr*qr*xx;
                if(residual<=xx*0.000001)flags |= F_DEGENERATE;
                else {
                    /* Match corrected Y amplitude to X, including unequal input amplitudes.
                     * Equal amplitudes reduce to the old 1/sqrt(1-K*K) formula.
                     * Conservative original GUI gain range retained (<=32767).
                     */
                    gain=sqrt(xx/residual)*16384.0;
                    if(gain<1.0 || gain>32767.0)flags |= F_RANGE;
                    else gainq=(uint32_t)(gain+0.5);
                }
            }
        }
    }
            }
    send_text("OK "); outbyte(op); outbyte(' '); send_hex(cap_offset,3U);
    field(cap_n); field((uint32_t)xmin); field((uint32_t)xmax);
    field((uint32_t)ymin); field((uint32_t)ymax); field((uint32_t)phase_mdeg);
    field((uint32_t)kq); field(gainq); field(flags); field(cycles); field(used); field(rate_milli);
    if(cap_offset>=0x324U && cap_offset<=0x32CU) {
        if(op=='E')
            angle_linearity(&lin_status,&lin_percent,&lin_error,&lin_points,&lin_direction);
        else
            lin_status=256U; /* Angle linearity is calculated only after capture ends. */
    }
    field(cap_control); field(stage); field((uint32_t)(xmin+xmax)); field((uint32_t)(ymin+ymax));
    field(lin_status); field(lin_percent); field(lin_error); field(lin_points); field((uint32_t)lin_direction);
    send_text("\r\n");
}

static int capture_command(
    unsigned argc,
    char **argv
)
{
    uint32_t a;
    uint32_t v;

    char op =
        argv[0][0];


    if (
        argv[0][1] ||

        (
            op != 'a' &&
            op != 'b' &&
            op != 's' &&
            op != 'p' &&
            op != 'e'
        )
    )
    {
        return 0;
    }


    if (
        argc !=
        (
            op == 'b'
            ?
            2U
            :
            1U
        )
    )
    {
        error("ARGS");

        return 1;
    }


    /* ========================================================
     * Abort
     * ======================================================== */

    if (op == 'a')
    {
        cap_active = 0;

        cap_n = 0U;

        send_text(
            "OK A\r\n"
        );

        return 1;
    }


    /* ========================================================
     * Begin
     * ======================================================== */

    if (op == 'b')
    {
        if (cap_active)
        {
            error("BUSY");

            return 1;
        }


        if (
            !number(
                argv[1],
                &a
            )
        )
        {
            error("NUMBER");

            return 1;
        }


        if (!cap_address(a))
        {
            error("SOURCE");

            return 1;
        }


        cap_offset = a;

        cap_n = 0U;

        cap_first = 0U;
        cap_last = 0U;

        cap_active = 1;


        cap_control =
            Xil_In32(
                ANGLE_BASE
            );


        send_text("OK B ");

        send_hex(
            a,
            3U
        );

        send_text("\r\n");

        return 1;
    }


    /* ========================================================
     * Progress / End
     * ======================================================== */

    if (
        op == 'p' ||
        op == 'e'
    )
    {
        if (op == 'e')
        {
            cap_active = 0;
        }


        cap_report(
            op == 'e'
            ?
            'E'
            :
            'P'
        );

        return 1;
    }


    /* ========================================================
     * Sample
     * ======================================================== */

    if (!cap_active)
    {
        error(
            "NO_CAPTURE"
        );

        return 1;
    }


    if (
        cap_n >=
        CAP_MAX
    )
    {
        error("FULL");

        return 1;
    }


    v =
        Xil_In32(
            ANGLE_BASE +
            cap_offset
        );


    /*
     * Timestamp
     */
    cap_last =
        timer_get();


    if (!cap_n)
    {
        cap_first =
            cap_last;
    }


    cap_time[cap_n]=cap_last;
    sample_pair(
        cap_offset,
        v,
        &cap_x[cap_n],
        &cap_y[cap_n]
    );


    ++cap_n;


    send_text("OK S ");

    send_hex(
        cap_offset,
        3U
    );


    field(cap_n);

    field(v);


    send_text("\r\n");


    return 1;
}


/* Read/set Hall output configuration. Generic r/w/m commands remain valid. */
static int hall_command(unsigned argc, char **argv)
{
    uint32_t mode, frequency, control, expected;

    if (strcmp(argv[0], "hall")) {
        return 0;
    }
    if (argc != 1U && argc != 3U) {
        error("ARGS");
        return 1;
    }
    if (argc == 3U) {
        if (cap_active) {
            error("BUSY");
            return 1;
        }
        if (!number(argv[1], &mode) || !number(argv[2], &frequency)) {
            error("NUMBER");
            return 1;
        }
        if (mode >= HALL_MODE_COUNT || frequency >= HALL_PWM_COUNT) {
            error("HALL_RANGE");
            return 1;
        }
        control = Xil_In32(ANGLE_BASE + HALL_CTRL_OFFSET);
        expected = (control & ~HALL_CTRL_MASK) |
                   (mode & 1U) | ((mode & 2U) << 2U) | (frequency << 1U);
        Xil_Out32(ANGLE_BASE + HALL_CTRL_OFFSET, expected);
        control = Xil_In32(ANGLE_BASE + HALL_CTRL_OFFSET);
        if (((control ^ expected) & HALL_CTRL_MASK) != 0U) {
            error("HALL_VERIFY");
            return 1;
        }
    } else {
        control = Xil_In32(ANGLE_BASE + HALL_CTRL_OFFSET);
    }
    mode = (control & 1U) | ((control >> 2U) & 2U);
    frequency = (control >> 1U) & 3U;
    send_text("OK HALL");
    field(mode);
    field(frequency);
    field(control);
    send_text("\r\n");
    return 1;
}


/* ============================================================
 * Command execute
 *
 * hello
 * hall [mode pwm_frequency_index]
 *
 * r offset
 *
 * w offset value
 *
 * m offset mask value
 *
 * a
 * b offset
 * s
 * p
 * e
 * ============================================================ */

static void execute(
    char *line
)
{
    char *argv[5];

    char *p =
        line;

    unsigned argc =
        0U;


    uint32_t offset;
    uint32_t value;

    uint32_t mask =
        UINT32_MAX;

    uint32_t actual;

    char op;


    /* ========================================================
     * Split arguments
     * ======================================================== */

    while (*p)
    {
        while (
            *p == ' ' ||
            *p == '\t'
        )
        {
            ++p;
        }


        if (!*p)
        {
            break;
        }


        if (argc == 5U)
        {
            error("ARGS");

            return;
        }


        argv[argc++] =
            p;


        while (
            *p &&
            *p != ' ' &&
            *p != '\t'
        )
        {
            ++p;
        }


        if (*p)
        {
            *p++ =
                '\0';
        }
    }


    if (!argc)
    {
        return;
    }


    /* ========================================================
     * Command -> lowercase
     * ======================================================== */

    for (
        p = argv[0];
        *p;
        ++p
    )
    {
        if (
            *p >= 'A' &&
            *p <= 'Z'
        )
        {
            *p =
                (char)(
                    *p -
                    'A' +
                    'a'
                );
        }
    }


    /* ========================================================
     * HELLO
     * ======================================================== */

    if (
        !strcmp(
            argv[0],
            "hello"
        )
    )
    {
        if (
            argc !=
            1U
        )
        {
            error("ARGS");

            return;
        }


        send_text(
            "OK HELLO 6 0x43C00000"
        );



        field(
            CAP_MAX
        );


        send_text(
            "\r\n"
        );


        return;
    }


    if (hall_command(argc, argv)) {
        return;
    }


    /* ========================================================
     * Capture command
     * ======================================================== */

    if (
        capture_command(
            argc,
            argv
        )
    )
    {
        return;
    }


    /* ========================================================
     * R / W / M
     * ======================================================== */

    op =
        argv[0][0];


    if (
        argv[0][1] ||

        (
            op != 'r' &&
            op != 'w' &&
            op != 'm'
        )
    )
    {
        error("CMD");

        return;
    }


    if (
        argc !=
        (
            op == 'r'
            ?
            2U
            :
            op == 'w'
            ?
            3U
            :
            4U
        )
    )
    {
        error("ARGS");

        return;
    }


    /* ========================================================
     * Address
     * ======================================================== */

    if (
        !number(
            argv[1],
            &offset
        )
    )
    {
        error("NUMBER");

        return;
    }


    if (
        !readable(
            offset
        )
    )
    {
        error("ADDR");

        return;
    }


    /* ========================================================
     * Read
     * ======================================================== */

    if (op == 'r')
    {
        actual =
            Xil_In32(
                ANGLE_BASE +
                offset
            );


        send_text(
            "OK R "
        );


        send_hex(
            offset,
            3U
        );


        outbyte(' ');


        send_hex(
            actual,
            8U
        );


        send_text(
            "\r\n"
        );


        return;
    }


    /*
     * Capture active 时禁止改配置，
     * 防止采集途中参数改变。
     */

    if (cap_active)
    {
        error("BUSY");

        return;
    }


    if (
        !writable(
            offset
        )
    )
    {
        error(
            "READ_ONLY"
        );

        return;
    }


    /* ========================================================
     * Modify mask
     * ======================================================== */

    if (
        op == 'm' &&
        !number(
            argv[2],
            &mask
        )
    )
    {
        error("NUMBER");

        return;
    }


    /* ========================================================
     * Value
     * ======================================================== */

    if (
        !number(
            argv[
                op == 'm'
                ?
                3
                :
                2
            ],
            &value
        )
    )
    {
        error("NUMBER");

        return;
    }


    /* ========================================================
     * Modify
     * ======================================================== */

    if (op == 'm')
    {
        value =
            (
                Xil_In32(
                    ANGLE_BASE +
                    offset
                )
                &
                ~mask
            )
            |
            (
                value &
                mask
            );
    }


    /* ========================================================
     * AXI write
     * ======================================================== */

    if(offset==0U && (value & 0x30U)==0x20U) {
        error("MODE_FINE_ONLY"); return;
    }
    Xil_Out32(
        ANGLE_BASE +
        offset,
        value
    );


    /* ========================================================
     * Read back
     * ======================================================== */

    actual =
        Xil_In32(
            ANGLE_BASE +
            offset
        );


    /* ========================================================
     * Response
     * ======================================================== */

    send_text(
        op == 'm'
        ?
        "OK M "
        :
        "OK W "
    );


    send_hex(
        offset,
        3U
    );


    outbyte(' ');


    send_hex(
        value,
        8U
    );


    outbyte(' ');


    send_hex(
        actual,
        8U
    );


    send_text(
        "\r\n"
    );
}


/* ============================================================
 * MAIN
 * ============================================================ */

int main(void)
{
    char line[128];

    unsigned length =
        0U;

    int bad =
        0;


    /* ========================================================
     * Start Cortex-A9 Global Timer
     * ======================================================== */

    timer_start();


    /* ========================================================
     * Boot response
     * ======================================================== */

    send_text(
        "READY PS_AXI_ASCII 6\r\n"
    );


    /* ========================================================
     * UART loop
     * ======================================================== */

    for (;;)
    {
        unsigned char c =
            (unsigned char)
            inbyte();


        /* ====================================================
         * CR / LF
         * ==================================================== */

        if (
            c == '\r' ||
            c == '\n'
        )
        {
            if (bad)
            {
                error(
                    "LINE"
                );
            }

            else if (length)
            {
                line[length] =
                    '\0';


                execute(
                    line
                );
            }


            length =
                0U;

            bad =
                0;
        }


        /* ====================================================
         * Backspace
         * ==================================================== */

        else if (
            c == 8U ||
            c == 127U
        )
        {
            if (
                !bad &&
                length
            )
            {
                --length;
            }
        }


        /* ====================================================
         * Normal ASCII
         * ==================================================== */

        else if (!bad)
        {
            if (
                (
                    c < 32U &&
                    c != '\t'
                )
                ||
                c > 126U
                ||
                length >=
                sizeof(line) - 1U
            )
            {
                bad =
                    1;
            }

            else
            {
                line[length++] =
                    (char)c;
            }
        }


        /*
         * Invalid / overflow lines are discarded
         * until CR/LF.
         */
    }


    return 0;
}
