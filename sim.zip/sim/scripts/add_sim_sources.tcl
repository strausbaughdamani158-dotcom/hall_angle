# Run in Vivado Tcl Console after opening the project and generating BD outputs.
if {[get_projects -quiet] eq ""} {
    error "Open the Vivado project before sourcing this script"
}

set sim_dir [file dirname [file dirname [file normalize [info script]]]]
set tb_wrapper [file join $sim_dir tb tb_angle_sensor_system_wrapper.sv]
set tb_cic [file join $sim_dir tb tb_cic_top.sv]
foreach src [list $tb_wrapper $tb_cic] {
    if {![file exists $src]} { error "Missing simulation source: $src" }
}

add_files -fileset sim_1 -norecurse [list $tb_wrapper $tb_cic]
set_property top tb_angle_sensor_system_wrapper [get_filesets sim_1]
update_compile_order -fileset sim_1
puts "Simulation top: tb_angle_sensor_system_wrapper"
puts "Synthesis top is unchanged. Run Behavioral Simulation next."
