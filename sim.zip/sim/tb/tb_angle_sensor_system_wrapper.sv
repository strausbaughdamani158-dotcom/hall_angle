`timescale 1ns/1ps

// Behavioral test of the real Vivado Block Design wrapper.
// CH1 is Y/sin PDM; CH2 is X/cos PDM. A first-order pulse-density encoder
// converts slowly rotating analog references into the two 1-bit input streams.
// The PS7 VIP configures the real AXI Hall register; no ARM ELF or UART is run.
// Defaults: PWM -> SENT -> UVW -> ABZ, 20 ms per mode, repeated indefinitely.
// Set AUTO_HALL_MODES=0 and INITIAL_HALL_MODE=0..3 to hold one selected mode.
module tb_angle_sensor_system_wrapper #(
    parameter integer AUTO_HALL_MODES = 1,
    parameter integer INITIAL_HALL_MODE = 0,
    parameter integer PWM_FREQUENCY_INDEX = 3,
    parameter time HALL_MODE_HOLD_NS = 20_000_000
);
    logic ps_clk = 0;
    always #15 ps_clk = ~ps_clk; // 33.3 MHz PS reference input
    logic porb = 0;
    logic srstb = 0;
    tri fixed_ps_clk;
    tri fixed_ps_porb;
    tri fixed_ps_srstb;
    assign fixed_ps_clk = ps_clk;
    assign fixed_ps_porb = porb;
    assign fixed_ps_srstb = srstb;

    logic DataIn_1_0 = 0;
    logic DataIn_2_0 = 0;
    logic data_vaild_0 = 0;
    logic UART_1_0_rxd = 1;
    wire UART_1_0_txd;
    wire [2:0] hall_out_0;
    wire hall_g14 = hall_out_0[0]; // PWM/SENT, W or Z
    wire hall_f16 = hall_out_0[1]; // V or B
    wire hall_h15 = hall_out_0[2]; // U or A

    angle_sensor_system_wrapper dut (
        .DDR_addr(), .DDR_ba(), .DDR_cas_n(), .DDR_ck_n(), .DDR_ck_p(),
        .DDR_cke(), .DDR_cs_n(), .DDR_dm(), .DDR_dq(), .DDR_dqs_n(),
        .DDR_dqs_p(), .DDR_odt(), .DDR_ras_n(), .DDR_reset_n(), .DDR_we_n(),
        .DataIn_1_0(DataIn_1_0), .DataIn_2_0(DataIn_2_0),
        .FIXED_IO_ddr_vrn(), .FIXED_IO_ddr_vrp(), .FIXED_IO_mio(),
        .FIXED_IO_ps_clk(fixed_ps_clk), .FIXED_IO_ps_porb(fixed_ps_porb),
        .FIXED_IO_ps_srstb(fixed_ps_srstb),
        .UART_1_0_rxd(UART_1_0_rxd), .UART_1_0_txd(UART_1_0_txd),
        .data_vaild_0(data_vaild_0), .hall_out_0(hall_out_0)
    );

    localparam real PI = 3.14159265358979323846;
    localparam integer PDM_BITS_PER_STEP = 2560;
    localparam integer STEPS_PER_REV = 64;
    integer bit_index = 0;
    integer cic_count = 0;
    integer angle_count = 0;
    integer setup_errors = 0;
    integer angle_errors = 0;
    integer hall_mux_errors = 0;
    integer hall_config_count = 0;
    integer hall_mux_checks = 0;
    logic hall_test_enable = 0;
    logic hall_config_busy = 0;
    time hall_config_started = 0;
    logic [1:0] hall_requested_mode = 0;
    logic [3:0] hall_modes_seen = 0;
    logic [31:0] hall_control_readback = 0;
    integer cic_y_min = 65535, cic_y_max = 0;
    integer cic_x_min = 65535, cic_x_max = 0;
    integer angle_min = 65535, angle_max = 0;
    real theta, pdm_target_y = 0.5, pdm_target_x = 0.85;
    real pdm_acc_y = 0.0, pdm_acc_x = 0.0;
    wire pl_clk = dut.angle_sensor_system_i.processing_system7_0_FCLK_CLK0;
    wire pl_resetn = dut.angle_sensor_system_i.rst_ps7_0_50M_peripheral_aresetn[0];
    wire ps_fclk_resetn = dut.angle_sensor_system_i.processing_system7_0_FCLK_RESET0_N;
    wire cic_valid = dut.angle_sensor_system_i.angle_sensor_axi_0.inst.cic_valid;
    wire [15:0] cic_ch1 = dut.angle_sensor_system_i.angle_sensor_axi_0.inst.cic_dout1;
    wire [15:0] cic_ch2 = dut.angle_sensor_system_i.angle_sensor_axi_0.inst.cic_dout2;
    wire [15:0] angle_final = dut.angle_sensor_system_i.angle_sensor_axi_0.inst.angle_final_out;
    wire angle_valid = dut.angle_sensor_system_i.angle_sensor_axi_0.inst.angle_final_valid;
    wire [1:0] hall_mode = dut.angle_sensor_system_i.angle_sensor_axi_0.inst.hall_mode_select;
    wire [1:0] hall_pwm_frequency = dut.angle_sensor_system_i.angle_sensor_axi_0.inst.hall_pwm_freq_select;
    wire [13:0] dsp_ch1 = dut.angle_sensor_system_i.angle_sensor_axi_0.inst.u_dsp_top.adc_ch1_in;
    wire [13:0] dsp_ch2 = dut.angle_sensor_system_i.angle_sensor_axi_0.inst.u_dsp_top.adc_ch2_in;
    // This RTL samples the DSP filter at 1 kHz and suppresses valid for the
    // first 32 samples. At the actual 10 MHz PL clock, allow about 32 ms.
    wire [5:0] dsp_warmup_samples = dut.angle_sensor_system_i.angle_sensor_axi_0.inst.u_dsp_top.u_angle_dsp.u_filter_top.FIR_filter_1.warmup_samples;
    wire hall_u = (hall_mode == 2) ? hall_h15 : 1'b0;
    wire hall_v = (hall_mode == 2) ? hall_f16 : 1'b0;
    wire hall_w = (hall_mode == 2) ? hall_g14 : 1'b0;
    wire hall_a = (hall_mode == 3) ? hall_h15 : 1'b0;
    wire hall_b = (hall_mode == 3) ? hall_f16 : 1'b0;
    wire hall_z = (hall_mode == 3) ? hall_g14 : 1'b0;
    wire [12:0] cic_input_count =
        dut.angle_sensor_system_i.angle_sensor_axi_0.inst.u_cic_top.u_cic_1.count;
    wire [7:0] cic_warmup_count =
        dut.angle_sensor_system_i.angle_sensor_axi_0.inst.u_cic_top.u_cic_1.warmup_cnt;
    wire cic_sample_enable =
        dut.angle_sensor_system_i.angle_sensor_axi_0.inst.u_cic_top.u_cic_1.sample_en_sync;
    wire result_ready = (cic_count >= 40) && (angle_count >= 2) &&
                        (cic_y_max > cic_y_min) && (cic_x_max > cic_x_min);

    localparam logic [31:0] HALL_CTRL_ADDRESS = 32'h43C00038;
    logic [2:0] hall_expected;

    // The mux is registered. Sample its inputs before NBA updates, then check
    // the actual three pins after the clock edge. Encoder outputs are not forced.
    always @(posedge pl_clk) begin
        if (hall_test_enable && pl_resetn === 1'b1) begin
            case (hall_mode)
                2'd0: hall_expected = {2'b00, dut.angle_sensor_system_i.angle_sensor_axi_0.inst.u_dsp_top.u_hall_interface.PWM1_out};
                2'd1: hall_expected = {2'b00, dut.angle_sensor_system_i.angle_sensor_axi_0.inst.u_dsp_top.u_hall_interface.SENT1_out};
                2'd2: hall_expected = dut.angle_sensor_system_i.angle_sensor_axi_0.inst.u_dsp_top.u_hall_interface.UVW_out;
                2'd3: hall_expected = dut.angle_sensor_system_i.angle_sensor_axi_0.inst.u_dsp_top.u_hall_interface.ABZ_out;
                default: hall_expected = 3'bxxx;
            endcase
            #1;
            hall_mux_checks = hall_mux_checks + 1;
            if (hall_out_0 !== hall_expected || $isunknown(hall_out_0)) begin
                hall_mux_errors = hall_mux_errors + 1;
                $fatal(1, "Hall mux/pin mismatch: mode=%0d got=%b expected=%b", hall_mode, hall_out_0, hall_expected);
            end
        end
    end

    task automatic configure_hall(input logic [1:0] mode);
        logic [1023:0] write_payload, read_payload;
        logic [1:0] response;
        logic [31:0] control;
        begin
            // Preserve the legacy mode bit and PWM frequency positions.
            // mode={bit3,bit0}; frequency=bits2:1.
            control = ((mode & 1) | ((mode & 2) << 2) |
                       (PWM_FREQUENCY_INDEX << 1));
            write_payload = {992'd0, control};
            read_payload = 0;
            hall_config_busy = 1;
            hall_config_started = $time;
            dut.angle_sensor_system_i.processing_system7_0.inst.write_data(
                HALL_CTRL_ADDRESS, 4, write_payload, response);
            if (response !== 2'b00)
                $fatal(1, "Hall AXI write failed: response=%b", response);
            dut.angle_sensor_system_i.processing_system7_0.inst.read_data(
                HALL_CTRL_ADDRESS, 4, read_payload, response);
            if (response !== 2'b00 || read_payload[31:0] !== control)
                $fatal(1, "Hall AXI readback mismatch: got=%h expected=%h response=%b", read_payload[31:0], control, response);
            hall_control_readback = read_payload[31:0];
            repeat (3) @(negedge pl_clk);
            if (hall_mode !== mode || hall_pwm_frequency !== PWM_FREQUENCY_INDEX)
                $fatal(1, "Hall register-to-DSP control mismatch");
            hall_config_busy = 0;
            hall_modes_seen[mode] = 1'b1;
            hall_config_count = hall_config_count + 1;
            $display("HALL CONFIG: t=%0t mode=%0d (0=PWM 1=SENT 2=UVW 3=ABZ) control=0x%08h pins[H15,F16,G14]=%b",
                     $time, mode, hall_control_readback, hall_out_0);
        end
    endtask

    initial begin
        if (INITIAL_HALL_MODE < 0 || INITIAL_HALL_MODE > 3 ||
            PWM_FREQUENCY_INDEX < 0 || PWM_FREQUENCY_INDEX > 3 ||
            HALL_MODE_HOLD_NS <= 0)
            $fatal(1, "Invalid Hall test parameter");
        wait (hall_test_enable);
        hall_requested_mode = INITIAL_HALL_MODE;
        configure_hall(hall_requested_mode);
        forever begin
            #(HALL_MODE_HOLD_NS);
            if (AUTO_HALL_MODES) begin
                hall_requested_mode = hall_requested_mode + 2'd1;
                configure_hall(hall_requested_mode);
            end
        end
    end

    // A stalled AXI transaction should fail clearly instead of appearing to
    // produce a constant Hall waveform forever. This is not a run-time limit.
    initial forever begin
        #1_000_000;
        if (hall_config_busy && ($time - hall_config_started > 1_000_000))
            $fatal(1, "Hall AXI transaction timed out; check PS VIP reset and AXI clocks");
    end

    always @(negedge pl_clk) begin
        if (porb && srstb && data_vaild_0) begin
            if ((bit_index % PDM_BITS_PER_STEP) == 0) begin
                theta = 2.0 * PI * ((bit_index / PDM_BITS_PER_STEP) % STEPS_PER_REV)
                        / STEPS_PER_REV;
                pdm_target_y = 0.5 + 0.35 * $sin(theta);
                pdm_target_x = 0.5 + 0.35 * $cos(theta);
            end
            pdm_acc_y = pdm_acc_y + pdm_target_y;
            pdm_acc_x = pdm_acc_x + pdm_target_x;
            DataIn_1_0 = (pdm_acc_y >= 1.0);
            DataIn_2_0 = (pdm_acc_x >= 1.0);
            if (DataIn_1_0) pdm_acc_y = pdm_acc_y - 1.0;
            if (DataIn_2_0) pdm_acc_x = pdm_acc_x - 1.0;
            bit_index = bit_index + 1;
        end
        if (cic_valid === 1'b1) begin
            if (cic_count == 0)
                $display("FIRST CIC: t=%0t Y=%0d X=%0d", $time, cic_ch1, cic_ch2);
            cic_count = cic_count + 1;
            if (cic_ch1 < cic_y_min) cic_y_min = cic_ch1;
            if (cic_ch1 > cic_y_max) cic_y_max = cic_ch1;
            if (cic_ch2 < cic_x_min) cic_x_min = cic_ch2;
            if (cic_ch2 > cic_x_max) cic_x_max = cic_ch2;
        end
        if (angle_valid === 1'b1) begin
            if (angle_count == 0)
                $display("FIRST DSP ANGLE: t=%0t code=%0d", $time, angle_final);
            angle_count = angle_count + 1;
            if (angle_final > 16'd36000) begin
                angle_errors = angle_errors + 1;
                if (angle_errors == 1)
                    $display("WARNING: DSP angle out of range: %0d", angle_final);
            end
            if (angle_final < angle_min) angle_min = angle_final;
            if (angle_final > angle_max) angle_max = angle_final;
        end
    end

    initial begin
        // Keep reset asserted long enough for the Zynq VIP and the AXI reset
        // checker. The old 300 ns pulse caused XILINX_RESET_PULSE_WIDTH.
        #10000;
        porb = 1;
        #10000;
        srstb = 1;
        // The Zynq PS VIP keeps FCLK_RESET0_N low after POR/SRSTB release.
        // Its bit 0 is active-high *reset control*: write 0 to release the
        // active-low FCLK_RESET0_N output feeding proc_sys_reset and CIC.rst.
        #2000;
        dut.angle_sensor_system_i.processing_system7_0.inst.fpga_soft_reset(32'h00000000);
        #10000;
        $display("PS VIP fabric reset released at t=%0t: FCLK_RESET0_N=%b PL_ARESETN=%b",
                 $time, ps_fclk_resetn, pl_resetn);
        if (ps_fclk_resetn !== 1'b1 || pl_resetn !== 1'b1) begin
            setup_errors = setup_errors + 1;
            $display("WARNING: PS/PL reset stayed low; FCLK_RESET0_N=%b PL_ARESETN=%b", ps_fclk_resetn, pl_resetn);
        end
        data_vaild_0 = 1;
        hall_test_enable = 1;
        #1000000; // 1 ms of PDM bits
        $display("DEBUG 1ms: pl_resetn=%b ps_fclk_resetn=%b data_valid=%b sample_en_sync=%b input_count=%0d warmup=%0d bit_index=%0d",
                 pl_resetn, ps_fclk_resetn, data_vaild_0, cic_sample_enable,
                 cic_input_count, cic_warmup_count, bit_index);
        if (pl_resetn !== 1'b1) begin
            setup_errors = setup_errors + 1;
            $display("WARNING: PL reset never released; check PS7 simulation reset wiring");
        end
        if (cic_sample_enable !== 1'b1 || cic_warmup_count == 0) begin
            setup_errors = setup_errors + 1;
            $display("WARNING: PDM bits are not entering CIC; check data_vaild and CIC reset");
        end
        // Free-running simulation: user presses Pause in Vivado to inspect
        // waveform/counters, then Resume to continue. No automatic $finish.
        forever begin
            #20000000; // Report every 20 ms of simulated time.
            if (angle_count == 0 && dsp_warmup_samples < 32)
                $display("DSP WARMUP: %0d/32 samples; angle_valid starts after about 32 ms at 10 MHz", dsp_warmup_samples);
            $display("LIVE t=%0t ready=%b resetn=%b PDM_bits=%0d CIC=%0d Y=%0d..%0d X=%0d..%0d ANGLE=%0d range=%0d..%0d errors=%0d/%0d Hall_mode=%0d pins=%b visited=%b Hall_errors=%0d",
                     $time, result_ready, pl_resetn, bit_index,
                     cic_count, cic_y_min, cic_y_max, cic_x_min, cic_x_max,
                     angle_count, angle_min, angle_max, setup_errors, angle_errors,
                     hall_mode, hall_out_0, hall_modes_seen, hall_mux_errors);
        end
    end
endmodule
