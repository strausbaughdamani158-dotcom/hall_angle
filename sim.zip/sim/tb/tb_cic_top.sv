`timescale 1ns/1ps

module tb_cic_top;
    logic clk = 0;
    always #5 clk = ~clk;

    logic rst_n = 0;
    logic data_vaild = 0; // RTL port spelling
    logic DataIn_1 = 0;
    logic DataIn_2 = 0;
    wire [15:0] Dout1, Dout2;
    wire [13:0] ch1_avg, ch0_avg;
    wire valid1, valid2;

    // Smaller DEC speeds up this unit test. Gain is rescaled accordingly.
    CIC_TOP #(
        .DEC(32), .ACC_WIDTH(47), .SCALE_NUM(11'd1),
        .SCALE_SHIFT(5), .WARMUP_SAMPLES(3)
    ) dut (
        .DataIn_1(DataIn_1), .DataIn_2(DataIn_2),
        .data_vaild(data_vaild), .rst(rst_n), .clk(clk),
        .Dout1(Dout1), .Dout2(Dout2),
        .ch1_avg(ch1_avg), .ch0_avg(ch0_avg),
        .valid1(valid1), .valid2(valid2)
    );

    integer bit_index = 0;
    integer valid_count = 0;
    reg [15:0] hold1, hold2;

    always @(negedge clk) begin
        if (rst_n && data_vaild) begin
            // CH1: 25% ones; CH2: 75% ones.
            DataIn_1 = (bit_index % 4 == 0);
            DataIn_2 = (bit_index % 4 != 0);
            bit_index = bit_index + 1;
        end
        if (rst_n && valid1) begin
            if (!valid2) $fatal(1, "CIC valid pulses differ");
            valid_count = valid_count + 1;
        end
    end

    initial begin
        repeat (6) @(negedge clk);
        rst_n = 1;
        data_vaild = 1;
        repeat (1800) @(negedge clk);
        if (valid_count < 10) $fatal(1, "Too few CIC output samples: %0d", valid_count);
        if (!(Dout1 > 16'd1000 && Dout2 > Dout1))
            $fatal(1, "CIC channel ordering failed: CH1=%0d CH2=%0d", Dout1, Dout2);
        if (ch0_avg !== Dout1[15:2] || ch1_avg !== Dout2[15:2])
            $fatal(1, "CIC 14-bit monitor mapping failed");

        data_vaild = 0;
        repeat (5) @(negedge clk); // Flush the input synchronizer.
        hold1 = Dout1;
        hold2 = Dout2;
        repeat (100) begin
            @(negedge clk);
            if (valid1 || valid2 || Dout1 !== hold1 || Dout2 !== hold2)
                $fatal(1, "CIC changed while data_vaild=0");
        end
        $display("PASS CIC_TOP: %0d valid outputs, CH1=%0d CH2=%0d, input gating OK",
                 valid_count, Dout1, Dout2);
        $finish;
    end
endmodule
