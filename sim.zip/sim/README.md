# RTL 仿真

本目录保存测试平台和导入脚本。设计源文件在 `../src/`，此处不重复复制 RTL/IP；

## 文件与测试范围

| 文件 | 用途 |
| --- | --- |
| `tb/tb_cic_top.sv` | CIC 单元测试：双通道位流、输出有效脉冲、通道对应关系、`data_vaild` 门控。为加快运行，抽取率设为 32，不能代表最终 2560 的吞吐/延迟。 |
| `tb/tb_angle_sensor_system_wrapper.sv` | 对真实 BD wrapper 施加 PS 参考时钟、复位和两路正余弦 PDM 位流，观察 CIC 输出与 DSP 角度输出。需 Vivado 生成的 BD、PS7/IP 仿真模型。 |
| `scripts/add_sim_sources.tcl` | 在已经打开并生成 BD output products 的 Vivado 工程中导入上述两个 TB，并设置 wrapper TB 为仿真顶层。 |

## 运行方法（Vivado 2024.2）

1. 打开含 `angle_sensor_system_wrapper`、Block Design 和本提交包自定义 IP 的 Vivado 工程；设计综合顶层保持 `angle_sensor_system_wrapper`。
2. 在 Vivado Tcl Console 执行 `source {<提交包绝对路径>/sim/scripts/add_sim_sources.tcl}`。也可手动将两个 `.sv` 加入 **Simulation Sources**，不能加入 **Design Sources**。
3. 选择 `tb_cic_top` 为 `sim_1` 顶层，运行 Behavioral Simulation。该测试自行结束；以 Tcl Console 中的 `PASS CIC_TOP` 和无 `$fatal` 为通过条件。
4. 选择 `tb_angle_sensor_system_wrapper` 为 `sim_1` 顶层，重新运行 Behavioral Simulation。在 Tcl Console 输入 `run all`；TB 不自动结束，需要在 Vivado 点击 **Pause** 后查看波形，点击 **Run All** 可继续。
5. wrapper 波形建议观察 `data_vaild_0`、`DataIn_1_0`、`DataIn_2_0`、`pl_resetn`、`cic_valid`、`cic_ch1`、`cic_ch2`、`angle_valid`、`angle_final`、`result_ready`。若复位始终为低或 CIC 计数不增长，先检查 PS7 仿真复位模型和 BD output products。截图应包含信号名与时间轴。

wrapper TB 用一阶脉冲密度编码器产生外部 1-bit PDM，不向 DUT 注入解码后的正余弦码。它不运行 ARM ELF，也不证明串口协议、AXI 配置、Hall 实物输出或最终角度精度；这些功能需另做仿真或上板验证。

