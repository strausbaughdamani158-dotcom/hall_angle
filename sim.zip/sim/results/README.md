# 模块仿真结果索引

本目录按功能模块保存 Vivado 仿真波形截图。截图用于展示各级数据通路与输出波形，原始可继续查看的顶层波形保存在本目录的 `.wdb` 和 `.wcfg` 文件中。

| 模块 | 仿真截图 | 图中主要信号 |
| --- | --- | --- |
| CORDIC 角度计算 | `cordic/cordic_waveform.png` | 两路正交输入与 `angle_raw` 角度输出 |
| 归一化 | `normalization/normalization_waveform.png` | 两路输入、手动极值参数与归一化输出 |
| 相位校准 | `phase_calibration/phase_calibration_waveform.png` | 原始 X/Y、粗细调系数与校准后 X/Y |
| PWM/SENT 输出 | `pwm_sent/pwm_sent_waveform.png` | 输出模式、PWM 频率选择、PWM 与 SENT 输出信号 |
| 数字滤波 | `filter/filter_waveform.png` | 两路带噪输入与滤波后输出 |
| CIC 解码 | `cic/cic_waveform.png` | 两路 PDM 输入、有效信号与两路 CIC 输出 |

这些图片均为 Vivado 波形窗口截图，文件名使用小写英文，便于在不同系统中解压和引用。
